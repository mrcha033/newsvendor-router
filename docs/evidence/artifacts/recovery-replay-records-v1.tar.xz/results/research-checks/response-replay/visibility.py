"""Probe whether explicit observed availability survives the selected text input path."""
import copy
from pathlib import Path
import torch
from transformers import AutoTokenizer
from newsvendor.io import digest, lines, write
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_value import state_features

root = Path('/dev/shm/newsvendor-recovery-replay-v1')
config = torch.load(root / 'observed-42.pt', map_location='cpu', weights_only=True)['config']['encoder']
tokenizer = AutoTokenizer.from_pretrained('/dev/shm/newsvendor-public-download-1654e77/forecast-v1/encoder', local_files_only=True)
router = ResearchRouter(None, tokenizer, config)
records = []
for row in lines(root / 'targets.jsonl'):
    if row['benchmark'] != 'retail':
        continue
    value, state = row['input'], row['state']
    failed = [s for s in ('c','p','v','b') if state['state'].get(s) == 'unavailable']
    if not failed or not any(a not in ('hold','handoff') for a in row['actions']):
        continue
    before = router.view(value, state)
    changed = copy.deepcopy(state)
    for slot in failed:
        changed['state'][slot] = 'unconfirmed'
    after = router.view(value, changed)
    numeric_before = state_features(value, state, row['actions'])
    numeric_after = state_features(value, changed, row['actions'])
    item = {'id': row['id'], 'stateKey': row['inputHash'], 'family': row['family'],
            'failedFields': failed, 'supervised': row['supervised'],
            'sameTokens': torch.equal(before['batch']['input_ids'], after['batch']['input_ids']),
            'sameMask': torch.equal(before['batch']['attention_mask'], after['batch']['attention_mask']),
            'sameActions': before['actions'] == after['actions'],
            'sameExactCosts': before['valueCosts'] == after['valueCosts'],
            'queryTruncated': before['queryTruncated'],
            'numericFeaturesDistinguish': numeric_before != numeric_after,
            'tokenHash': digest(before['batch']['input_ids'].tolist())}
    records.append(item)
report = {'scope': 'Train-only input-path intervention on explicit constructed availability. The observed history is held fixed, so this does not prove all no-response information is absent or establish a cause of policy loss.',
          'devUsed': False, 'testUsed': False, 'states': len(records),
          'allTokensMasksActionsAndCostsUnchanged': all(all(r[k] for k in ('sameTokens','sameMask','sameActions','sameExactCosts')) for r in records),
          'allNumericFeaturesDistinguish': all(r['numericFeaturesDistinguish'] for r in records), 'records': records}
write('results/research-checks/response-replay/visibility.json', report)
print({k:v for k,v in report.items() if k != 'records'})
