"""Publish both negative Train screens, retaining all measured paths and candidates."""
import hashlib
import tarfile
from pathlib import Path
from newsvendor.io import read, write


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def publish(path, files):
    assert not path.exists(), path
    manifest = {n: {'bytes': p.stat().st_size, 'sha256': sha(p)} for n,p in files.items()}
    with tarfile.open(path,'w:xz',preset=3) as archive:
        for name,p in files.items(): archive.add(p,arcname=name)
    assert path.stat().st_size < 95*1024**2
    seen=set()
    with tarfile.open(path,'r:xz') as archive:
        for m in archive:
            assert m.isfile() and m.size == manifest[m.name]['bytes']
            assert hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest() == manifest[m.name]['sha256']
            seen.add(m.name)
    assert seen == set(manifest)
    result={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path),'verifiedEveryMember':True,'files':manifest}
    print({k:v for k,v in result.items() if k!='files'},flush=True)
    return result


def compact(report):
    result={k:v for k,v in report.items() if k not in ('results','rawHashes')}
    result['initial']={k:v for k,v in result['initial'].items() if k!='selectedActions'}
    result['results']={k:{**{a:b for a,b in v.items() if a not in ('epochs','selected')},
                          'selected':{a:b for a,b in v['selected'].items() if a!='selectedActions'}}
                       for k,v in report['results'].items()}
    return result


if __name__ == '__main__':
    encoded=Path('/dev/shm/newsvendor-recovery-replay-v1')
    numeric=Path('/dev/shm/newsvendor-recovery-numeric-v1')
    checks=Path('results/research-checks/response-replay')
    reports=[read(p/'report.json') for p in (encoded,numeric)]
    assert all(not r['eligibleForSequentialTrainCheck'] for r in reports)
    assert read(checks/'target-audit.json')['maximumMeanError']==0
    raw=encoded/'train-rollouts.jsonl.gz'
    assert sha(raw)==reports[0]['rawHashes'][raw.name]
    raw_archive=publish(Path('docs/evidence/artifacts/recovery-replay-rollouts-v1.tar.xz'),
                        {'results/l40s-recovery-replay-v1/'+raw.name:raw})
    files={}
    for root,dest in ((encoded,'results/l40s-recovery-replay-v1'),(numeric,'results/l40s-recovery-numeric-v1')):
        files.update({str(Path(dest)/p.name):p for p in root.iterdir() if p.is_file() and p.name!=raw.name})
    files.update({str(p):p for p in checks.iterdir() if p.is_file() and p.name not in ('publication.log','publication.json')})
    for name in ('scripts/study_recovery_replay.py','scripts/evaluate_responses.py','scripts/study_parameter_state.py',
                 'configs/research-recovery-replay-v1.json','configs/research-recovery-numeric-v1.json',
                 'tests/test_recovery_replay.py','docs/evidence/scripts/reproduce-recovery-heads.py','.github/workflows/ci.yml'):
        files[name]=Path(name)
    record_archive=publish(Path('docs/evidence/artifacts/recovery-replay-records-v1.tar.xz'),files)
    evidence={'scope':'Observed-state replay and numeric-input Train screening; neither passes its registered gate. No new policy adoption, no Dev or Test evaluation.',
              'testUsed':False,'devUsed':False,'weightsAdopted':False,
              'encoded':compact(reports[0]),'numeric':compact(reports[1]),
              'coverage':read(checks/'coverage.json'),'targetAudit':read(checks/'target-audit.json'),
              'residuals':read(checks/'residuals.json'),'visibility':read(checks/'visibility.json'),
              'checks':read(checks/'checks.json'),'rawArtifact':raw_archive,'artifact':record_archive}
    write('docs/evidence/research-recovery-replay-results.json',evidence)
    write(checks/'publication.json',{'artifact':record_archive,'rawArtifact':raw_archive})
