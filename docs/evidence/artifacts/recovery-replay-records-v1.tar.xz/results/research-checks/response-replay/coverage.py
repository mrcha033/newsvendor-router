"""Compare supervised Train states with every preserved continuation state."""
import collections
import copy
import json
from pathlib import Path
from newsvendor.io import read, digest, write
from newsvendor.structured_forecast import actions, copy_responses

plan = read('configs/l40s-parameter-state-v1.json')
starts, all_states, sources = {}, {}, {}
for name in plan['rollouts']:
    p = Path(name)
    assert digest(p.read_bytes()) == plan['files'][name]
    sources[name] = plan['files'][name]
    for row in map(json.loads, p.open()):
        assert row['split'] == 'train'
        for i, event in enumerate(row['events']):
            key = digest([row['family'], event['input']])
            item = {'id': row['id'], 'family': row['family'], 'input': event['input'], 'state': event['state']}
            all_states[key] = item
            if i == 0:
                starts[key] = item


def summarize(states):
    counts, cases = collections.Counter(), []
    for key, event in states.items():
        value, state = event['input'], copy.deepcopy(event['state'])
        copy_responses(value, state)
        kind = 'retail' if 'forecast' in value['task'] else 'generated'
        counts[kind] += 1
        counts[kind + ('AfterRequest' if value['history'] else 'Initial')] += 1
        failed = [k for k in ('c', 'p', 'v', 'b') if state['state'].get(k) == 'unavailable' and k not in state['values']]
        other = [a for a in actions(value, state) if a not in ('hold', 'handoff')]
        if failed:
            counts[kind + 'FailedStates'] += 1
            if other:
                counts[kind + 'FailedWithOtherRequest'] += 1
                cases.append({'id': event['id'], 'stateHash': key, 'history': value['history'],
                              'failed': failed, 'other': other, 'rootSupervised': key in starts})
    return {'states': len(states), 'families': len({s['family'] for s in states.values()}),
            'counts': dict(counts), 'failedWithOtherRequest': cases}


report = {'scope': 'Historical Train collection versus all measured continuation states; no new inference or outcome selection',
          'testUsed': False, 'devUsed': False, 'sources': sources,
          'supervised': summarize(starts), 'encountered': summarize(all_states)}
write('results/research-checks/response-replay/coverage.json', report)
for kind in ('supervised', 'encountered'):
    print(kind, {k: v for k, v in report[kind].items() if k != 'failedWithOtherRequest'}, flush=True)
