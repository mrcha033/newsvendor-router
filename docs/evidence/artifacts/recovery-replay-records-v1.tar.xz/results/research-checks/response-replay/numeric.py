"""Matched replay comparison using the existing numeric-state value inputs."""
import copy
import os
import sys
import time
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0, str(Path('scripts').resolve()))
from study_recovery_replay import measure, scores
from evaluate_responses import file_hash
from newsvendor.heads import Head
from newsvendor.io import lines, read, write, require
from newsvendor.cli import provenance
from newsvendor.structured_critic import value_loss
from newsvendor.structured_value import state_features, STATE_FEATURES
from newsvendor.train import seed

plan = read('configs/research-recovery-numeric-v1.json')
assert os.environ.get('CUDA_VISIBLE_DEVICES') == plan['gpu']
assert torch.cuda.device_count() == 1 and 'L40S' in torch.cuda.get_device_name(0)
assert file_hash(__file__) == plan['scriptHash']
assert provenance({})['sourceHash'] == plan['sourceHash']
for path, sha in plan['files'].items():
    assert file_hash(path) == sha, path
root = Path(plan['output']); assert not root.exists(); root.mkdir()
base = Path(plan['previous'])
prior = read(base / 'report.json')
rows = lines(base / 'targets.jsonl')
payload = torch.load(base / 'features.pt', map_location='cpu', weights_only=True)
seed(42); torch.set_num_threads(4)
started = time.perf_counter()
old = Head(256,128,2).to('cuda').eval()
old.load_state_dict(payload['initial'])
head = Head(256 + len(STATE_FEATURES),128,2).to('cuda').eval()
weights = copy.deepcopy(old.state_dict())
weights['layers.0.weight'] = torch.cat([weights['layers.0.weight'], torch.zeros(128,len(STATE_FEATURES),device='cuda')],1)
head.load_state_dict(weights)
features = []
for row, (x,y,costs) in zip(rows,payload['features'],strict=True):
    numeric = state_features(row['input'],row['state'],row['actions'])
    x,y = x.to('cuda'),y.to('cuda')
    feature = (torch.cat([x,x.new_tensor(numeric)],1),y,costs)
    with torch.no_grad():
        a,b = scores(old,(x,y,costs)),scores(head,feature)
        require(torch.allclose(a,b,atol=1e-7,rtol=1e-6), 'Padded initial scores changed')
        require(int(a.sum(-1).argmin()) == int(b.sum(-1).argmin()), 'Padded initial decision changed')
    features.append(feature)
fit_families = set(prior['partitions']['fit']['families'])
fit = [i for i,r in enumerate(rows) if r['family'] in fit_families]
held = [i for i,r in enumerate(rows) if r['family'] not in fit_families]
report = {'scope':'Source-held Train screening of the existing numeric-state path with corrected observed response states. Frozen parent continuation targets; not new-policy effectiveness.',
          'devUsed':False,'testUsed':False,'plan':plan,'source':provenance({}),
          'initialPredictionsPreserved':True,'numericDimensions':len(STATE_FEATURES),
          'initial':measure(head,features,rows,held),'results':{}}
write(root/'registered.json',report)
torch.save({'features':[(x.cpu(),y.cpu(),c) for x,y,c in features], 'initial':weights},root/'features.pt')
updates = (len(fit) + plan['batchSize'] - 1) // plan['batchSize']
for condition in ('observed','continuations'):
    ids = [i for i in fit if condition == 'continuations' or rows[i]['supervised']]
    for random_seed in plan['seeds']:
        head.load_state_dict(weights)
        random = np.random.default_rng(random_seed)
        optimizer = torch.optim.AdamW(head.parameters(),lr=plan['lr'],weight_decay=0.01,fused=True)
        best, selected = report['initial']['meanTargetLoss'],0
        saved,saved_optimizer = copy.deepcopy(weights),None
        history = []
        for epoch in range(plan['epochs']):
            for _ in range(updates):
                order = random.choice(ids,size=plan['batchSize'],replace=True)
                batch = [features[int(i)] for i in order]
                optimizer.zero_grad(set_to_none=True)
                loss = value_loss(head,batch,plan['rankWeight'])
                assert torch.isfinite(loss)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(head.parameters(),5,error_if_nonfinite=True)
                optimizer.step()
            measured = measure(head,features,rows,held)
            if measured['meanTargetLoss'] < best - 1e-10:
                best,selected = measured['meanTargetLoss'],epoch+1
                saved,saved_optimizer = copy.deepcopy(head.state_dict()),copy.deepcopy(optimizer.state_dict())
            history.append({'epoch':epoch+1,**measured})
        final = copy.deepcopy(head.state_dict())
        head.load_state_dict(saved)
        key = f'{condition}-{random_seed}'
        report['results'][key] = {'selectedEpoch':selected,'fitStates':len(ids),
            'updatesPerEpoch':updates,'selected':measure(head,features,rows,held),'epochs':history,
            'newColumnsNorm':float(torch.linalg.vector_norm(head.layers[0].weight[:,256:]).detach())}
        torch.save({'weights':saved,'optimizer':saved_optimizer,'finalWeights':final,
                    'finalOptimizer':optimizer.state_dict(),'seed':random_seed,'selectedEpoch':selected,
                    'finalEpoch':plan['epochs'],'numericState':True,'actionPrecision':'float32',
                    'parentWeightsHash':prior['plan']['weightsHash']},root/f'{key}.pt')
        write(root/'partial.json',report)
        print({'condition':key,'selectedEpoch':selected,'heldLoss':best,'seconds':time.perf_counter()-started},flush=True)
report['gates'] = {}
for random_seed in plan['seeds']:
    old_result = prior['results'][f'continuations-{random_seed}']['selected']
    control = report['results'][f'observed-{random_seed}']['selected']
    current = report['results'][f'continuations-{random_seed}']['selected']
    report['gates'][str(random_seed)] = {
        'improvesEncodedReplay':current['meanTargetLoss'] < old_result['meanTargetLoss'] - 1e-10,
        'notWorseThanNumericObserved':current['meanTargetLoss'] <= control['meanTargetLoss'] + 1e-10,
        'bothBenchmarksNotWorseThanParent':all(current['benchmarks'][k]['targetLoss'] <= report['initial']['benchmarks'][k]['targetLoss'] + 1e-10 for k in current['benchmarks']),
        'noAdditionalExpectedFalseHandoff':all(current['benchmarks'][k]['falseHandoff'] <= report['initial']['benchmarks'][k]['falseHandoff'] + 1e-10 for k in current['benchmarks'])}
report['eligibleForSequentialTrainCheck'] = all(all(v.values()) for v in report['gates'].values())
report['seconds'] = time.perf_counter()-started
report['peakGpuBytes'] = torch.cuda.max_memory_allocated()
report['rawHashes'] = {p.name:file_hash(p) for p in root.iterdir() if p.is_file()}
write(root/'report.json',report)
print({'completed':True,'seconds':report['seconds'],'gates':report['gates']},flush=True)
