"""Check every collected action target against its preserved actual Train rollouts."""
import gzip
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from newsvendor.io import digest, read, lines, write

root = Path('/dev/shm/newsvendor-recovery-replay-v1')
report = read(root / 'report.json')
targets = {r['inputHash']: r for r in lines(root / 'targets.jsonl')}
assert len(targets) == report['states']
groups = defaultdict(list)
paths = 0
with gzip.open(root / 'train-rollouts.jsonl.gz', 'rt') as stream:
    for row in map(json.loads, stream):
        target = targets[row['stateKey']]
        assert row['split'] == 'train' and row['family'] == target['family']
        assert row['id'] == target['id']
        assert row['events'][0]['input'] == target['input']
        assert row['events'][0]['state'] == target['state']
        assert row['events'][0]['action'] == row['forcedAction']
        groups[row['stateKey'], row['forcedAction']].append(
            (row['responseSeed'], row['terminalLoss'], row['requestCost'], float(row['falseHandoff']))
        )
        paths += 1
maximum = 0.0
for key, row in targets.items():
    assert row['split'] == 'train'
    for action, expected, false in zip(row['actions'], row['values'], row['falseHandoffs'], strict=True):
        samples = groups[key, action]
        assert len(samples) == len({s[0] for s in samples}) == report['plan']['responseSamples']
        expected_seeds = [digest([report['plan']['responseSeed'], 'target', i]) for i in range(len(samples))]
        assert [s[0] for s in samples] == expected_seeds
        measured = np.mean([[s[1], s[2]] for s in samples], axis=0) / row['input']['task']['hold']
        maximum = max(maximum, float(np.max(np.abs(measured - expected))))
        assert abs(np.mean([s[3] for s in samples]) - false) < 1e-12
assert maximum < 1e-12
fit, held = [set(report['partitions'][k]['families']) for k in ('fit', 'held')]
assert not fit & held and fit | held == {r['family'] for r in targets.values()}
assert len({r['updatesPerEpoch'] for r in report['results'].values()}) == 1
result = {'scope': 'Every finite sampled action target checked against its actual parent-continuation rollout, not an optimum or new-policy loss.',
          'states': len(targets), 'actions': len(groups), 'rawRollouts': paths, 'maximumMeanError': maximum,
          'allStartingObservationsAndModelStatesMatch': True, 'sourceOverlap': 0,
          'fitFamilies': len(fit), 'heldFamilies': len(held), 'sameGradientBudget': True,
          'testUsed': False, 'devUsed': False}
write('results/research-checks/response-replay/target-audit.json', result)
print(result, flush=True)
