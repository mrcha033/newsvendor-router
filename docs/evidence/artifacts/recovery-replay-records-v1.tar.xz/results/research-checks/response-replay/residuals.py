"""Describe remaining held-Train action errors using finite measured return targets."""
from collections import Counter
from pathlib import Path
import numpy as np
from newsvendor.io import lines, read, write

root = Path('/dev/shm/newsvendor-recovery-replay-v1')
report = read(root / 'report.json')
rows = lines(root / 'targets.jsonl')
families = set(report['partitions']['held']['families'])
held = [r for r in rows if r['family'] in families]
choices = {k: v['selected']['selectedActions'] for k, v in report['results'].items()}
result = {'scope': 'Diagnostic of finite parent-continuation return targets on inner held Train states; no independent policy rollout or optimality claim.',
          'devUsed': False, 'testUsed': False,
          'sameSelectedActionsAllSixHeads': all(v == next(iter(choices.values())) for v in choices.values()),
          'conditions': {}}
for condition, chosen in choices.items():
    mistakes = []
    for row, selected in zip(held, chosen, strict=True):
        costs = np.asarray(row['values'], dtype=np.float32).sum(-1)
        minimum = float(costs.min())
        gap = float(costs[selected]) - minimum
        if gap <= 1e-7:
            continue
        mistake = {k: row[k] for k in ('id', 'family', 'benchmark', 'inputHash', 'supervised', 'actions', 'values')}
        mistake.update(chosen=row['actions'][selected], best=[row['actions'][i] for i, v in enumerate(costs) if abs(float(v) - minimum) < 1e-7],
                       normalizedGap=gap, actualUnitGap=gap * row['input']['task']['hold'],
                       history=row['input']['history'], states=row['state']['state'],
                       remaining=row['input']['remaining'])
        mistakes.append(mistake)
    result['conditions'][condition] = {'errors': len(mistakes), 'benchmarks': dict(Counter(r['benchmark'] for r in mistakes)), 'records': mistakes}
write('results/research-checks/response-replay/residuals.json', result)
print({k: v for k, v in result.items() if k != 'conditions'})
for k, v in result['conditions'].items():
    print(k, {a: b for a, b in v.items() if a != 'records'})
for r in result['conditions']['continuations-42']['records']:
    print({k: r[k] for k in ('id', 'benchmark', 'supervised', 'chosen', 'best', 'normalizedGap', 'history', 'states')})
