import hashlib
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write

root=Path("results/research-checks/current-source")
run=Path("results/l40s-research-action-adaptation-v1")
output=run/"value/42"
registered=read(run/"registered.json")
report=read(output/"report.json")
storage=read(run/"storage.json")
require(read(run/"queue.json")["status"]=="complete" and read(output/"job.json")["stage"]=="complete","Live training")
require(storage["allHashesVerified"] and storage["durableCopyVerified"] and storage["allCheckpointsAndOptimizersPreserved"],"Missing training archive")
require(file_hash(storage["archive"])==storage["sha256"],"Private training archive changed")
require(provenance({})["sourceHash"]==registered["source"]["sourceHash"],"Measured source changed")
with tarfile.open(output/"source.tar.gz","r:gz") as tar:
    for name,expected in registered["source"]["sources"].items():
        require(hashlib.sha256(tar.extractfile(name).read()).hexdigest()==expected,"Training source snapshot changed")
require("283 passed in 31.85s" in (root/"tests.log").read_text(),"Tests not verified")
require("All checks passed!" in (root/"ruff.log").read_text() and "87 files already formatted" in (root/"ruff.log").read_text(),"Ruff failed")
checks={"tests":{"passed":283,"seconds":31.85,"logHash":file_hash(root/"tests.log")},"ruff":{"passed":True,"formatFiles":87,"logHash":file_hash(root/"ruff.log")},"sourceChecks":read(root/"source-checks.json"),"numericalSmoke":read("results/smoke.json"),"currentSourceHash":provenance({})["sourceHash"],"policyData":read(root/"policy-data-check.json")}
require(len(checks["sourceChecks"])==4,"Incomplete source audits")
for check in checks["sourceChecks"].values():
    require(check["check"]["sourceOverlaps"]==check["check"]["inputOverlaps"]==0,"Source leakage")
require(checks["numericalSmoke"]["smokeEpisodes"]==30 and checks["numericalSmoke"]["falseHandoffs"]==0,"Numerical smoke failed")
write(root/"checks.json",checks)
paths=set()
for p in root.rglob("*"):
    if p.is_file() and p.suffix not in (".pt",".pyc") and p!=root/"publish.log":paths.add(p)
for p in run.rglob("*"):
    if p.is_file() and p.suffix!=".zst" and (p.suffix!=".pt" or p.name.startswith("policy-candidate-")):paths.add(p)
paths.update(Path(p) for p in (
    "configs/l40s-research-action-adaptation-v1.json","src/newsvendor/structured_forecast.py","src/newsvendor/structured_rollout.py","tests/test_structured.py",
    "results/research-checks/parameter-contrast/inputs.jsonl","results/research-checks/parameter-contrast/labels.jsonl","results/research-checks/parameter-contrast/raw.jsonl",
    "results/parameter-contrasts-v2/held.jsonl","results/parameter-contrasts-v2/manifest.json",
    "results/l40s-parameter-scope-held-v1/parent.jsonl","results/l40s-parameter-scope-held-v1/control_selected.jsonl","results/l40s-parameter-scope-held-v1/prefix_selected.jsonl",
    "results/l40s-research-replay-v1/base/42/value-targets-0.jsonl",
))
for name,prefix in (("parent","results/l40s-research-scope-v1/control/42/initial"),("control","results/l40s-research-scope-v1/control/42/final"),("prefix","results/l40s-research-scope-v1/prefix/42/final")):
    for cohort in ("dev","generated-dev"):paths.add(Path(prefix+"-"+cohort+"-learned.jsonl"))
paths.add(Path("results/l40s-research-scope-v1/control/42/documents-dev.jsonl"))
files={str(p):{"sha256":file_hash(p),"bytes":p.stat().st_size} for p in sorted(paths)}
archive=Path("docs/evidence/artifacts/research-source-validity.tar.xz")
require(not archive.exists(),"Preserve prior evidence")
print({"stage":"archive","files":len(files),"rawBytes":sum(r["bytes"] for r in files.values())},flush=True)
with tarfile.open(archive,"w:xz",preset=3) as tar:
    for name in files:tar.add(name,arcname=name)
with tarfile.open(archive,"r:xz") as tar:
    require(set(tar.getnames())==set(files),"Public archive members differ")
    for name,record in files.items():
        require(hashlib.file_digest(tar.extractfile(name),"sha256").hexdigest()==record["sha256"],"Public archive hash differs")
published={"path":str(archive),"sha256":file_hash(archive),"bytes":archive.stat().st_size,"files":files,"allHashesVerified":True}
validity={"scope":"Unify current-version/conflict validation for newly selected expressions and observed state/response copying; frozen predictions and actual L40S verification, not improved learned extraction","testUsed":False,"modelWeightsChanged":False,"source":provenance({}),"registration":read(root/"registered.json"),"replay":read(root/"report.json"),"gpuVerification":read(root/"gpu-report.json")["constructor"],"checks":checks,"publishedRaw":published,"limitations":["Rejecting a wrong value makes it unresolved; value extraction error counts do not improve and requests/holds may increase on shifted inputs.","Competing source discovery uses existing supported financial-document kinds, so arbitrary document lineage is not solved.","The original Dev comparison replays saved neural/forecast outputs and asserts exact historical-state equality; it is not a newly executed sequential economic result.","Controlled Train document perturbations are not real organizational effectiveness evidence."]}
write("docs/evidence/research-source-validity-results.json",validity)
adaptation={"scope":"Fresh own-state action-value fitting after a changed fixed constructor; retail missed requests recover but generated loss/public retention prevent full-model adoption","testUsed":False,"modelReplacementMade":False,"retainedCheckpoint":"results/l40s-research-forecast-v1/base/42/model.pt","retainedCheckpointHash":"e2fb23ee44b7a6c7158b111d122280d41f3626027f33323ff98f0fddc765904a","registration":registered,"initialDevDiagnosis":read(root/"action-drift-dev.json"),"trainDiagnosis":read(root/"gpu-report.json"),"trainComponents":read(root/"action-drift-components.json"),"training":report,"weightAndPublicVerification":read(root/"policy-verification.json"),"generatedLossDecomposition":read(root/"policy-loss-decomposition.json"),"privateStorage":storage,"checks":checks,"publishedRaw":published,"decision":{"adopted":False,"reason":"TAT-QA remains 12/48 versus selected model 16/48; generated Dev loss 148.3549 exceeds selected model 147.6813. Within-constructor retail recovery alone is insufficient."},"limitations":["One fixed seed; retail exact loss covers five unique periods crossed with seven controlled conditions.","Five additional generated requests come from one source family; this is not five independent failure groups.","Frozen public predictions prove value-only fitting preserves the rejected constructor's public outputs, not that those outputs meet the earlier selected model's quality.","Candidate and optimizer weights are preserved locally; small value-head candidates and raw measurements are public, while this candidate's full constructor archive remains local.","No new Test was used and the legacy generated Test threshold remains unmet."]}
write("docs/evidence/research-action-adaptation-results.json",adaptation)
print({"stage":"published","bytes":archive.stat().st_size,"files":len(files)},flush=True)
