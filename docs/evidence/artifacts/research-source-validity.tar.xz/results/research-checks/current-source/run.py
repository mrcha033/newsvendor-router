import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write

root=Path("results/l40s-research-action-adaptation-v1")
plan=read(root/"registered.json")
require(os.environ.get("CUDA_VISIBLE_DEVICES")==plan["gpu"],"Assigned GPU only")
require(provenance({})["sourceHash"]==plan["source"]["sourceHash"],"Registered source changed")
for path,expected in plan["files"].items():
    require(file_hash(path)==expected,"Registered file changed: "+path)
state={"status":"running","pid":os.getpid(),"testUsed":False}
started=time.perf_counter()
for stage,command in (
    ("diagnostic",[sys.executable,"results/research-checks/current-source/train_actions.py"]),
    ("policy",[sys.executable,"scripts/run_research.py","--config",plan["config"],"--stage","policy"]),
):
    if stage=="policy":
        require(read("results/research-checks/current-source/gpu-report.json")["changedTrainActions"]>0,"No Train action drift; reassess need for adaptation")
        require(shutil.disk_usage(root).free>1.7*1024**3,"Insufficient checkpoint space")
    with (root/(stage+".log")).open("w") as stream:
        child=subprocess.Popen(command,stdout=stream,stderr=subprocess.STDOUT)
        state.update(stage=stage,childPid=child.pid)
        write(root/"queue.json",state)
        print({"stage":stage,"pid":child.pid},flush=True)
        code=child.wait()
    require(code==0,"Stage failed: "+stage)
state.update(status="complete",childPid=None,seconds=time.perf_counter()-started)
write(root/"queue.json",state)
print(state,flush=True)
