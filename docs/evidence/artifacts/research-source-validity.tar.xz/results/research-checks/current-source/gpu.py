import copy
import importlib.util
import os
import time
from pathlib import Path

import torch

from newsvendor import structured_rollout
from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_train import load
from newsvendor.train import seed

root=Path(__file__).resolve().parent
require(not (root/"gpu-report.json").exists(),"Preserve previous GPU audit")
require(os.environ.get("CUDA_VISIBLE_DEVICES")=="GPU-674d64b8-4bdf-7006-1791-5dc7f7245409","Assigned GPU only")
require(torch.cuda.device_count()==1 and torch.cuda.get_device_name(0)=="NVIDIA L40S","L40S only")
seed(42);torch.set_num_threads(8)
started=time.perf_counter()

def previous(name):
    spec=importlib.util.spec_from_file_location("newsvendor._gpu_before_"+name,root/("before-"+name+".py"))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

old_rollout=previous("structured_rollout")
old_rollout.structured_forecast=previous("structured_forecast")
paths={"parent":"results/l40s-research-forecast-v1/base/42/model.pt","control":"results/l40s-research-scope-v1/control/42/model.pt"}
inputs=lines("results/research-checks/parameter-contrast/inputs.jsonl")
before=lines("results/research-checks/parameter-contrast/raw.jsonl")
after=lines(root/"initial_train.jsonl")
target_path=Path("results/l40s-research-replay-v1/base/42/value-targets-0.jsonl")
targets=lines(target_path)
require(all(r["split"]=="train" for r in targets),"Train actions only")
write(root/"gpu-registered.json",{"source":provenance({}),"scriptHash":file_hash(__file__),"checkpointHashes":{k:file_hash(v) for k,v in paths.items()},"trainTargetsHash":file_hash(target_path),"testUsed":False,"trainingPerformed":False,"validationCases":len(inputs),"actionTrainStates":len(targets)})
report={"scope":"Actual L40S old/new constructor parity and Train-only action representation drift with identical captured own-state inputs; existing parent-rollout losses are diagnostic targets, not fresh current-policy rollout values","testUsed":False,"trainingPerformed":False,"models":{}}
records={}
for name,path in paths.items():
    model,tokenizer,config,_=load(path,"cuda")
    router=structured_rollout.ResearchRouter(model,tokenizer,config["encoder"],config["noValue"])
    if name=="parent":
        original=old_rollout.ResearchRouter(model,tokenizer,config["encoder"],config["noValue"])
        validation=[]
        for i,(row,old,expected) in enumerate(zip(inputs,before,after,strict=True)):
            actual_old=original.construct(row["input"])
            actual_new=router.construct(row["input"])
            require(actual_old==old["state"],"Actual old inference differs from archived output")
            require(actual_new==expected["after"],"Actual new inference differs from acceptance replay")
            validation.append({"id":row["id"],"family":row["family"],"condition":row["condition"],"beforeHash":digest(actual_old),"afterHash":digest(actual_new),"rawPredictionsEqual":actual_old["rawFields"]==actual_new["rawFields"]})
            if (i+1)%64==0:print({"stage":"constructor","processed":i+1,"cases":len(inputs)},flush=True)
        jsonl(root/"gpu-constructor.jsonl",validation)
        report["constructor"]={"cases":len(validation),"archivedOldOutputExact":True,"acceptanceReplayExact":True,"rawPredictionsEqual":all(r["rawPredictionsEqual"] for r in validation),"rawHash":file_hash(root/"gpu-constructor.jsonl")}
    raw=[];features=[]
    with torch.inference_mode():
        for start in range(0,len(targets),32):
            group=targets[start:start+32]
            views=[router.view(r["input"],r["state"]) for r in group]
            for lo,hi in model.training_batches(views):
                for row,view,output in zip(group[lo:hi],views[lo:hi],model(views[lo:hi]),strict=True):
                    require(view["actions"]==row["actions"],"Action set changed")
                    scores=output["value"].sum(-1)
                    target=scores.new_tensor(row["values"]).sum(-1)
                    selected=int(scores.argmin());best=int(target.argmin())
                    raw.append({"id":row["id"],"family":row["family"],"inputHash":digest(row["input"]),"stateHash":digest(row["state"]),"actions":row["actions"],"scores":scores.cpu().tolist(),"parentRolloutTargets":target.cpu().tolist(),"predictedAction":row["actions"][selected],"targetBest":row["actions"][best],"excessAgainstParentRollouts":float(target[selected]-target[best]),"mseAgainstParentRollouts":float((scores-target).square().mean())})
                    features.append({"features":output["actionState"].cpu(),"costs":view.get("valueCosts"),"target":row["values"]})
            if (start+32)%128==0:print({"stage":"train_action_features","model":name,"processed":min(start+32,len(targets))},flush=True)
    jsonl(root/(name+"-action-train.jsonl"),raw)
    torch.save(features,root/(name+"-action-features.pt"))
    records[name]=raw
    report["models"][name]={"weightsHash":weights_hash(model.state_dict()),"valueHeadHash":weights_hash(model.heads["value"].state_dict()),"states":len(raw),"wrongAgainstParentRollouts":sum(r["predictedAction"]!=r["targetBest"] for r in raw),"meanExcessAgainstParentRollouts":sum(r["excessAgainstParentRollouts"] for r in raw)/len(raw),"rawHash":file_hash(root/(name+"-action-train.jsonl")),"featuresHash":file_hash(root/(name+"-action-features.pt"))}
    del model,router,tokenizer,features
    if name=="parent":del original
    torch.cuda.empty_cache()
require(report["models"]["parent"]["valueHeadHash"]==report["models"]["control"]["valueHeadHash"],"Value head changed")
report["changedTrainActions"]=sum(a["predictedAction"]!=b["predictedAction"] for a,b in zip(records["parent"],records["control"],strict=True))
report["seconds"]=time.perf_counter()-started
report["peakGpuBytes"]=torch.cuda.max_memory_allocated()
write(root/"gpu-report.json",report)
print(report,flush=True)
