import hashlib
import os
import shutil
import subprocess
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

root=Path("results/l40s-research-action-adaptation-v1")
output=root/"value/42"
require(read(root/"queue.json")["status"]=="complete" and read(output/"job.json")["stage"]=="complete","Training is live")
paths=[p for p in sorted(output.rglob("*")) if p.is_file()]
files={str(p.relative_to(output)):{"sha256":file_hash(p),"bytes":p.stat().st_size} for p in paths}
archive=Path("/dev/shm/newsvendor-action-adaptation-v1.tar.zst")
require(not archive.exists(),"Preserve previous archive")
with archive.open("xb") as stream:
    process=subprocess.Popen(["zstd","-T2","-3","--long=31","-c"],stdin=subprocess.PIPE,stdout=stream)
    with tarfile.open(fileobj=process.stdin,mode="w|") as tar:
        for path in paths:tar.add(path,arcname=str(path.relative_to(output)))
    process.stdin.close();require(process.wait()==0,"Compression failed")
process=subprocess.Popen(["zstd","--long=31","-dc",str(archive)],stdout=subprocess.PIPE)
seen=set()
with tarfile.open(fileobj=process.stdout,mode="r|") as tar:
    for member in tar:
        require(member.isfile() and member.name in files and member.name not in seen,"Unexpected archive member")
        require(hashlib.file_digest(tar.extractfile(member),"sha256").hexdigest()==files[member.name]["sha256"],"Archive member changed")
        seen.add(member.name)
require(process.wait()==0 and seen==set(files),"Incomplete archive verification")
sha=file_hash(archive);target=root/"full-run.tar.zst"
require(not target.exists(),"Preserve previous durable archive")
require(shutil.disk_usage(root).free>archive.stat().st_size+300_000_000,"Insufficient durable storage")
with archive.open("rb") as src,target.open("xb") as dst:
    shutil.copyfileobj(src,dst,8*1024*1024);dst.flush();os.fsync(dst.fileno())
require(file_hash(target)==sha,"Durable archive copy differs")
duplicate=output/"policy-base.pt"
require(file_hash(duplicate)==files["policy-base.pt"]["sha256"],"Policy base changed")
duplicate.unlink()
write(root/"storage.json",{"archive":str(target),"sha256":sha,"bytes":target.stat().st_size,"files":files,"allHashesVerified":True,"durableCopyVerified":True,"archiveOnly":["policy-base.pt"],"allCheckpointsAndOptimizersPreserved":True,"restore":"zstd --long=31 -dc "+str(target)+" | tar -xf - -C <new-directory>"})
print({"archive":str(target),"bytes":target.stat().st_size,"files":len(files),"allHashesVerified":True},flush=True)
