import os
from pathlib import Path

import torch

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import lines, read, require, write
from newsvendor.structured_policy import public_validation
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_train import load
from newsvendor.train import seed

root=Path(__file__).resolve().parent
require(os.environ.get("CUDA_VISIBLE_DEVICES")=="GPU-674d64b8-4bdf-7006-1791-5dc7f7245409","Assigned GPU only")
seed(42);torch.set_num_threads(8)
parent_path=Path("results/l40s-research-scope-v1/control/42/model.pt")
current_path=Path("results/l40s-research-action-adaptation-v1/value/42/model.pt")
parent=torch.load(parent_path,map_location="cpu",mmap=True,weights_only=True)["weights"]
current=torch.load(current_path,map_location="cpu",mmap=True,weights_only=True)["weights"]
changed=[k for k in parent if not torch.equal(parent[k],current[k])]
require(changed and all(k.startswith("heads.value.") for k in changed),"Non-value parameters changed")
fixed=weights_hash({k:v for k,v in current.items() if not k.startswith("heads.value.")})
report=read(current_path.parent/"report.json")
require(all(r["frozenWeightsHash"]==fixed and r["frozenWeightsUnchanged"] for r in report["policy"]),"Frozen-weight audit differs")
model,tokenizer,config,_=load(current_path,"cuda")
inputs=lines(current_path.parent/"documents-inputs.jsonl")
dev=[("public",r) for r in inputs if r["split"]=="dev"]
labels=read(current_path.parent/"documents-labels.json")
collection=lines(Path(config["dataset"])/"collection.jsonl")
metrics=public_validation(model,tokenizer,config,dev,labels,collection,root/"policy-public-dev.jsonl")
previous=lines(parent_path.parent/"documents-dev.jsonl")
after=lines(root/"policy-public-dev.jsonl")
require(previous==after,"Frozen public predictions changed")
result={"scope":"Audit actual changed tensors and all original public Dev outputs after value-only own-state fitting; no Test","testUsed":False,"parentHash":file_hash(parent_path),"checkpointHash":file_hash(current_path),"weightsHash":weights_hash(current),"frozenWeightsHash":fixed,"changedTensors":changed,"publicCases":len(after),"publicPredictionsExactlyEqual":True,"publicMetrics":metrics,"publicRawHash":file_hash(root/"policy-public-dev.jsonl"),"provenance":provenance({})}
write(root/"policy-verification.json",result)
print({"changedTensors":changed,"publicCases":len(after),"publicPredictionsExactlyEqual":True,"publicMetrics":metrics},flush=True)
