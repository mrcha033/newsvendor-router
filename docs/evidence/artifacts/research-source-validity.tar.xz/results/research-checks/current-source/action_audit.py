from pathlib import Path

import torch

from newsvendor.bundle import file_hash
from newsvendor.io import digest, jsonl, lines, require, write
from newsvendor.structured_tool_eval import weights_hash

root=Path(__file__).resolve().parent
torch.set_num_threads(4)
paths={"parent":"results/l40s-research-forecast-v1/base/42/model.pt", "control":"results/l40s-research-scope-v1/control/42/model.pt"}
states={name:torch.load(path,map_location="cpu",mmap=True,weights_only=True)["weights"] for name,path in paths.items()}
heads={name:weights_hash({k:v for k,v in state.items() if k.startswith("heads.value.")}) for name,state in states.items()}
require(heads["parent"]==heads["control"],"Action value head changed")
base="results/l40s-research-scope-v1/control/42/"
before={r["id"]:r for r in lines(base+"initial-dev-learned.jsonl")}
after={r["id"]:r for r in lines(base+"final-dev-learned.jsonl")}
require(before.keys()==after.keys(),"Retail Dev cases changed")
keys=("values","state","types","q","gamma","valid","errors","forecast","missing")
rows=[]
for key,left in before.items():
    right=after[key]
    require(left["split"]==right["split"]=="dev","Original Dev only")
    old,new=left["events"][0],right["events"][0]
    require(old["input"]==new["input"],"Initial observations changed")
    summary_equal={k:old["state"].get(k) for k in keys}=={k:new["state"].get(k) for k in keys}
    decision_equal=old["decision"]["inputHash"]==new["decision"]["inputHash"]
    changed=old["action"]!=new["action"]
    rows.append({"id":key,"family":left["family"],"semanticStateEqual":summary_equal,"actionInputHashEqual":decision_equal,"actionChanged":changed,"before":old["action"],"after":new["action"],"beforeValues":old["decision"].get("actionValues"),"afterValues":new["decision"].get("actionValues"),"beforeTotal":left["total"],"afterTotal":right["total"],"outcomeComplete":left["outcomeComplete"],"inputHash":digest(old["input"])})
jsonl(root/"action-drift-dev.jsonl",rows)
report={"scope":"Read-only diagnosis of the already measured original Dev; no fitting or Test. Compare identical initial observations and action inputs, with unchanged value-head tensors.","testUsed":False,"trainingPerformed":False,"checkpointHashes":{k:file_hash(v) for k,v in paths.items()},"valueHeadHashes":heads,"cases":len(rows),"sameSemanticState":sum(r["semanticStateEqual"] for r in rows),"sameActionInput":sum(r["actionInputHashEqual"] for r in rows),"changedFirstActions":sum(r["actionChanged"] for r in rows),"newHoldInsteadOfRequest":sum(r["actionChanged"] and r["after"]=="hold" for r in rows),"rawHash":file_hash(root/"action-drift-dev.jsonl")}
write(root/"action-drift-dev.json",report)
print(report,flush=True)
