import copy
import hashlib
import importlib.util
import math
import subprocess
import time
from collections import defaultdict
from pathlib import Path
from unittest.mock import patch

from newsvendor import structured_forecast, structured_rollout
from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.construction import parameter_record
from newsvendor.corpus import SLOTS
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_retail import parameter_metrics

root = Path(__file__).resolve().parent
require(not (root / "report.json").exists(), "Preserve previous audit")
parent = "1654e770724c37cce29db7e95fb7224f47ea3c47"

def previous(name):
    path = root / ("before-" + name + ".py")
    path.write_bytes(subprocess.run(["git", "show", parent + ":src/newsvendor/" + name + ".py"], check=True, capture_output=True).stdout)
    spec = importlib.util.spec_from_file_location("newsvendor._before_" + name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

old_forecast = previous("structured_forecast")
old_rollout = previous("structured_rollout")
old_rollout.structured_forecast = old_forecast

class FrozenPredictions:
    def eval(self):
        return self

    def __call__(self, view):
        return {}


def replay(module, forecast_module, value, original):
    retrieval = original["retrieval"]
    view = {k: retrieval[k] for k in ("indexedChunks", "selectedChunks")}
    with patch.object(module, "prepare", return_value=view), patch.object(module, "extract", side_effect=lambda *args: copy.deepcopy(original["rawFields"])), patch.object(forecast_module, "predict", side_effect=lambda *args: copy.deepcopy(original.get("forecast"))):
        return module.ResearchRouter(FrozenPredictions(), None, {}).construct(value)


groups = []
inputs = lines("results/research-checks/parameter-contrast/inputs.jsonl")
raw = lines("results/research-checks/parameter-contrast/raw.jsonl")
require(len(inputs) == len(raw), "Initial diagnostic size changed")
groups.append(("initial_train", [(x["input"], r, r["condition"]) for x,r in zip(inputs,raw,strict=True)]))
inputs = lines("results/parameter-contrasts-v2/held.jsonl")
for name in ("parent", "control_selected", "prefix_selected"):
    records = lines("results/l40s-parameter-scope-held-v1/" + name + ".jsonl")
    require(len(inputs) == len(records), "Held diagnostic size changed")
    groups.append(("held_" + name, [(x["input"],r,r["contrast"]) for x,r in zip(inputs,records,strict=True)]))
for name,path in (
    ("parent", "results/l40s-research-scope-v1/control/42/initial"),
    ("control", "results/l40s-research-scope-v1/control/42/final"),
    ("prefix", "results/l40s-research-scope-v1/prefix/42/final"),
):
    rows=[]
    for cohort in ("dev", "generated-dev"):
        for record in lines(path + "-" + cohort + "-learned.jsonl"):
            require(record["split"] == "dev", "Non-Dev retention record")
            for event in record["events"]:
                rows.append((event["input"], {"id":record["id"],"family":record["family"],"state":event["state"]}, cohort))
    groups.append(("dev_" + name,rows))
write(root / "registered.json", {"scope":"Replay identical saved raw neural predictions and forecasts through old/new acceptance code; no new model inference, training or Test. Exact replay of old accepted states is required before counterfactual checks.","parentCommit":parent,"source":provenance({}),"scriptHash":file_hash(__file__),"groups":{n:len(r) for n,r in groups},"testUsed":False})
started=time.perf_counter()
report={"scope":"Fixed-prediction acceptance replay, not a learned extraction improvement or new sequential rollout", "testUsed":False,"source":provenance({}),"groups":{}}
for name,rows in groups:
    raw=[];counts=defaultdict(lambda:defaultdict(int))
    for index,(value,row,condition) in enumerate(rows):
        original=row["state"]
        before=replay(old_rollout,old_forecast,value,original)
        require(before == original, "Historical replay mismatch: " + name + "/" + str(index))
        after=replay(structured_rollout,structured_forecast,value,original)
        require(before["rawFields"] == after["rawFields"], "Raw neural predictions changed")
        expected=parameter_record(value)
        metrics={}
        for label,state in (("before",before),("after",after)):
            measured=parameter_metrics(value,state)
            wrong=sum(slot in state["values"] and (slot not in expected["values"] or not math.isclose(state["values"][slot],expected["values"][slot],rel_tol=1e-7,abs_tol=1e-7)) for slot in SLOTS)
            metrics[label]={"valueErrors":round(4*(1-measured["parameterAccuracy"])),"stateErrors":round(4*(1-measured["stateAccuracy"])),"acceptedWrong":wrong,"unresolved":sum(s not in state["values"] for s in SLOTS)}
        changed=before!=after
        for group in ("all",condition):
            counts[group]["states"]+=1;counts[group]["changedStates"]+=changed
            for label,values in metrics.items():
                for k,v in values.items():counts[group][label+"_"+k]+=v
        raw.append({"id":row["id"],"family":row["family"],"condition":condition,"inputHash":digest(value),"beforeHash":digest(before),"after":after,"metrics":metrics,"changed":changed})
        if (index+1)%128==0:print({"group":name,"processed":index+1,"total":len(rows)},flush=True)
    jsonl(root/(name+".jsonl"),raw)
    report["groups"][name]={"counts":dict(counts),"rawHash":file_hash(root/(name+".jsonl")),"oldStateReplayExact":True,"rawPredictionsUnchanged":True}
    write(root/"partial.json",report)
    print({"group":name,"result":report["groups"][name]["counts"]["all"]},flush=True)
report["seconds"]=time.perf_counter()-started
write(root/"report.json",report)
