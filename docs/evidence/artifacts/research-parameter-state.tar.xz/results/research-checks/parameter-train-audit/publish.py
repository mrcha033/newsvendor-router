import copy
import io
import tarfile
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import digest, read, require, write

audit = Path(__file__).parent
study = Path("results/l40s-parameter-state-v1")
dev = Path("results/l40s-parameter-state-dev-v1")
train_report = read(study / "report.json")
dev_report = read(dev / "report.json")
source_hash = provenance({})["sourceHash"]

# The inference study finished before the optional training-replay connection changed.
# Preserve its exact earlier core source, plus its registered evaluation entry point.
with tarfile.open(study / "source.tar.gz", "r:gz") as old:
    with tarfile.open(dev / "source.tar.gz", "w:gz") as archive:
        for member in old.getmembers():
            if member.name.startswith("src/"):
                data = old.extractfile(member).read()
                require(digest(data) == dev_report["provenance"]["sources"][member.name], "Wrong historical source")
                archive.addfile(member, io.BytesIO(data))
        for path in [Path("scripts/evaluate_parameter_state.py"), Path("configs/research-parameter-state-dev-v1.json")]:
            archive.add(path, arcname=str(path))

checks = {
    "tests": {"passed": 257, "seconds": 28.57, "logHash": digest((audit / "tests-final.log").read_bytes())},
    "ruff": {"passed": True, "formatFiles": 82},
    "sourceChecks": read(audit / "source-checks.json"),
    "numericalSmoke": read("results/smoke.json"),
    "researchCheck": read(audit / "data-check/manifest.json"),
    "currentSourceHash": source_hash,
    "studySourceHash": train_report["provenance"]["sourceHash"],
    "integration": "Core train runner now passes constructionReplay to research_cases; only registered Train rows, with model-visible deduplication. Default no-replay cases remain unchanged. No full encoder retraining after this connection is claimed.",
}
write(audit / "checks.json", checks)

result = {
    "scope": "Observed Train state diagnosis and state-head-only fitting; original Dev sequential comparison; no frozen Test reuse, no model promotion",
    "testUsed": False,
    "modelReplacementMade": False,
    "retainedCheckpoint": train_report["plan"]["checkpoint"],
    "retainedCheckpointHash": train_report["plan"]["files"][train_report["plan"]["checkpoint"]],
    "diagnostic": read(audit / "report.json"),
    "trainingExposure": read(audit / "exposure.json"),
    "study": {k: copy.deepcopy(train_report[k]) for k in ["scope", "testUsed", "devUsed", "provenance", "scriptHash", "statesHash", "statuses", "groups", "initial", "selectedEpoch", "finalTrain", "parentWeightsHash", "parentStateHash", "headWeightsHash", "seconds", "peakGpuBytes"]},
    "dev": dev_report,
    "checks": checks,
    "decision": {
        "adopted": False,
        "reason": "Learned-policy generated/retail totals and request outcomes do not improve; checklist generated response states improve, but one new intermediate state error appears in learned retail. Retain the parent despite lower Train errors.",
        "observedGeneratedChecklistResponseErrors": {"before": 11, "after": 8, "fields": 232},
        "observedRetailLearnedResponseErrors": {"before": 0, "after": 1, "fields": 1152},
    },
    "limitations": [
        "The encoder was previously trained on all Train sources. The source-held partition is a validation set for this head fit, not an independently held model effectiveness cohort.",
        "Only one head-fit seed and the preexisting small original Dev were measured. No general economic advantage is established.",
        "Controlled financial documents and manager replies are generated and do not establish real organizational effectiveness.",
        "The replay connection is covered by regression tests but full encoder retraining after it is not included in this report.",
        "Head weights and raw representations are published; full parent ModernBERT weights are still required for end-to-end model inference.",
    ],
}
result["study"]["partitions"] = {k: {n: v[n] for n in ["states", "families"]} for k,v in train_report["partitions"].items()}
result["study"]["selectedHeld"] = train_report["curve"][train_report["selectedEpoch"] - 1]
paths = [p for root in [study, dev] for p in sorted(root.iterdir()) if p.is_file()]
paths += [audit / name for name in ["audit.py", "raw.jsonl", "errors.json", "report.json", "exposure.py", "exposure.json", "exposure.log", "study.log", "dev.log", "tests-final.log", "source-checks.json", "smoke.log", "checks.json", "publish.py"]]
paths += [Path(p) for p in ["scripts/study_parameter_state.py", "scripts/evaluate_parameter_state.py", "scripts/run_research.py", "src/newsvendor/structured_train.py", "tests/test_parameter_state.py", "configs/l40s-parameter-state-v1.json", "configs/research-parameter-state-dev-v1.json"]]
paths = [p.relative_to(Path.cwd()) if p.is_absolute() else p for p in paths]
hashes = {str(p): {"sha256": digest(p.read_bytes()), "bytes": p.stat().st_size} for p in paths}
archive_path = Path("docs/evidence/artifacts/research-parameter-state.tar.xz")
require(not archive_path.exists(), "Preserve published study")
with tarfile.open(archive_path, "w:xz", preset=3) as archive:
    for path in paths:
        archive.add(path, arcname=str(path))
with tarfile.open(archive_path, "r:xz") as archive:
    require(set(archive.getnames()) == set(hashes), "Archive members differ")
    for name, info in hashes.items():
        require(digest(archive.extractfile(name).read()) == info["sha256"], "Archive hash differs")
result["publishedRaw"] = {"path": str(archive_path), "sha256": digest(archive_path.read_bytes()), "bytes": archive_path.stat().st_size, "files": hashes, "verified": True}
write("docs/evidence/research-parameter-state-results.json", result)
write(audit / "published-audit.json", {"allHashesVerified": True, "files": len(paths), "archiveHash": result["publishedRaw"]["sha256"], "archiveBytes": archive_path.stat().st_size})
print({"files": len(paths), "archiveBytes": archive_path.stat().st_size, "modelPromoted": False, "sourceHash": source_hash})
