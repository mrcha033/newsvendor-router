from collections import Counter
from pathlib import Path

from newsvendor.construction import parameter_record
from newsvendor.io import digest, lines, write
from newsvendor.structured_inputs import research_input
from newsvendor.structured_train import research_cases

root = Path(__file__).parent
parent = Path("results/l40s-research-replay-v1/base/42")
episodes = []
for name, envname in [("inputs.jsonl", "environment.jsonl"), ("generated-inputs.jsonl", "generated-environment.jsonl")]:
    environment = {r["id"]: r for r in lines(parent / envname)}
    for row in lines(parent / name):
        if row["split"] != "train":
            continue
        episode = {**row, **environment[row["id"]]}
        if name == "inputs.jsonl":
            source, cutoff, scenario = row["id"].rsplit(":", 2)
            episode.update(sourceId=source, cutoffIndex=int(cutoff), scenario=scenario)
        episodes.append(episode)
known, counts = {}, Counter()
for mode, row in research_cases(episodes):
    value = row["input"]
    key = digest([row["family"], research_input(value)])
    known[key] = row["id"]
    benchmark = "retail" if "forecast" in value["task"] else "generated"
    for status in parameter_record(value)["state"].values():
        counts[benchmark + ":" + status] += 1
states = {r["inputHash"]: r for r in lines("results/l40s-parameter-state-v1/states.jsonl")}
exposure = Counter()
for row in lines("results/l40s-parameter-state-v1/predictions.jsonl"):
    key = row["inputHash"]
    source = states[key]
    group = f"{source['benchmark']}:{'seen' if key in known else 'unseen'}"
    exposure[group + ":states"] += 1
    exposure[group + ":initialErrors"] += sum(a != b for a,b in zip(row["target"], row["initial"], strict=True))
report = {
    "scope": "Original language research cases reconstructed using archived observed inputs and response environment; the error cohort is Train only",
    "originalTrainResearchStates": len(known),
    "targetCounts": dict(counts),
    "rolloutExposure": dict(exposure),
}
write(root / "exposure.json", report)
print(report)
