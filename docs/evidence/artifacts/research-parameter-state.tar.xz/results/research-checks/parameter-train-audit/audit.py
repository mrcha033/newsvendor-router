import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from newsvendor.construction import parameter_record
from newsvendor.corpus import SLOTS
from newsvendor.io import digest
from newsvendor.structured_retail import parameter_metrics

root = Path(__file__).parent
paths = [Path(f"results/l40s-research-replay-v1/base/42/rollout-train-{i}.jsonl") for i in range(2)]
seen = set()
counts = Counter()
errors = []
sources = defaultdict(set)
raw = []
for path in paths:
    for line in path.open():
        row = json.loads(line)
        assert row["split"] == "train"
        for step, event in enumerate(row["events"]):
            value, state = event["input"], event["state"]
            key = digest([row["family"], value])
            if key in seen:
                continue
            seen.add(key)
            benchmark = "retail" if "forecast" in value["task"] else "generated"
            phase = "response" if value["history"] else "initial"
            group = f"{benchmark}:{phase}"
            sources[group].add(row["family"])
            counts[group + ":states"] += 1
            reference = parameter_record(value)
            fields = {f["name"]: f for f in state.get("rawFields", [])}
            metrics = parameter_metrics(value, state)
            raw.append({"id": row["id"], "family": row["family"], "inputHash": key, "group": group, "metrics": metrics})
            for slot in SLOTS:
                expected = reference["values"].get(slot)
                actual = state["values"].get(slot)
                issues = []
                value_ok = actual is None if expected is None else actual is not None and math.isclose(actual, expected, rel_tol=1e-7, abs_tol=1e-7)
                if not value_ok:
                    issues.append("value")
                if reference["state"][slot] != state["state"].get(slot):
                    issues.append("state")
                if reference["types"][slot] != state["types"].get(slot):
                    issues.append("type")
                if expected is not None and reference["expressions"][slot] != state["expressions"].get(slot):
                    issues.append("evidence")
                for issue in issues:
                    counts[f"{group}:{slot}:{issue}"] += 1
                if issues:
                    errors.append({"id": row["id"], "family": row["family"], "inputHash": key, "group": group, "slot": slot, "issues": issues, "history": value["history"], "docs": value["docs"], "expected": {"value": expected, "state": reference["state"][slot], "expression": reference["expressions"].get(slot)}, "predicted": {"value": actual, "state": state["state"].get(slot), "expression": state["expressions"].get(slot), "raw": fields.get(slot)}, "source": str(path), "step": step})
report = {"scope": "Deduplicated observed Train states from archived actual rollouts; no new inference or effectiveness measurement", "testUsed": False, "devUsed": False, "states": len(seen), "counts": dict(counts), "families": {k: len(v) for k,v in sources.items()}, "slotErrors": len(errors)}
for name, content in (("errors.json", errors), ("report.json", report)):
    (root / name).write_text(json.dumps(content, indent=2) + "\n")
(root / "raw.jsonl").write_text("".join(json.dumps(r) + "\n" for r in raw))
print(json.dumps(report, indent=2))
for error in errors[:12]:
    print(json.dumps({k:v for k,v in error.items() if k not in ("docs", "predicted") } | {"predicted": error["predicted"]}))
