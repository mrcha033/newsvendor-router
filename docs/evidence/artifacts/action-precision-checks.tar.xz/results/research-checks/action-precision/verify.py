"""Verify full L40S action-head inference matches cached FP32 for saved Train states."""
import time
from pathlib import Path
import torch
from torch.nn import functional as fn
from newsvendor.io import lines,write,jsonl,digest,require
from newsvendor.cli import provenance
from newsvendor.structured_train import load
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_value import constrain
from newsvendor.train import seed
seed(42);torch.set_num_threads(8)
root=Path('results/research-checks/action-precision/fp32');root.mkdir(parents=True,exist_ok=True)
parent=Path('results/l40s-research-numeric-v1/value/42/model.pt')
candidate=Path('results/l40s-research-numeric-v1/value/42/policy-candidate-0-9.pt')
source=Path('results/l40s-research-replay-v1/base/42/value-targets-0.jsonl')
rows=lines(source);require(all(r['split']=='train' for r in rows),'Train only')
original=torch.load('results/research-checks/action-precision/train-features.pt',weights_only=True)
model,tok,config,_=load(parent,'cuda');config['encoder']['actionPrecision']='float32'
router=ResearchRouter(model,tok,config['encoder'])
record={'scope':'Actual L40S inference/cached arithmetic, same 928 Train states and unchanged weights; not a policy performance evaluation','testUsed':False,'devUsed':False,'source':provenance(config),'parentHash':digest(parent.read_bytes()),'candidateHash':digest(candidate.read_bytes()),'trainHash':digest(source.read_bytes()),'scriptHash':digest(Path(__file__).read_bytes()),'hardware':{'name':torch.cuda.get_device_name(),'uuid':str(torch.cuda.get_device_properties(0).uuid)},'models':{}}
require(record['hardware']['uuid'].removeprefix('GPU-')=='674d64b8-4bdf-7006-1791-5dc7f7245409','Wrong GPU')
views=[router.view(r['input'],r['state']) for r in rows]
start=time.perf_counter()
with torch.inference_mode():
 for name in ['inherited','candidate']:
  if name=='candidate':model.heads['value'].load_state_dict(torch.load(candidate,map_location='cuda',weights_only=True)['weights'])
  raw=[]
  for offset in range(0,len(rows),32):
   outputs=model(views[offset:offset+32])
   for i,out in enumerate(outputs,offset):
    row,view=rows[i],views[i];x=out['actionState']
    require(torch.equal(x[:,:256].cpu(),original[i]['features'][:,:256]),'Encoder/fusion representation changed')
    expected=x.new_tensor(view['economicFeatures']);require(torch.equal(x[:,256:],expected),'Numeric input rounded')
    cached=constrain(fn.softplus(model.heads['value'](x)),view['valueCosts'])
    require(torch.equal(cached,out['value']),'Inference/cached value mismatch')
    recovery=model.heads['recovery'](x).flatten().masked_fill(~torch.tensor(view['allowedActions'],device='cuda'),-1e9)
    require(torch.equal(recovery,out['recovery']),'Inference/cached recovery mismatch')
    raw.append({'id':row['id'],'family':row['family'],'actions':view['actions'],'numericMaxError':float((x[:,256:]-expected).abs().max()),'scoreMaxError':float((cached-out['value']).abs().max()),'inference':out['value'].cpu().tolist(),'cachedFp32':cached.cpu().tolist(),'action':view['actions'][int(cached.sum(-1).argmin())]})
  jsonl(root/f'{name}.jsonl',raw)
  record['models'][name]={'states':len(raw),'numericMaxError':max(r['numericMaxError'] for r in raw),'scoreMaxError':max(r['scoreMaxError'] for r in raw),'encoderAndFusionIdentical':True,'valueAndRecoveryMatchCachedTraining':True,'rawHash':digest((root/f'{name}.jsonl').read_bytes())}
  print({name:record['models'][name]},flush=True)
record['seconds']=time.perf_counter()-start;write(root/'checks.json',record)
