"""Train-only L40S probe of actual action inputs and cached critic precision."""
import time
from collections import Counter
from pathlib import Path
import torch
from torch.nn import functional as fn
from newsvendor.io import read,lines,write,jsonl,digest,require
from newsvendor.cli import provenance
from newsvendor.structured_train import load
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_value import constrain
from newsvendor.train import seed
seed(42)
torch.set_num_threads(8)
root=Path('results/research-checks/action-precision')
parent=Path('results/l40s-research-numeric-v1/value/42/model.pt')
candidate=Path('results/l40s-research-numeric-v1/value/42/policy-candidate-0-9.pt')
source=Path('results/l40s-research-replay-v1/base/42/value-targets-0.jsonl')
rows=lines(source); require(all(r['split']=='train' for r in rows),'Train only')
model,tok,config,_=load(parent,'cuda')
router=ResearchRouter(model,tok,config['encoder'])
record={'scope':'Train-only actual model-input and action-head arithmetic; no rollout performance claim','testUsed':False,'devUsed':False,'source':provenance(config),'trainHash':digest(source.read_bytes()),'parentHash':digest(parent.read_bytes()),'candidateHash':digest(candidate.read_bytes()),'hardware':{'name':torch.cuda.get_device_name(),'uuid':str(torch.cuda.get_device_properties(0).uuid)},'scriptHash':digest(Path(__file__).read_bytes())}
require(record['hardware']['uuid'].removeprefix('GPU-')=='674d64b8-4bdf-7006-1791-5dc7f7245409','Wrong GPU')
dtypes=Counter();features=[];raw=[]
def capture(module,args): dtypes[str(args[0].dtype)]+=1
hook=model.heads['value'].register_forward_pre_hook(capture)
start=time.perf_counter()
with torch.inference_mode():
 for offset in range(0,len(rows),32):
  group=rows[offset:offset+32];views=[router.view(r['input'],r['state']) for r in group]
  for lo,hi in model.training_batches(views):
   outputs=model(views[lo:hi])
   for r,v,out in zip(group[lo:hi],views[lo:hi],outputs,strict=True):
    x=out['actionState'];expected=x.new_tensor(v['economicFeatures']); costs=v['valueCosts']
    with torch.autocast('cuda',enabled=False): cached=constrain(fn.softplus(model.heads['value'](x)),costs)
    with torch.autocast('cuda',dtype=torch.bfloat16): same=constrain(fn.softplus(model.heads['value'](x).float()),costs)
    require(torch.equal(same,out['value']),'BF16 cached reconstruction differs from real inference')
    data={'id':r['id'],'family':r['family'],'split':r['split'],'actions':v['actions'],'features':x.cpu(),'costs':costs}
    features.append(data)
    raw.append({'id':r['id'],'family':r['family'],'numericMaxError':float((x[:,256:]-expected).abs().max()),'numericEqualsBf16Cast':torch.equal(x[:,256:],expected.bfloat16().float()),'inference':out['value'].cpu().tolist(),'cachedFp32':cached.cpu().tolist(),'maxError':float((cached-out['value']).abs().max()),'inferenceAction':v['actions'][int(out['value'].sum(-1).argmin())],'cachedAction':v['actions'][int(cached.sum(-1).argmin())]})
  if (offset+32)%128==0: print({'processed':min(offset+32,len(rows))},flush=True)
hook.remove()
record['valueHeadInputDtypes']=dict(dtypes)
# Raw input hooks include the two explicit cached arithmetic probes for each case.
record['inherited']={'states':len(raw),'numericFp32Mismatches':sum(r['numericMaxError']>0 for r in raw),'numericMaxError':max(r['numericMaxError'] for r in raw),'allNumericInputsMatchBf16Cast':all(r['numericEqualsBf16Cast'] for r in raw),'scoreMaxError':max(r['maxError'] for r in raw),'argminDifferences':sum(r['inferenceAction']!=r['cachedAction'] for r in raw)}
jsonl(root/'inherited.jsonl',raw)
torch.save(features,root/'train-features.pt')
model.heads['value'].load_state_dict(torch.load(candidate,map_location='cuda',weights_only=True)['weights'])
raw=[]
with torch.inference_mode():
 for row in features:
  x=row['features'].cuda();costs=row['costs']
  with torch.autocast('cuda',enabled=False): full=constrain(fn.softplus(model.heads['value'](x)),costs)
  with torch.autocast('cuda',dtype=torch.bfloat16): mixed=constrain(fn.softplus(model.heads['value'](x).float()),costs)
  raw.append({'id':row['id'],'family':row['family'],'inference':mixed.cpu().tolist(),'cachedFp32':full.cpu().tolist(),'maxError':float((full-mixed).abs().max()),'inferenceAction':row['actions'][int(mixed.sum(-1).argmin())],'cachedAction':row['actions'][int(full.sum(-1).argmin())]})
jsonl(root/'candidate.jsonl',raw)
record['candidate']={'states':len(raw),'scoreMaxError':max(r['maxError'] for r in raw),'argminDifferences':sum(r['inferenceAction']!=r['cachedAction'] for r in raw)}
record['seconds']=time.perf_counter()-start
record['rawHashes']={n:digest((root/n).read_bytes()) for n in ['inherited.jsonl','candidate.jsonl','train-features.pt']}
write(root/'before.json',record)
print({k:record[k] for k in ['inherited','candidate','valueHeadInputDtypes','seconds']},flush=True)
