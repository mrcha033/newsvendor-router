"""Separate untrained action-head arithmetic from the learned correction on original Dev."""

import copy
import gzip
import json
import os
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import CachedRouter, file_hash

from newsvendor import structured_train
from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import lines, read, require, write
from newsvendor.structured_metrics import generated_metrics
from newsvendor.structured_rollout import rollout
from newsvendor.structured_tool_eval import weights_hash


def main():
    plan = read("results/research-checks/recovery-stability/precision-plan.json")
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    require(file_hash(__file__) == plan["scriptHash"], "Diagnostic source changed")
    require(provenance({})["sourceHash"] == plan["sourceHash"], "Package source changed")
    for path, expected in plan["files"].items():
        require(file_hash(path) == expected, "Pinned diagnostic asset changed")
    root = Path(plan["output"])
    require(not root.exists(), "Preserve diagnostic")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    observed = lines(Path(plan["cohort"]) / "inputs.jsonl")
    environment = {r["id"]: r for r in lines(Path(plan["cohort"]) / "environment.jsonl")}
    episodes = [r | environment[r["id"]] for r in observed]
    require(len(episodes) == 60 and all(e["split"] == "dev" for e in episodes), "Original Dev only")
    model, tokenizer, config, _ = structured_train.load(plan["checkpoint"], "cuda")
    model.requires_grad_(False).eval()
    original_weights = weights_hash(model.state_dict())
    source = Path(plan["reference"])
    with gzip.open(source, "rt") as stream:
        reference = {r["id"]: r for r in map(json.loads, stream)}
    report = {
        "scope": "Existing original Dev arithmetic diagnosis; no fitting, selection, Test or new-source inference.",
        "source": provenance({}),
        "plan": plan,
        "trainingPerformed": False,
        "testUsed": False,
        "results": {},
    }
    write(root / "registered.json", report)
    started = time.perf_counter()
    for mode in ("native", "float32", "padded-float32"):
        if mode != "native":
            model.config["actionPrecision"] = config["encoder"]["actionPrecision"] = "float32"
        if mode == "padded-float32":
            for name in ("value", "recovery"):
                old = model.heads[name]
                weights = copy.deepcopy(old.state_dict())
                weights["layers.0.weight"] = torch.cat(
                    [weights["layers.0.weight"], weights["layers.0.weight"].new_zeros((128, 94))], 1
                )
                head = Head(350, 128, old.layers[-1].out_features).cuda().eval()
                head.load_state_dict(weights)
                model.heads[name] = head
            model.config["numericState"] = config["encoder"]["numericState"] = True
            model.requires_grad_(False).eval()
        else:
            require(
                weights_hash(model.state_dict()) == original_weights,
                "Precision switch changed weights",
            )
        router = CachedRouter(model, tokenizer, config["encoder"])
        router.reset()
        rows = [rollout(e, router) for e in episodes]
        changes = []
        for row in rows:
            old = reference[row["id"]]
            if [e["action"] for e in row["events"]] != [e["action"] for e in old["events"]] or row[
                "total"
            ] != old["total"]:
                changes.append(
                    {
                        "id": row["id"],
                        "before": [e["action"] for e in old["events"]],
                        "after": [e["action"] for e in row["events"]],
                        "oldTotal": old["total"],
                        "newTotal": row["total"],
                    }
                )
        if mode == "native":
            require(not changes, "Native parent did not reproduce")
        with gzip.open(root / f"{mode}.jsonl.gz", "wt", compresslevel=3) as stream:
            for row in rows:
                stream.write(json.dumps(row, allow_nan=False) + "\n")
        report["results"][mode] = {
            "metrics": generated_metrics(rows),
            "changedCases": changes,
            "seconds": time.perf_counter() - started,
        }
        write(root / "partial.json", report)
        print(
            {
                "mode": mode,
                "total": report["results"][mode]["metrics"]["meanTotal"],
                "changes": changes,
            },
            flush=True,
        )
    report["seconds"] = time.perf_counter() - started
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print({"completed": True, "seconds": report["seconds"]}, flush=True)


if __name__ == "__main__":
    main()
