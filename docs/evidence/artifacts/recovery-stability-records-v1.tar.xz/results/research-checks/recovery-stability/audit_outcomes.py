"""Reconcile every saved Train trajectory with inputs, action costs and reported totals."""

import gzip
import importlib.util
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import file_hash

from newsvendor.io import digest, lines, read, require, write
from newsvendor.structured_metrics import generated_metrics

spec = importlib.util.spec_from_file_location(
    "selection_comparison", "results/research-checks/recovery-stability/sequential.py"
)
execution = importlib.util.module_from_spec(spec)
spec.loader.exec_module(execution)
root = Path("/dev/shm/newsvendor-recovery-selected-sequential-v1")
report = read(root / "report.json")
inputs = {r["id"]: r for r in lines(root / "inputs.jsonl")}
require(all(r["split"] == "train" for r in inputs.values()), "Train-only scope differs")
audit = {
    "scope": "All raw Train paths: input/source identity, response draw metadata, costs, terminal decomposition and exact report reconciliation; no new model evaluation.",
    "testUsed": False,
    "devUsed": False,
    "results": {},
    "verifiedRollouts": 0,
}
for name, result in report["results"].items():
    raw = root / f"{name}-rollouts.jsonl.gz"
    require(file_hash(raw) == report["rawHashes"][raw.name], "Raw bytes changed")
    records = lines(root / f"{name}-measurements.jsonl")
    generated, retail, seen = [], {"0": [], "0.1": []}, set()
    with gzip.open(raw, "rt") as stream:
        for measurement, row in zip(records, map(json.loads, stream), strict=True):
            original = inputs[row["id"]]
            require(
                row["split"] == "train" and row["family"] == original["family"], "Source differs"
            )
            require(row["events"][0]["input"] == original["input"], "Initial observation differs")
            draw = digest([report["registration"]["responseSeed"], "sequential", row["sample"]])
            require(row["responseSeed"] == draw, "Response draw changed")
            key = (row["id"], row["sample"])
            require(key not in seen, "Duplicate trajectory")
            seen.add(key)
            cost = 0
            for event in row["events"]:
                value, action = event["input"], event["action"]
                require(
                    not set(value)
                    & {"gold", "responses", "target", "responseSeed", "missingResponses"},
                    "Hidden environment key in model observation",
                )
                if action not in ("hold", "handoff"):
                    cost += 1 if action == "retrieve" else value["task"]["costs"][action]
            require(
                math.isclose(cost, row["requestCost"], abs_tol=1e-9), "Question cost sum differs"
            )
            require(
                math.isclose(row["total"], row["terminalLoss"] + cost, abs_tol=1e-9),
                "Total loss sum differs",
            )
            require(
                row["q"] is None if row["result"] == "hold" else row["q"] is not None,
                "Order/result differ",
            )
            require(
                measurement["actions"] == [e["action"] for e in row["events"]], "Actions differ"
            )
            require(
                all(
                    measurement[k] == row[k]
                    for k in ("q", "result", "total", "terminalLoss", "requestCost", "falseHandoff")
                ),
                "Measurements differ",
            )
            if row["benchmark"] == "generated":
                require(row["sample"] < 4 and row["noise"] == 0, "Generated draw scope differs")
                generated.append(row)
            else:
                require(
                    row["noise"] == (0.1 if row["sample"] < 4 else 0), "Retail draw scope differs"
                )
                retail[str(row["noise"])].append(row)
    gm = generated_metrics(generated)
    gm["meanTerminalLoss"] = sum(r["terminalLoss"] for r in generated) / len(generated)
    expected = result["metrics"]
    require(
        all(gm[k] == v for k, v in expected["generated"].items() if k != "meanTerminalLoss"),
        "Generated report differs",
    )
    require(
        math.isclose(
            gm["meanTerminalLoss"], expected["generated"]["meanTerminalLoss"], abs_tol=1e-9
        ),
        "Terminal mean differs",
    )
    require(
        {k: execution.retail_metrics(v) for k, v in retail.items()} == expected["retail"],
        "Retail report differs",
    )
    require(
        len(generated) == 1440 and len(retail["0"]) == 154 and len(retail["0.1"]) == 616,
        "Cohort size differs",
    )
    audit["results"][name] = {
        "rollouts": len(seen),
        "allInputsAndCostsVerified": True,
        "reportReproduced": True,
    }
    audit["verifiedRollouts"] += len(seen)
    print({"condition": name, "verified": len(seen)}, flush=True)
require(audit["verifiedRollouts"] == report["rawRollouts"] == 15470, "Total rollout count differs")
write("results/research-checks/recovery-stability/outcome-audit.json", audit)
print({"completed": True, "verifiedRollouts": audit["verifiedRollouts"]}, flush=True)
