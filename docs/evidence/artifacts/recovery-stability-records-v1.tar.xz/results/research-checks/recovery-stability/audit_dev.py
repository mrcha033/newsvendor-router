"""Audit raw Dev trajectory inputs, costs, masks and report aggregates."""

import gzip
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import conditions, expectations, file_hash, measurement

from newsvendor import structured_compare
from newsvendor.io import lines, read, require, write
from newsvendor.structured_metrics import generated_metrics

root = Path("/dev/shm/newsvendor-recovery-residual-dev-v1")
report = read(root / "report.json")
inputs = {
    name: {r["id"]: r for r in lines(root / f"{name}-inputs.jsonl")}
    for name in ("generated", "retail")
}
require(
    all(r["split"] == "dev" for group in inputs.values() for r in group.values()),
    "Original Dev only",
)
audit = {
    "scope": "Raw Dev record reconciliation only; no new inference, training or Test use.",
    "testUsed": False,
    "results": {},
    "verifiedRollouts": 0,
}
responses = {}
for name, result in report["results"].items():
    generated, retail = [], []
    counts = {}
    for benchmark in ("generated", "retail"):
        path = root / f"{name}-{benchmark}.jsonl.gz"
        require(file_hash(path) == report["rawHashes"][path.name], "Raw bytes differ")
        seen = set()
        with gzip.open(path, "rt") as stream:
            for row in map(json.loads, stream):
                original = inputs[benchmark][row["id"]]
                require(
                    row["split"] == "dev" and row["family"] == original["family"], "Source differs"
                )
                require(
                    row["events"][0]["input"] == original["input"], "Initial observation differs"
                )
                missing = tuple(row.get("missingResponses", []))
                key = (row["id"], missing)
                require(key not in seen, "Duplicate raw condition")
                seen.add(key)
                if benchmark == "retail":
                    require(missing in conditions(0), "Unexpected response mask")
                cost = 0.0
                for event in row["events"]:
                    value, action = event["input"], event["action"]
                    require(
                        not set(value)
                        & {"gold", "responses", "target", "missingResponses", "responseSeed"},
                        "Hidden condition in observation",
                    )
                    if action in ("hold", "handoff"):
                        continue
                    cost += 1 if action == "retrieve" else value["task"]["costs"][action]
                    if benchmark == "retail" and action != "retrieve":
                        channel = (row["id"], missing, action)
                        answer = event["observedResponse"]
                        require(
                            channel not in responses or responses[channel] == answer,
                            "Policies saw different channel responses",
                        )
                        require(
                            action not in missing or answer is None, "Unavailable channel responded"
                        )
                        responses[channel] = answer
                require(
                    math.isclose(cost, row["requestCost"], abs_tol=1e-9), "Request costs differ"
                )
                if row["terminalLoss"] is None:
                    require(row["total"] is None, "Censored loss represented as exact")
                else:
                    require(
                        math.isclose(row["total"], row["terminalLoss"] + cost, abs_tol=1e-9),
                        "Loss decomposition differs",
                    )
                require(
                    row["q"] is None if row["result"] == "hold" else row["q"] is not None,
                    "Order/result differ",
                )
                if benchmark == "generated":
                    generated.append(row)
                else:
                    retail.append(measurement(row) | {"missingResponses": list(missing)})
        require(
            len(seen) == len(inputs[benchmark]) * (16 if benchmark == "retail" else 1),
            "Incomplete cohort",
        )
        counts[benchmark] = len(seen)
    require(generated_metrics(generated) == result["generated"], "Generated report differs")
    require(
        retail == lines(root / f"{name}-retail-measurements.jsonl"), "Raw measurement file differs"
    )
    expected = {str(rate): expectations(retail, rate) for rate in (0, 0.1, 0.2)}
    require(expected == read(root / f"{name}-retail-expectations.json"), "Expected metrics differ")
    require(
        {k: structured_compare.means(v) for k, v in expected.items()} == result["retail"],
        "Reported retail aggregate differs",
    )
    audit["results"][name] = {
        "rawCounts": counts,
        "allInputsCostsAndMasksVerified": True,
        "reportReproduced": True,
    }
    audit["verifiedRollouts"] += sum(counts.values())
    print({"condition": name, "verified": counts}, flush=True)
require(audit["verifiedRollouts"] == report["rawRollouts"] == 32616, "Missing raw outcomes")
audit["pairedObservedChannels"] = len(responses)
write("results/research-checks/recovery-stability/dev-audit.json", audit)
print({"completed": True, "verifiedRollouts": audit["verifiedRollouts"]}, flush=True)
