"""Replay saved Train updates to locate when full refitting loses recovery decisions."""

import copy
import os
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import file_hash
from study_recovery_replay import scores

from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import jsonl, lines, read, require, write
from newsvendor.structured_critic import value_loss
from newsvendor.structured_tool_eval import weights_hash


def main():
    require(
        os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409",
        "Assigned L40S only",
    )
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    root = Path("/dev/shm/newsvendor-recovery-stability-trace-v1")
    require(not root.exists(), "Preserve previous diagnostics")
    root.mkdir()
    prior = Path("/dev/shm/newsvendor-recovery-balanced-refit-v1")
    payload_path = Path("/dev/shm/newsvendor-recovery-numeric-v1/features.pt")
    rows_path = Path("/dev/shm/newsvendor-recovery-replay-v1/targets.jsonl")
    report = read(prior / "report.json")
    require(provenance({})["sourceHash"] == report["source"]["sourceHash"], "Source changed")
    rows = lines(rows_path)
    require(all(r["split"] == "train" for r in rows), "Train only")
    payload = torch.load(payload_path, map_location="cpu", weights_only=True)
    features = [(x.cuda(), y.cuda(), c) for x, y, c in payload["features"]]
    failures = [
        i
        for i, r in enumerate(rows)
        if r["benchmark"] == "retail"
        and len(r["actions"]) > 1
        and "unavailable" in r["state"]["state"].values()
    ]
    require(len(failures) == 6, "Original diagnostic states changed")
    output = {
        "scope": "Exact replay of preserved full-Train updates with new intermediate diagnostics. No candidate selection or Dev/Test inference.",
        "source": provenance({}),
        "devUsed": False,
        "testUsed": False,
        "plan": report["plan"],
        "scriptHash": file_hash(__file__),
        "files": {str(p): file_hash(p) for p in (payload_path, rows_path, prior / "report.json")},
        "failureStates": [
            {k: rows[i][k] for k in ("id", "family", "inputHash", "actions", "values")}
            for i in failures
        ],
        "results": {},
    }
    write(root / "registered.json", output)
    head = Head(350, 128, 2).cuda().eval()

    @torch.no_grad()
    def diagnostic():
        predictions, choices, saturation, encoded, numeric = [], [], [], [], []
        for i in failures:
            x = features[i][0]
            estimate = scores(head, features[i]).sum(-1)
            predictions.append(estimate.tolist())
            choices.append(rows[i]["actions"][int(estimate.argmin())])
            saturation.append(float((head.layers[0](x).tanh().abs() > 0.99).float().mean()))
            encoded.append(float((x[:, :256] @ head.layers[0].weight[:, :256].T).abs().mean()))
            numeric.append(float((x[:, 256:] @ head.layers[0].weight[:, 256:].T).abs().mean()))
        return {
            "estimates": predictions,
            "choices": choices,
            "holds": choices.count("hold"),
            "tanhSaturation": saturation,
            "encodedPreactivationAbsMean": encoded,
            "numericPreactivationAbsMean": numeric,
        }

    started = time.perf_counter()
    for random_seed in (42, 43, 44):
        name = f"balanced-{random_seed}"
        batch_path = prior / f"{name}-batches.json"
        saved_path = prior / f"{name}.pt"
        require(file_hash(batch_path) == report["rawHashes"][batch_path.name], "Batches changed")
        require(file_hash(saved_path) == report["rawHashes"][saved_path.name], "Checkpoint changed")
        batches = read(batch_path)
        saved = torch.load(saved_path, map_location="cpu", weights_only=True)
        head.load_state_dict(payload["initial"])
        optimizer = torch.optim.AdamW(head.parameters(), lr=0.001, weight_decay=0.01, fused=True)
        selected_step = saved["selectedEpoch"] * report["updatesPerEpoch"]
        matched_step = saved["selectedEpoch"] * 15
        trace = [{"step": 0, **diagnostic()}]
        selected_exact, final_exact = False, False
        losses = []
        for step, batch in enumerate(batches, 1):
            optimizer.zero_grad(set_to_none=True)
            loss = value_loss(head, [features[i] for i in batch], 0.25)
            require(torch.isfinite(loss).item(), "Nonfinite replay loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(), 5, error_if_nonfinite=True)
            optimizer.step()
            losses.append(float(loss.detach()))
            if step % report["updatesPerEpoch"] == 0 or step in (matched_step, selected_step):
                trace.append({"step": step, "lastBatchLoss": losses[-1], **diagnostic()})
            if step == selected_step:
                selected_exact = weights_hash(head.state_dict()) == weights_hash(saved["weights"])
                require(selected_exact, "Saved selected weights did not reproduce exactly")
            if step == matched_step:
                torch.save(
                    {
                        "weights": copy.deepcopy(head.state_dict()),
                        "optimizer": optimizer.state_dict(),
                        "step": step,
                    },
                    root / f"{name}-matched-updates.pt",
                )
        final_exact = weights_hash(head.state_dict()) == weights_hash(saved["finalWeights"])
        require(final_exact, "Saved final weights did not reproduce exactly")
        jsonl(root / f"{name}-trace.jsonl", trace)
        write(root / f"{name}-losses.json", losses)
        output["results"][name] = {
            "selectedExact": selected_exact,
            "finalExact": final_exact,
            "selectedStep": selected_step,
            "innerUpdateCount": matched_step,
            "holdsAcrossEpochs": [r["holds"] for r in trace if r["step"] % 19 == 0],
            "holdsAtMatchedUpdates": next(r["holds"] for r in trace if r["step"] == matched_step),
            "holdsAtSelectedStep": next(r["holds"] for r in trace if r["step"] == selected_step),
            "final": trace[-1],
        }
        write(root / "partial.json", output)
        print(
            {
                "seed": random_seed,
                **{k: v for k, v in output["results"][name].items() if k != "final"},
            },
            flush=True,
        )
    output["seconds"] = time.perf_counter() - started
    output["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", output)
    print({"completed": True, "seconds": output["seconds"]}, flush=True)


if __name__ == "__main__":
    main()
