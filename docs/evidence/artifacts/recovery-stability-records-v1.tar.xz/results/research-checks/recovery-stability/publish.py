"""Preserve the negative numeric-residual comparison and every measured trajectory."""

import importlib.util
from pathlib import Path

from newsvendor.io import read, write

spec = importlib.util.spec_from_file_location(
    "prior_publication", "results/research-checks/recovery-balance/publish.py"
)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
publish, raw_entries = prior.publish, prior.raw_entries


def compact(report):
    result = {k: v for k, v in report.items() if k != "rawHashes"}
    for stage in ("inner", "refit"):
        if stage not in result:
            continue
        result[stage] = {
            seed: {
                k: {a: b for a, b in value.items() if a != "selectedActions"}
                if k in ("selected", "fit")
                else value
                for k, value in run.items()
                if k != "epochs"
            }
            for seed, run in result[stage].items()
        }
    return result


def main():
    checks = Path("results/research-checks/recovery-stability")
    names = ("stability-trace", "residual", "selected-sequential", "residual-dev", "precision")
    roots = {name: Path(f"/dev/shm/newsvendor-recovery-{name}-v1") for name in names}
    destinations = {name: f"results/l40s-recovery-{name}-v1" for name in names}
    reports = {name: read(root / "report.json") for name, root in roots.items()}
    assert not reports["residual"]["eligibleForSequentialTrainCheck"]
    assert not reports["selected-sequential"]["eligibleForDev"]
    assert reports["residual-dev"]["exploratory"]
    assert not reports["residual-dev"]["eligibleForAdoption"]
    raw = []
    for name in ("selected-sequential", "residual-dev", "precision"):
        raw += raw_entries(roots[name], destinations[name])
    raw_archive = publish(
        Path("docs/evidence/artifacts/recovery-stability-rollouts-v1.tar.xz"), {}, raw
    )
    files = {}
    for name, root in roots.items():
        report = reports[name]
        for p in root.iterdir():
            if not p.is_file() or p.name.endswith(".jsonl.gz"):
                continue
            if p.name in report["rawHashes"]:
                assert prior.sha(p) == report["rawHashes"][p.name], p
            files[str(Path(destinations[name]) / p.name)] = p
    files.update(
        {str(p): p for p in checks.iterdir() if p.is_file() and "publication" not in p.name}
    )
    for p in [
        *Path("src/newsvendor").glob("*.py"),
        *Path("configs").glob("research-recovery-residual*.json"),
        Path("configs/research-recovery-selected-sequential-v1.json"),
        Path("scripts/study_recovery_residual.py"),
        Path("scripts/study_recovery_replay.py"),
        Path("scripts/study_recovery_sampling.py"),
        Path("scripts/evaluate_responses.py"),
        Path("tests/test_recovery_residual.py"),
        Path("docs/evidence/scripts/reproduce-recovery-residual.py"),
        Path("results/research-checks/recovery-balance/sequential.py"),
        Path("results/research-checks/recovery-balance/publish.py"),
        Path(".github/workflows/ci.yml"),
    ]:
        files[str(p)] = p
    records = publish(Path("docs/evidence/artifacts/recovery-stability-records-v1.tar.xz"), files)
    result = {
        "scope": "Train refit replay, frozen-prior numeric residual learning, actual sequential Train comparison and separately registered exploratory original Dev. Controlled documents and responses only.",
        "testUsed": False,
        "newSourceHoldoutUsed": False,
        "weightsAdopted": False,
        "retainedModel": "forecast-v1",
        "priorProtocolFailuresPreserved": True,
        "reports": {name: compact(report) for name, report in reports.items()},
        "actualTrainScreen": read(checks / "actual-screen.json"),
        "generatedDifference": read(checks / "generated-difference.json"),
        "learningAudit": read(checks / "audit.json"),
        "trainOutcomeAudit": read(checks / "outcome-audit.json"),
        "devOutcomeAudit": read(checks / "dev-audit.json"),
        "checks": read(checks / "checks.json"),
        "artifact": records,
        "rawArtifact": raw_archive,
        "rawFormat": "Decompressed JSONL bytes and order are unchanged. raw-format.json preserves original gzip hashes and exact raw-byte hashes; tar.xz avoids recompressing gzip streams.",
        "limitations": [
            "Old refit and selected-versus-refit filters failed; subsequent Dev is separately registered exploratory development, not a retrospectively passed protocol.",
            "Primary full refit/42 and all three required seeds were fixed before Dev; no fallback to the diagnostic selected mode.",
            "Parent encoder had seen the Train families; source-held action-head selection is not independent generalization.",
            "Exact retail losses use only five complete periods from four sources, giving 35 conditions.",
            "Tanh saturation was observed, not isolated as a cause. The residual changes both input routing and trainable parameters.",
            "Generated Dev is 60 cases from 12 families. Public extraction, demand calibration and the historical frozen Test threshold remain unresolved.",
        ],
    }
    write("docs/evidence/research-recovery-stability-results.json", result)
    write(checks / "publication.json", {"artifact": records, "rawArtifact": raw_archive})


if __name__ == "__main__":
    main()
