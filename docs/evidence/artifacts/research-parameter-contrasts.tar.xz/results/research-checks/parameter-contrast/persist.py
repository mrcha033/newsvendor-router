import hashlib
import os
import shutil
import subprocess
import tarfile
from pathlib import Path

from newsvendor.io import read, require, write

root = Path("results/l40s-research-parameter-contrasts-v1")
output = root / "base/42"
stage = Path("/dev/shm/newsvendor-parameter-contrasts-v1-20261009")
require(output.is_symlink() and output.resolve() == stage, "Wrong temporary output")
require(read(output / "job.json")["stage"] == "complete", "Training must complete first")


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


paths = sorted(p for p in stage.rglob("*") if p.is_file())
require(not any(p.is_symlink() for p in stage.rglob("*")), "Unexpected symlink in run")
files = {str(p.relative_to(stage)): {"sha256": file_hash(p), "bytes": p.stat().st_size} for p in paths}
archive = root / "full-run.tar.zst"
write(root / "storage-files.json", files)
if not archive.exists():
    temporary = archive.with_suffix(".tmp")
    with (root / "compression.log").open("w") as log:
        pack = subprocess.Popen(["tar", "-C", str(stage), "-cf", "-", "."], stdout=subprocess.PIPE, stderr=log)
        compress = subprocess.Popen(["zstd", "-T2", "-3", "--long=31", "-o", str(temporary)], stdin=pack.stdout, stdout=log, stderr=log)
        pack.stdout.close()
        require(compress.wait() == 0 and pack.wait() == 0, "Archival failed; keep temporary run")
    with temporary.open("rb") as stream:
        os.fsync(stream.fileno())
    temporary.replace(archive)
seen = set()
unpack = subprocess.Popen(["zstd", "--long=31", "-dc", str(archive)], stdout=subprocess.PIPE)
with tarfile.open(fileobj=unpack.stdout, mode="r|") as reader:
    for member in reader:
        if not member.isfile():
            continue
        name = member.name.removeprefix("./")
        require(name in files and name not in seen, "Unexpected archive member")
        require(member.size == files[name]["bytes"], "Archive size differs")
        require(hashlib.file_digest(reader.extractfile(member), "sha256").hexdigest() == files[name]["sha256"], "Archive hash differs")
        seen.add(name)
require(unpack.wait() == 0 and seen == set(files), "Incomplete archive verification")
restored = root / "base/durable-42"
require(not restored.exists(), "Preserve existing durable output")
restored.mkdir()
copied = []
for name, record in files.items():
    path = Path(name)
    if path.suffix == ".pt" and path.name not in ("model.pt", "common.pt"):
        continue
    destination = restored / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(stage / path, destination)
    with destination.open("rb") as stream:
        os.fsync(stream.fileno())
    require(file_hash(destination) == record["sha256"], "Durable copy differs")
    copied.append(name)
output.unlink()
restored.rename(output)
report = {
    "state": "durable", "output": str(output), "archive": str(archive),
    "archiveHash": file_hash(archive), "archiveBytes": archive.stat().st_size,
    "files": files, "allHashesVerified": True, "directFiles": copied,
    "archiveOnlyFiles": sorted(set(files) - set(copied)),
    "allCheckpointsAndOptimizersPreserved": True,
    "restoreExample": "zstd --long=31 -dc " + str(archive) + " | tar -xf - -C DESTINATION ./language-progress.pt",
}
write(root / "storage.json", report)
# Only this run's verified duplicate temporary files are removed.
shutil.rmtree(stage)
write(root / "temporary-cleanup.json", {"temporaryRemoved": not stage.exists(), "archiveVerifiedFiles": len(files), "directFiles": len(copied)})
print({"files": len(files), "archiveBytes": archive.stat().st_size, "directFiles": len(copied), "allHashesVerified": True})
