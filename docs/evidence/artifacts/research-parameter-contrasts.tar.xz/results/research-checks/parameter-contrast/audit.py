import copy
import math
import os
import random
import time
from collections import defaultdict
from pathlib import Path

import torch

from newsvendor.cli import provenance
from newsvendor.construction import atoms, parameter_record
from newsvendor.corpus import SLOTS, answer_doc
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import research_input
from newsvendor.structured_retail import parameter_metrics
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_train import load

ROOT = Path(__file__).resolve().parent
SOURCES = [f"results/l40s-research-replay-v1/base/42/{name}-inputs.jsonl" for name in ["generated"]]
SOURCES.append("results/l40s-research-replay-v1/base/42/inputs.jsonl")
CHECKPOINT = "results/l40s-research-forecast-v1/base/42/model.pt"
CONDITIONS = ["baseline", "money_scale", "source_ids", "pack_size", "refund_order", "wrong_sku", "wrong_period", "older_version"]


def transformed(row, condition):
    value = copy.deepcopy(row["input"])
    reference = parameter_record(value)
    expected = reference["values"].copy()
    rng = random.Random(digest([71, row["family"], condition]))
    if condition == "money_scale":
        factor = 1.731
        for doc in value["docs"]:
            spans = {tuple(a["span"]): a["value"] for a in atoms(doc) if a["unit"] != "count"}
            for (start, end), number in sorted(spans.items(), reverse=True):
                doc["text"] = doc["text"][:start] + f"{number * factor:.12g}" + doc["text"][end:]
        expected = {s: n * factor for s, n in expected.items()}
    elif condition == "source_ids":
        for i, doc in enumerate(value["docs"]):
            doc["id"] = digest([row["family"], i, condition])[:12]
        rng.shuffle(value["docs"])
    elif condition == "pack_size":
        doc = next(d for d in value["docs"] if d["id"] == reference["links"]["c"])
        doc["text"] = f"Pack price = {17 * expected['c']:.12g}; units per pack = 17."
    elif condition == "refund_order":
        doc = next(d for d in value["docs"] if d["id"] == reference["links"]["v"])
        doc["text"] = f"handling fee per unit = 1; Refund per unit = {expected['v'] + 1:.12g}. Unlimited returns."
    elif condition in ("wrong_sku", "wrong_period", "older_version"):
        for slot in SLOTS:
            original = next(d for d in value["docs"] if d["id"] == reference["links"][slot])
            added = answer_doc(value, slot, expected[slot] + 7.123, f"distractor-{slot}")
            added["version"] = original["version"] + 1
            if condition == "wrong_sku":
                added["sku"] = "another-" + value["task"]["sku"]
            elif condition == "wrong_period":
                added["period"] = "different-period"
            else:
                added["version"] = 1
                original["version"] = max(2, original["version"])
            value["docs"].append(added)
        rng.shuffle(value["docs"])
    measured = parameter_record(value)
    errors = [s for s in SLOTS if s not in measured["values"] or not math.isclose(measured["values"][s], expected[s], rel_tol=1e-7, abs_tol=1e-7)]
    return value, expected, errors


def main():
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "Assigned GPU only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    require(not (ROOT / "report.json").exists(), "Preserve prior audit")
    selected = {}
    for source in SOURCES:
        for row in lines(source):
            if row["split"] != "train" or row["input"]["history"]:
                continue
            if len(parameter_record(row["input"])["values"]) != 4:
                continue
            key = row["family"]
            if key not in selected or digest(research_input(row["input"])) < digest(research_input(selected[key]["input"])):
                selected[key] = row
    cases, oracle_errors = [], []
    for row in sorted(selected.values(), key=lambda r: r["family"]):
        for condition in CONDITIONS:
            value, expected, errors = transformed(row, condition)
            item = {"id": row["id"], "family": row["family"], "split": "train", "condition": condition, "input": value, "expected": expected, "inputHash": digest(research_input(value))}
            (oracle_errors if errors else cases).append(item | {"oracleErrors": errors})
    jsonl(ROOT / "inputs.jsonl", [{k: v for k, v in r.items() if k not in ("expected", "oracleErrors")} for r in cases])
    jsonl(ROOT / "labels.jsonl", [{k: r[k] for k in ("id", "family", "condition", "expected")} for r in cases])
    jsonl(ROOT / "oracle-errors.jsonl", oracle_errors)
    plan = {"scope": "Train-only controlled parameter stress audit; no economic, latent-demand, or real-organizational effectiveness claim", "testUsed": False, "devUsed": False, "conditions": CONDITIONS, "families": sorted(selected), "cases": len(cases), "oracleFailures": len(oracle_errors), "seed": 71, "checkpoint": CHECKPOINT, "checkpointHash": digest(Path(CHECKPOINT).read_bytes()), "source": provenance({}), "scriptHash": digest(Path(__file__).read_bytes()), "inputsHash": digest((ROOT / "inputs.jsonl").read_bytes()), "labelsHash": digest((ROOT / "labels.jsonl").read_bytes()), "sources": {p: digest(Path(p).read_bytes()) for p in SOURCES}}
    write(ROOT / "registered.json", plan)
    require(not oracle_errors, "Document annotation/calculator differs from independent transformation targets; inspect oracle-errors first")
    torch.set_num_threads(8)
    torch.manual_seed(42)
    started = time.perf_counter()
    model, tokenizer, config, _ = load(CHECKPOINT, "cuda")
    router = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
    raw, groups = [], defaultdict(lambda: defaultdict(int))
    for i, row in enumerate(cases):
        state = router.construct(row["input"])
        metrics = parameter_metrics(row["input"], state)
        record = {k: row[k] for k in ("id", "family", "condition", "inputHash", "expected")}
        record.update(state=state, metrics=metrics)
        raw.append(record)
        group = groups[row["condition"]]
        group["cases"] += 1
        group["fields"] += 4
        group["valueErrors"] += round(4 * (1 - metrics["parameterAccuracy"]))
        group["rawValueErrors"] += round(4 * (1 - metrics["rawParameterAccuracy"]))
        group["stateErrors"] += round(4 * (1 - metrics["stateAccuracy"]))
        group["evidenceErrors"] += metrics["evidenceCount"] - metrics["evidenceCorrect"]
        if (i + 1) % 64 == 0:
            print({"processed": i + 1, "total": len(cases)}, flush=True)
    jsonl(ROOT / "raw.jsonl", raw)
    report = {"plan": plan, "groups": dict(groups), "seconds": time.perf_counter() - started, "peakGpuBytes": torch.cuda.max_memory_allocated(), "rawHash": digest((ROOT / "raw.jsonl").read_bytes())}
    write(ROOT / "report.json", report)
    print({"groups": report["groups"], "seconds": report["seconds"]}, flush=True)


if __name__ == "__main__":
    main()
