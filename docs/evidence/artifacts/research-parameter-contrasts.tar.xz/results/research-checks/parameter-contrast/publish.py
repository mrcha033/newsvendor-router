import hashlib
import tarfile
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import digest, read, require, write


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


audit = Path(__file__).resolve().parent.relative_to(Path.cwd())
run = Path("results/l40s-research-parameter-contrasts-v1")
held = Path("results/l40s-parameter-contrasts-held-v1")
data = Path("results/parameter-contrasts-v1")
registered = read(run / "registered.json")
storage = read(run / "storage.json")
train = read(audit / "training-summary.json")
comparison = read(held / "report.json")
require(storage["state"] == "durable" and storage["allHashesVerified"], "Undurable run")
require(storage["allCheckpointsAndOptimizersPreserved"], "Missing optimizer/checkpoint archive")
require(sha(Path(storage["archive"])) == storage["archiveHash"], "Private archive changed")
require(not (run / "base/42").is_symlink(), "Temporary output remains")
parent = Path(registered["config"]["warmStart"])
require(sha(parent) == registered["files"][str(parent)], "Selected parent changed")
require(not train["adopted"] and train["policyIterations"] == 0, "Wrong selection scope")
require(comparison["models"]["selected"]["groups"]["all"]["valueErrors"] == 0, "Wrong contrast report")
with tarfile.open(run / "base/42/source.tar.gz", "r:gz") as archive:
    for name, expected in registered["source"]["sources"].items():
        require(digest(archive.extractfile(name).read()) == expected, "Historical source differs")
tests = (audit / "tests-final.log").read_text()
require("270 passed in 31.24s" in tests, "Wrong test log")
require("All checks passed!" in (audit / "ruff-final.log").read_text(), "Ruff failed")
checks = {
    "tests": {"passed": 270, "seconds": 31.24, "logHash": sha(audit / "tests-final.log")},
    "ruff": {"passed": True, "formatFiles": 85, "logHash": sha(audit / "ruff-final.log")},
    "sourceChecks": read(audit / "source-checks-final.json"),
    "numericalSmoke": read("results/smoke.json"),
    "contrastSeparation": read(run / "preflight.json"),
    "currentSourceHash": provenance({})["sourceHash"],
    "measuredSourceHash": registered["source"]["sourceHash"],
}
for record in checks["sourceChecks"].values():
    require(record["check"]["sourceOverlaps"] == record["check"]["inputOverlaps"] == 0, "Leakage")
require(checks["numericalSmoke"]["smokeEpisodes"] == 30 and checks["numericalSmoke"]["falseHandoffs"] == 0, "Smoke failed")
write(audit / "checks.json", checks)
paths = [p for root in [data, held, run / "base/42"] for p in sorted(root.iterdir()) if p.is_file() and p.suffix != ".pt"]
paths += [run / n for n in ["registered.json", "preflight.json", "encoder-update-verified.json", "encoder-update.log", "train.log", "storage.json", "storage-files.json", "temporary-cleanup.json", "compression.log"]]
paths += [audit / n for n in [
    "audit.py", "audit.log", "registered.json", "inputs.jsonl", "labels.jsonl", "oracle-errors.jsonl",
    "report.json", "raw.jsonl", "error-types.json", "acceptance.json", "training-summary.json",
    "selection-audit.json", "public-retention.json", "prepare.log", "tests-final.log", "ruff-final.log",
    "source-checks-final.json", "smoke-final.log", "held.log", "persist.py", "persist.log",
    "persist-final.log", "publish.py", "checks.json",
]]
paths += [Path(n) for n in [
    "configs/parameter-contrasts-v1.json", "configs/parameter-contrasts-held-v1.json",
    "configs/l40s-research-parameter-contrasts-v1.json", "scripts/prepare_parameter_contrasts.py",
    "scripts/evaluate_parameter_contrasts.py", "src/newsvendor/structured_train.py",
    "tests/test_parameter_contrasts.py", "tests/test_structured.py",
    "results/research-checks/construction-queries/encoder_update.py",
]]
paths = sorted(set(paths))
files = {str(p): {"sha256": sha(p), "bytes": p.stat().st_size} for p in paths}
archive_path = Path("docs/evidence/artifacts/research-parameter-contrasts.tar.xz")
require(not archive_path.exists(), "Preserve earlier published archive")
print({"stage": "compress", "files": len(files), "rawBytes": sum(v["bytes"] for v in files.values())}, flush=True)
with tarfile.open(archive_path, "w:xz", preset=3) as archive:
    for path in paths:
        archive.add(path, arcname=str(path))
with tarfile.open(archive_path, "r:xz") as archive:
    require(set(archive.getnames()) == set(files), "Published archive members differ")
    for name, entry in files.items():
        require(hashlib.file_digest(archive.extractfile(name), "sha256").hexdigest() == entry["sha256"], "Published raw hash differs")
result = {
    "scope": "Train document applicability contrasts, full encoder continuation, held augmentation-source diagnosis and original Dev retention; candidate not adopted",
    "testUsed": False,
    "modelReplacementMade": False,
    "retainedCheckpoint": str(parent),
    "retainedCheckpointHash": registered["files"][str(parent)],
    "initialDiagnostic": read(audit / "report.json"),
    "initialErrorTypes": read(audit / "error-types.json"),
    "data": read(data / "manifest.json"),
    "trainingRegistration": registered,
    "training": train,
    "encoderUpdate": read(run / "encoder-update-verified.json"),
    "heldContrasts": comparison,
    "publicRetention": read(audit / "public-retention.json"),
    "selectionFix": read(audit / "selection-audit.json"),
    "checks": checks,
    "privateStorage": storage,
    "decision": {"adopted": False, "reason": train["reason"], "selectedLanguageEpoch": 2, "correctedGateRetrained": False},
    "limitations": [
        "Held contrast sources were seen as original Train cases; 100% contrast scores are not independent-source model effectiveness or real organizational evidence.",
        "Original retail exact loss covers only five unique periods crossed with seven generated conditions. Six new incomplete-period stops are excluded from that mean and must still count as a regression.",
        "Only one training seed and two epochs were measured; no robust optimum or general superiority is established.",
        "The selector fix was made after this run. Recorded-metric replay would choose epoch 1, but epoch 1 sequential/public retention has not been evaluated and no retraining under the fix is claimed.",
        "The full checkpoint and optimizer archive is local and not part of the public raw bundle. External end-to-end reproduction still requires full model weights.",
    ],
    "publishedRaw": {"path": str(archive_path), "sha256": sha(archive_path), "bytes": archive_path.stat().st_size, "files": files, "verified": True},
}
write("docs/evidence/research-parameter-contrasts-results.json", result)
write(audit / "published-audit.json", {"allHashesVerified": True, "files": len(files), "archiveHash": result["publishedRaw"]["sha256"], "archiveBytes": archive_path.stat().st_size, "modelPromoted": False})
print({"stage": "complete", "files": len(files), "archiveBytes": archive_path.stat().st_size, "currentSourceHash": checks["currentSourceHash"], "measuredSourceHash": checks["measuredSourceHash"]}, flush=True)
