"""Decompose realized Train loss and forced-first-action gaps; no model or Test selection."""
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
from newsvendor.io import lines,read,write,jsonl,digest,require
root=Path('results/research-checks/train-loss-audit')
base=Path('results/l40s-research-precision-v1/control/42')
targets=lines(base/'value-targets-0.jsonl')
outputs=lines('results/research-checks/action-precision/fp32/inherited.jsonl')
require(len(targets)==len(outputs),'State counts differ')
measurements=lines(base/'rollout-train-0.jsonl')
by_state={}
for m in measurements:
 require(m['split']=='train','Train only')
 key=(m['id'],m['stateHash'],m['forcedAction'])
 require(key not in by_state,'Duplicate forced rollout')
 by_state[key]=m
raw=[]
for r,p in zip(targets,outputs,strict=True):
 require(r['id']==p['id'] and r['actions']==[a['id'] for a in p['actions']],'Probe state mismatch')
 if r['input']['history']: continue
 action=p['action']['id']; state_hash=digest(r['input']); key=(r['id'],state_hash,action)
 actual=by_state[key]
 values={a:sum(t)*r['scale'] for a,t in zip(r['actions'],r['values'],strict=True)}
 require(abs(actual['total']-values[action])<1e-6,'Target/rollout loss mismatch')
 first_state=actual['events'][0]['state']; final_state=actual['events'][-1]['state']
 data={'id':r['id'],'family':r['family'],'split':'train','benchmark':'retail' if 'forecast' in r['input']['task'] else 'generated','action':action,'result':actual['result'],'total':actual['total'],'terminal':actual['terminalLoss'],'requestCost':actual['requestCost'],'invalidHandoffPenalty':actual['invalidHandoffPenalty'],'falseHandoff':actual['falseHandoff'],'holdCost':r['scale'],'q':actual['q'],'initialValues':first_state['values'],'finalValues':final_state['values'],'initialErrors':first_state['errors'],'finalErrors':final_state['errors'],'initialStates':first_state['state'],'finalStates':final_state['state'],'realizedForcedValues':values,'realizedBestAction':min(values,key=values.get),'realizedGap':values[action]-min(values.values()),'interactions':actual['interactions'],'responses':[{'action':e['action'],'response':e.get('observedResponse')} for e in actual['events'] if 'observedResponse' in e]}
 if data['benchmark']=='retail':data['parameters']=actual['parameters']
 raw.append(data)
require(len(raw)==len({r['id'] for r in raw})==514,'Expected one initial state per Train episode')
groups=defaultdict(list)
for r in raw:groups[r['benchmark']].append(r)
report={'scope':'One recorded noisy Train response per action, continued with the inherited policy. Best forced action is a hindsight lower bound within these continuations, not an expected-value oracle or a new policy.','testUsed':False,'devUsed':False,'sourceHash':read('results/l40s-research-precision-v1/registered.json')['source']['sourceHash'],'scriptHash':digest(Path(__file__).read_bytes()),'inputHashes':{str(p):digest(p.read_bytes()) for p in [base/'value-targets-0.jsonl',base/'rollout-train-0.jsonl',Path('results/research-checks/action-precision/fp32/inherited.jsonl')]},'benchmarks':{}}
for name,rows in groups.items():
 sums={k:float(np.mean([r[k] for r in rows])) for k in ['total','terminal','requestCost','invalidHandoffPenalty','realizedGap','interactions']}
 report['benchmarks'][name]={'episodes':len(rows),'families':len({r['family'] for r in rows}),'means':sums,'holds':sum(r['result']=='hold' for r in rows),'falseHandoffs':sum(r['falseHandoff'] for r in rows),'positiveRealizedGap':sum(r['realizedGap']>1e-6 for r in rows),'initialErrors':dict(Counter(e for r in rows for e in r['initialErrors'])),'gapByInitialAction':{a:float(sum(r['realizedGap'] for r in rows if r['action']==a)) for a in sorted({r['action'] for r in rows})},'topLoss':sorted(rows,key=lambda r:r['total'],reverse=True)[:12],'topGap':sorted(rows,key=lambda r:r['realizedGap'],reverse=True)[:12]}
jsonl(root/'raw.jsonl',raw)
report['rawHash']=digest((root/'raw.jsonl').read_bytes());write(root/'report.json',report)
print({k:{key:value for key,value in v.items() if key not in ['topLoss','topGap']} for k,v in report['benchmarks'].items()})
