"""Run the two fixed Train/Dev response-supervision conditions on the assigned L40S."""
import os
import subprocess
import sys
import tarfile
import time
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import digest, read, require, write

root = Path('results/l40s-research-responses-v1')
root.mkdir(parents=True, exist_ok=True)
require(not (root / 'registered.json').exists(), 'Never overwrite a registration')
conditions = {name: read(f'configs/l40s-research-responses-v1-{name}.json') for name in ['aligned', 'sampled']}
source = provenance(conditions['aligned'])
paths = sorted({Path('pyproject.toml'), Path('uv.lock'), *Path('src').rglob('*.py'), *Path('tests').rglob('*.py'), *Path('scripts').glob('*.py'), *Path('configs').glob('*.json')})
archive = root / 'source.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in paths:
        tar.add(path, arcname=str(path))
write(root / 'registered.json', {
    'scope': 'Fixed Train/Dev response-noise alignment and averaged rollout-return study',
    'testUsed': False, 'source': source, 'conditions': conditions,
    'parentHash': digest(Path(conditions['aligned']['warmStart']).read_bytes()),
    'sourceArchive': {'path': str(archive), 'sha256': digest(archive.read_bytes())},
    'historicalReference': 'results/l40s-research-precision-v1/value/42',
    'trainDiagnostic': 'results/research-checks/train-loss-audit/noise-comparison.json',
    'trainDiagnosticHash': digest(Path('results/research-checks/train-loss-audit/noise-comparison.json').read_bytes()),
    'scriptHash': digest(Path(__file__).read_bytes()),
})
env = os.environ.copy()
env.update(CUDA_VISIBLE_DEVICES='GPU-674d64b8-4bdf-7006-1791-5dc7f7245409', CUBLAS_WORKSPACE_CONFIG=':4096:8', HF_HUB_OFFLINE='1', HF_HOME='.cache/torch-models', PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True', PYTHONPATH='src')
jobs = []
for name, config in conditions.items():
    require(provenance(config)['sourceHash'] == source['sourceHash'], 'Source changed during registered study')
    directory = Path(config['output'])
    require(not directory.exists(), 'Output already exists')
    directory.mkdir(parents=True)
    command = ['.venv-l40s/bin/python', 'scripts/run_research.py', '--config', f'configs/l40s-research-responses-v1-{name}.json', '--stage', 'policy']
    start = time.perf_counter()
    with (directory / 'train.log').open('w') as log:
        child = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT)
        write(root / 'queue.json', {'stage': 'running', 'condition': name, 'pid': child.pid, 'queuePid': os.getpid(), 'completed': jobs, 'testUsed': False})
        code = child.wait()
    jobs.append({'condition': name, 'exitCode': code, 'seconds': time.perf_counter()-start})
    if code:
        write(root / 'queue.json', {'stage': 'failed', 'completed': jobs, 'testUsed': False})
        sys.exit(code)
    require(read(directory / 'job.json')['stage'] == 'complete', 'Run did not complete')
write(root / 'queue.json', {'stage': 'complete', 'completed': jobs, 'testUsed': False})
print(jobs, flush=True)
