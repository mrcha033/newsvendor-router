"""Train-only response-noise comparison at the same frozen constructor/policy."""
import time
from pathlib import Path

import torch

from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, require, write
from newsvendor.structured_model import assemble
from newsvendor.structured_retail import VERSION
from newsvendor.structured_rollout import ResearchRouter, collect
from newsvendor.structured_train import load
from newsvendor.train import seed

root = Path('results/research-checks/train-loss-audit')
source = Path('results/l40s-research-precision-v1/control/42')
parent = Path('results/l40s-research-replay-v1/base/42/model.pt')
seed(42)
torch.set_num_threads(8)
require(str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == '674d64b8-4bdf-7006-1791-5dc7f7245409', 'Wrong GPU')
episodes = []
for stem in ['', 'generated-']:
    inputs = [r for r in lines(source / f'{stem}inputs.jsonl') if r['split'] == 'train']
    ids = {r['id'] for r in inputs}
    environments = {r['id']: r for r in lines(source / f'{stem}environment.jsonl') if r['id'] in ids}
    for row in inputs:
        episode = row | environments[row['id']]
        if not stem:
            source_id, cutoff, scenario = row['id'].rsplit(':', 2)
            episode.update(benchmark=VERSION, sourceId=source_id, cutoffIndex=int(cutoff), scenario=scenario)
            if not all(episode['target']['complete']):
                continue
        episodes.append(episode)
require(len(episodes) == 514, 'Train episode count changed')
model, tokenizer, config, _ = load(parent, 'cuda')
config['encoder']['actionPrecision'] = 'float32'
router = ResearchRouter(model, tokenizer, config['encoder'])
write(root / 'noise-plan.json', {
    'scope': 'Train diagnostic only, same inherited policy and no extra response corruption. Environment missing/partial responses remain. No Dev/Test selection.',
    'source': provenance(config), 'checkpointHash': digest(parent.read_bytes()),
    'scriptHash': digest(Path(__file__).read_bytes()), 'episodes': len(episodes),
    'inputHash': digest([r['input'] for r in episodes]), 'noise': 0, 'testUsed': False,
})
started = time.perf_counter()
rows, raw = collect(episodes, router, noise=0, policy='mixed')
jsonl(root / 'no-noise-targets.jsonl', rows)
jsonl(root / 'no-noise-rollouts.jsonl', raw)
decisions = []
with torch.inference_mode():
    for start in range(0, len(rows), 32):
        group = rows[start:start+32]
        views = [router.view(r['input'], r['state']) for r in group]
        outputs = model(views)
        for row, view, prediction in zip(group, views, outputs, strict=True):
            decisions.append({'id': row['id'], 'stateHash': digest(row['input']), 'actions': row['actions'], 'action': assemble(view, prediction)['action']})
jsonl(root / 'no-noise-decisions.jsonl', decisions)
write(root / 'noise-run.json', {'seconds': time.perf_counter()-started, 'states': len(rows), 'rollouts': len(raw), 'testUsed': False})
print({'seconds': time.perf_counter()-started, 'states': len(rows), 'rollouts': len(raw)}, flush=True)
