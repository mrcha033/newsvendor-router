import hashlib
import importlib.util
from pathlib import Path

import torch

from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, require, write
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_train import load

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("portable_bundle", root / "bundle.py")
bundle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bundle)
torch.set_num_threads(8)
checkpoint = Path("results/l40s-research-forecast-v1/base/42/model.pt")
require(bundle.file_hash(checkpoint) == "e2fb23ee44b7a6c7158b111d122280d41f3626027f33323ff98f0fddc765904a", "Selected checkpoint changed")
model, tokenizer, config, _ = load(checkpoint, "cpu")
payload = torch.load(checkpoint, map_location="cpu", weights_only=True, mmap=True)
identity = {"checkpoint": str(checkpoint), "checkpointHash": bundle.file_hash(checkpoint), "datasetHashes": payload["datasetHashes"], "provenance": provenance({}), "modelRevision": config["encoder"]["revision"], "exportScriptHash": digest(Path(__file__).read_bytes()), "loaderHash": digest((root / "bundle.py").read_bytes())}
del payload
directory = Path("/dev/shm/newsvendor-forecast-bundle-v1")
manifest = bundle.export_bundle(directory, model, tokenizer, config, identity)
write(root / "manifest.json", manifest)
print({"stage": "exported", "weightsHash": manifest["weightsHash"]}, flush=True)
other, other_tokenizer, other_config, _ = bundle.load_bundle(directory, "cpu")
rows = lines("results/research-checks/parameter-scope/inputs.jsonl")
selected = [r for condition in ("baseline", "observed_reply", "wrong_sku", "wrong_period") for r in [x for x in rows if x["condition"] == condition][:2]]
jsonl(root / "inputs.jsonl", selected)
left = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
right = ResearchRouter(other, other_tokenizer, other_config["encoder"], other_config["noValue"])
raw = []
for row in selected:
    first = left.decision(row["input"])
    second = right.decision(row["input"])
    require(first == second, "Portable CPU inference differs")
    raw.append({k: row[k] for k in ("id", "family", "condition", "inputHash")} | {"original": first, "portable": second})
jsonl(root / "cpu-raw.jsonl", raw)
write(root / "cpu-report.json", {"scope": "Exact CPU inference parity on eight previously observed Train cases; not a new effectiveness evaluation or a GPU parity claim", "cases": len(raw), "exact": True, "testUsed": False, "trainingDataNeededByPortableLoader": False, "hubAccessNeededByPortableLoader": False, "rawHash": bundle.file_hash(root / "cpu-raw.jsonl"), "weightsHash": manifest["weightsHash"]})
print({"stage": "cpu-parity-complete", "cases": len(raw)}, flush=True)
