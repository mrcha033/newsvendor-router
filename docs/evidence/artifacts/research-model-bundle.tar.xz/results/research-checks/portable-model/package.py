import hashlib
import shutil
import subprocess
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

root = Path(__file__).resolve().parent
bundle = Path("/dev/shm/newsvendor-forecast-bundle-v1")
stage = Path("/dev/shm/newsvendor-forecast-release-public-v1")
require(not stage.exists(), "Preserve previous release stage")
stage.mkdir()
for name in ("README.md", "NOTICE.txt", "ModernBERT-LICENSE.txt", "upstream-license.json"):
    shutil.copyfile(root / name, stage / name)
shutil.copyfile(root / "public-inputs.jsonl", stage / "example-inputs.jsonl")
paths = {"forecast-v1/" + str(p.relative_to(bundle)): p for p in sorted(bundle.rglob("*")) if p.is_file()}
paths.update({p.name: p for p in stage.iterdir() if p.is_file()})
files = {name: {"sha256": file_hash(p), "bytes": p.stat().st_size} for name, p in paths.items()}
archive = Path("/dev/shm/newsvendor-forecast-public-v1.tar.zst")
require(not archive.exists(), "Preserve previous release archive")
require(read(root / "production-report.json")["cpuExact"] and read(root / "production-report.json")["gpuExact"], "Missing production parity")
with archive.open("xb") as stream:
    process = subprocess.Popen(["zstd", "-T2", "-3", "--long=31", "-c"], stdin=subprocess.PIPE, stdout=stream)
    with tarfile.open(fileobj=process.stdin, mode="w|") as tar:
        for name, path in paths.items():
            tar.add(path, arcname=name)
    process.stdin.close()
    require(process.wait() == 0, "Compression failed")
process = subprocess.Popen(["zstd", "--long=31", "-dc", str(archive)], stdout=subprocess.PIPE)
seen = set()
with tarfile.open(fileobj=process.stdout, mode="r|") as tar:
    for member in tar:
        require(member.isfile() and member.name in files and member.name not in seen, "Wrong archive member")
        require(member.size == files[member.name]["bytes"], "Archive member size changed")
        require(hashlib.file_digest(tar.extractfile(member), "sha256").hexdigest() == files[member.name]["sha256"], "Archive member hash changed")
        seen.add(member.name)
require(process.wait() == 0 and seen == set(files), "Incomplete verification")
record = {"archive": str(archive), "sha256": file_hash(archive), "bytes": archive.stat().st_size, "files": files, "allHashesVerified": True}
write(root / "public-archive-verified.json", record)
print({k:v for k,v in record.items() if k != "files"}, flush=True)
