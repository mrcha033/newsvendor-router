import hashlib
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write

root = Path("results/research-checks/portable-model")
archive = read(root / "public-archive-verified.json")
storage = read(root / "storage.json")
production = read(root / "production-report.json")
offline = read(root / "production-offline-report.json")
require(production["cpuExact"] and production["gpuExact"] and offline["exact"], "Inference parity failed")
require(archive["allHashesVerified"] and storage["durableCopyVerified"], "Release archive not verified")
require(file_hash(storage["archive"]) == archive["sha256"], "Release archive changed")
require(production["weightsHash"] == read(root / "manifest.json")["weightsHash"], "Model identity differs")
paths = {p for p in root.iterdir() if p.is_file() and p.suffix not in (".pt", ".zst") and p.name not in ("publish.log", "upstream-model-card.md")}
paths.update(Path(p) for p in ("src/newsvendor/bundle.py", "scripts/predict_research.py", "tests/test_structured.py", ".github/workflows/ci.yml"))
files = {str(p): {"sha256": file_hash(p), "bytes": p.stat().st_size} for p in sorted(paths)}
raw = Path("docs/evidence/artifacts/research-model-bundle.tar.xz")
require(not raw.exists(), "Preserve prior publication")
with tarfile.open(raw, "w:xz", preset=3) as tar:
    for name in files:
        tar.add(name, arcname=name)
with tarfile.open(raw, "r:xz") as tar:
    require(set(tar.getnames()) == set(files), "Raw archive file set differs")
    for name, entry in files.items():
        require(hashlib.file_digest(tar.extractfile(name), "sha256").hexdigest() == entry["sha256"], "Raw archive hash differs")
result = {
    "scope": "Portable selected ModernBERT/heads/GRU inference bundle; within-device CPU/L40S parity and isolated offline loading. No new training or effectiveness claim.",
    "testUsed": False, "modelReplacementMade": False, "provenance": provenance({}),
    "release": {"url": "https://github.com/mrcha033/newsvendor-router/releases/tag/research-forecast-v1", "assetUrl": "https://github.com/mrcha033/newsvendor-router/releases/download/research-forecast-v1/forecast-v1.tar.zst", "sha256": archive["sha256"], "bytes": archive["bytes"], "files": archive["files"], "allLocalMemberHashesVerified": True},
    "manifest": read(root / "manifest.json"), "productionParity": production, "offlineLoading": offline,
    "publicInputs": read(root / "public-inputs-audit.json"), "upstreamLicense": read(root / "upstream-license.json"),
    "checks": read("results/research-checks/parameter-scope/checks.json"),
    "publishedRaw": {"path": str(raw), "sha256": file_hash(raw), "bytes": raw.stat().st_size, "files": files, "allHashesVerified": True},
    "limitations": [
        "Eight already observed Train examples verify preservation of inference, not model effectiveness, calibration or independent generalization.",
        "Exact parity compares original and exported weights on the same device. CPU/GPU output equality is not asserted.",
        "Full optimizer states and expanded Train datasets are absent. Code and Python/PyTorch/Transformers are required; the bundle removes original training-data and Hub dependencies from inference only.",
        "The initial cross-process comparison harness keyed cases by non-unique source id and incorrectly reported a mismatch. The corrected positional/id comparison checks all eight observations; failed log and raw outputs are preserved.",
        "Later scope-contrast candidates were not adopted or substituted into this release. The legacy Test threshold and demand calibration remain unresolved.",
    ],
}
write("docs/evidence/research-model-bundle.json", result)
print({"rawArchive": str(raw), "bytes": raw.stat().st_size, "releaseBytes": archive["bytes"], "releaseHash": archive["sha256"]})
