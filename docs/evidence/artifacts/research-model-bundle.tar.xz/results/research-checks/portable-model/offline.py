import importlib.util
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import torch

from newsvendor.io import lines, require, write
from newsvendor.structured_rollout import ResearchRouter

root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("portable_bundle", root / "bundle.py")
bundle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bundle)
torch.set_num_threads(8)
inputs = lines(root / "inputs.jsonl")
previous = lines(root / "cpu-raw.jsonl")
with tempfile.TemporaryDirectory(prefix="newsvendor-portable-") as empty:
    os.chdir(empty)
    require(not Path("data").exists(), "Training data unexpectedly present")
    with patch("socket.create_connection", side_effect=RuntimeError("Network disabled")):
        model, tokenizer, config, manifest = bundle.load_bundle("/dev/shm/newsvendor-forecast-bundle-v1", "cpu")
        router = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
        for row, expected in zip(inputs, previous, strict=True):
            require(router.decision(row["input"]) == expected["original"], "Offline output differs")
write(root / "offline-report.json", {"scope": "Fresh process in an empty working directory with offline Hub settings and network connections blocked; uses only the inference bundle, project code and eight captured observed Train inputs", "cases": len(inputs), "exact": True, "weightsHash": manifest["weightsHash"], "trainingDataPresent": False, "networkBlocked": True, "testUsed": False})
print({"cases": len(inputs), "offlineExact": True})
