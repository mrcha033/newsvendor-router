def test_portable_bundle_loads_exactly_without_training_data_or_network(
    model, tokenizer, settings, tmp_path, monkeypatch
):
    from newsvendor import bundle, structured_train

    model.eval()
    settings["attention"] = "eager"
    checkpoint = tmp_path / "original.pt"
    torch.save(model.state_dict(), checkpoint)
    directory = tmp_path / "bundle"
    config = {"encoder": settings, "noValue": False, "dataset": "absent-training-data"}
    manifest = bundle.export_bundle(
        directory, model, tokenizer, config, {"checkpointHash": bundle.file_hash(checkpoint)}
    )

    def forbidden(*args, **kwargs):
        raise AssertionError("Inference must use only local bundle assets")

    monkeypatch.setattr(structured_train, "dataset_hashes", forbidden)
    monkeypatch.setattr(structured_train, "load_backbone", forbidden)
    monkeypatch.setattr("socket.create_connection", forbidden)
    empty = tmp_path / "empty"
    empty.mkdir()
    monkeypatch.chdir(empty)
    restored, other_tokenizer, other_config, observed = bundle.load_bundle(directory)
    assert observed == manifest and set(other_config) == {"encoder", "noValue"}
    assert all(torch.equal(v, restored.state_dict()[k]) for k, v in model.state_dict().items())
    value = payload(request="purchase cost 10", documents=[], tables=[], tools=[], history=[])
    first = prepare(value, tokenizer, settings)
    second = prepare(value, other_tokenizer, other_config["encoder"])
    assert torch.equal(first["batch"]["input_ids"], second["batch"]["input_ids"])
    with torch.inference_mode():
        left, right = model(first), restored(second)
    for key, tensor in left.items():
        if isinstance(tensor, torch.Tensor):
            assert torch.equal(tensor, right[key]), key


@pytest.mark.parametrize("asset", ["model.pt", "encoder/tokenizer.json"])
def test_portable_bundle_rejects_modified_assets_before_loading(
    model, tokenizer, settings, tmp_path, asset
):
    from newsvendor import bundle

    directory = tmp_path / "bundle"
    bundle.export_bundle(
        directory, model, tokenizer, {"encoder": settings}, {"checkpointHash": "fixture"}
    )
    path = directory / asset
    changed = bytearray(path.read_bytes())
    changed[len(changed) // 2] ^= 1
    path.write_bytes(changed)
    with pytest.raises(ValueError, match="file hash changed"):
        bundle.load_bundle(directory)


def test_portable_bundle_rejects_extra_tokenizer_assets(model, tokenizer, settings, tmp_path):
    from newsvendor import bundle

    directory = tmp_path / "bundle"
    bundle.export_bundle(
        directory, model, tokenizer, {"encoder": settings}, {"checkpointHash": "fixture"}
    )
    (directory / "encoder/added_tokens.json").write_text('{"changed": 999}')
    with pytest.raises(ValueError, match="Unregistered bundle files"):
        bundle.load_bundle(directory)
