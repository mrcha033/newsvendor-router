import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import torch

from newsvendor.bundle import file_hash, load_bundle
from newsvendor.io import lines, require, write
from newsvendor.structured_rollout import ResearchRouter

root = Path(__file__).resolve().parent
torch.set_num_threads(8)
inputs = lines(root / "public-inputs.jsonl")
previous = lines(root / "cpu-raw.jsonl")
with tempfile.TemporaryDirectory(prefix="newsvendor-production-offline-") as empty:
    os.chdir(empty)
    require(not Path("data").exists(), "Training data unexpectedly present")
    with patch("socket.create_connection", side_effect=RuntimeError("Network disabled")):
        model, tokenizer, config, manifest = load_bundle("/dev/shm/newsvendor-forecast-bundle-v1", "cpu")
        router = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
        for row, expected in zip(inputs, previous, strict=True):
            require(row["id"] == expected["id"], "Input order changed")
            require(router.decision(row["input"]) == expected["original"], "Offline output differs")
write(root / "production-offline-report.json", {
    "scope": "Production loader in a fresh process, empty working directory and empty offline model cache, with socket connections blocked; previously observed sanitized Train inputs only",
    "cases": len(inputs), "exact": True, "weightsHash": manifest["weightsHash"], "publicInputHash": file_hash(root / "public-inputs.jsonl"),
    "trainingDataPresent": False, "networkBlocked": True, "testUsed": False,
    "offline": {k:os.environ.get(k) for k in ("HF_HOME", "HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE")}})
print({"cases": len(inputs), "offlineExact": True}, flush=True)
