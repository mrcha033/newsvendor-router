import os
from pathlib import Path

import torch

from newsvendor.bundle import file_hash, load_bundle
from newsvendor.cli import provenance
from newsvendor.io import jsonl, lines, require, write
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_train import load

root = Path(__file__).resolve().parent
require(os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "Wrong GPU")
require(torch.cuda.get_device_name(0) == "NVIDIA L40S", "Wrong GPU device")
torch.set_num_threads(8)
checkpoint = Path("results/l40s-research-forecast-v1/base/42/model.pt")
model, tokenizer, config, _ = load(checkpoint, "cuda")
other, other_tokenizer, other_config, manifest = load_bundle("/dev/shm/newsvendor-forecast-bundle-v1", "cuda")
left = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
right = ResearchRouter(other, other_tokenizer, other_config["encoder"], other_config["noValue"])
raw = []
for row in lines(root / "public-inputs.jsonl"):
    first = left.decision(row["input"])
    second = right.decision(row["input"])
    require(first == second, "Portable GPU inference differs")
    raw.append({"id": row["id"], "original": first, "portable": second})
jsonl(root / "gpu-raw.jsonl", raw)
cpu_original = lines(root / "cpu-raw.jsonl")
cpu_actual = lines(root / "public-cpu.jsonl")
require(len(cpu_actual) == len(cpu_original) == len(raw), "CPU case count differs")
require(all(r["id"] == old["id"] and r["prediction"] == old["original"] for r, old in zip(cpu_actual, cpu_original, strict=True)), "Production CPU output differs")
write(root / "production-report.json", {
    "scope": "Within-device exact inference parity on eight previously observed Train cases. This does not assert CPU/GPU equality or new effectiveness.",
    "cases": len(raw), "cpuExact": True, "gpuExact": True, "gpu": os.environ["CUDA_VISIBLE_DEVICES"],
    "testUsed": False, "weightsHash": manifest["weightsHash"], "checkpointHash": file_hash(checkpoint),
    "publicInputHash": file_hash(root / "public-inputs.jsonl"), "cpuRawHash": file_hash(root / "public-cpu.jsonl"),
    "gpuRawHash": file_hash(root / "gpu-raw.jsonl"), "provenance": provenance({})})
print({"cases": len(raw), "cpuExact": True, "gpuExact": True}, flush=True)
