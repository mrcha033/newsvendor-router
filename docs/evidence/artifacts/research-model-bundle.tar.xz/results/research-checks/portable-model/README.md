# Frozen Newsvendor forecast-v1 inference weights

This export contains the complete selected ModernBERT-base encoder, functional heads and demand GRU. It produces structured parameter/evidence/state records and manager-request or ordering actions; it does not generate natural-language responses.

Original checkpoint SHA-256: `e2fb23ee44b7a6c7158b111d122280d41f3626027f33323ff98f0fddc765904a`.
Tensor hash: `736836c735ab9e61662ea14371b699139bd60f00d80a7fdfd40e6b7139b6137e`.
Upstream encoder: `answerdotai/ModernBERT-base`, revision `8949b909ec900327062f0ebf497f51aef5e6f0c8`.

The `forecast-v1` directory includes weights, encoder configuration, tokenizer and a file-hash manifest. Load it with the repository's inference-bundle loader. Original training datasets, their local paths, Hugging Face access and a separate pretrained weight download are unnecessary for inference. Python/PyTorch/Transformers and the repository code remain required.

The manifest preserves original training-data identities. Optimizer states and expanded training datasets are not included, so this is an inference export rather than a complete training-resumption archive.

The small controlled evaluation and generated financial documents do not establish effectiveness in real organizational work. Demand calibration and the legacy generated Test target remain unresolved; use the repository's evidence documents for the measured scope and negative results. This export does not contain the later scope-contrast training candidates.

Upstream licensing evidence is in `upstream-license.json`; upstream license and attribution are included separately. The export makes no new repository-wide licensing declaration.
