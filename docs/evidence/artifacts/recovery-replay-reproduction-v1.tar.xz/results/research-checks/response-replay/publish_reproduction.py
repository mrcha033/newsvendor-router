"""Preserve the isolated cached-head reproduction from the verified public archive."""
from pathlib import Path
from publish import publish
from newsvendor.io import read,write

root=Path('/dev/shm/newsvendor-recovery-restored-v1')
checks=Path('results/research-checks/response-replay')
report=read(root/'reproduced.json')
assert report['comparedStateDecisions']==3864 and report['heldStates']==276
assert all(all(v.values()) for v in report['results'].values())
assert not list((root/'empty-hub-cache').iterdir())
files={str(checks/'reproduced.json'):root/'reproduced.json',
       str(checks/'restoration.json'):root/'restoration.json',
       str(checks/'reproduction-guard.py'):root/'guard/sitecustomize.py'}
for name in ('reproduction.log','publish_reproduction.py'):
    files[str(checks/name)]=checks/name
files['docs/evidence/scripts/reproduce-recovery-heads.py']=Path('docs/evidence/scripts/reproduce-recovery-heads.py')
artifact=publish(Path('docs/evidence/artifacts/recovery-replay-reproduction-v1.tar.xz'),files)
path='docs/evidence/research-recovery-replay-results.json'
evidence=read(path)
evidence['publishedReproduction']={**report,'artifact':artifact,'networkAndWorkingDataForbidden':True,'emptyHubCache':True,
    'scopeNote':'Only cached features and small heads; no original datasets, checkpoint, encoder execution or fresh sequential policy evaluation.'}
write(path,evidence)
write(checks/'reproduction-publication.json',artifact)
