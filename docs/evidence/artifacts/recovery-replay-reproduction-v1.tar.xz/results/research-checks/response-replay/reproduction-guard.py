import os, sys
from pathlib import Path
blocked = [Path('/home/yunmin/newsvendor-router/data'), Path('/home/yunmin/newsvendor-router/results')]
def audit(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo'):
        raise RuntimeError('Network forbidden during published-assets reproduction')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.path.abspath(os.fsdecode(args[0])))
        if any(path.is_relative_to(r) or path.resolve().is_relative_to(r) for r in blocked):
            raise RuntimeError('Working data/checkpoint forbidden: ' + str(path))
sys.addaudithook(audit)
