"""Profile allocation concentration on fixed Train-fit and Train-held forecasts."""
import os
from pathlib import Path

import numpy as np
import torch

from newsvendor import demand, sequence
from newsvendor.io import digest, jsonl, lines, read, require, write

root=Path('/dev/shm/newsvendor-demand-tail-allocation-v1')
require(not root.exists(),'Preserve diagnostics')
require(os.environ.get('CUDA_VISIBLE_DEVICES')=='GPU-674d64b8-4bdf-7006-1791-5dc7f7245409','Assigned L40S only')
torch.set_num_threads(1)
parent=read('results/research-checks/demand-curve-audit/report.json')
dataset=Path('data/processed/core-retail-train-v1')
rows=[r for r in lines(dataset/'inputs.jsonl') if r['component']=='retail' and r['split']=='train']
ids={r['id'] for r in rows}
labels={r['id']:r['target'] for r in lines(dataset/'labels.jsonl') if r['id'] in ids}
samples=[r for r in sequence.samples(rows,labels) if r['horizon']==7]
fit=set(parent['fitFamilies']);held=set(parent['heldFamilies'])
require(not fit & held and {r['family'] for r in samples}==fit|held,'Source leakage')
checkpoint=torch.load('results/research-checks/demand-curve-audit/epoch-07.pt',weights_only=True,map_location='cpu')
model=sequence.DemandEncoder().to('cuda').eval();model.load_state_dict(checkpoint['weights'])
root.mkdir()
jsonl(root/'origins.jsonl',[{k:v for k,v in r.items() if k!='sequence'} for r in samples])
values={a:[] for a in range(1,9)}
with torch.inference_mode():
 for start in range(0,len(samples),128):
  batch=samples[start:start+128]
  output=model([r['sequence'] for r in batch],[7]*len(batch),daily=True)
  for concentration in values:
   loss=sequence.losses(output,batch,{**checkpoint['settings'],'allocationConcentration':concentration})
   values[concentration].append(loss.cpu())
  if start%2048==0: print({'done':min(start+128,len(samples))},flush=True)
values={a:torch.cat(v) for a,v in values.items()}
torch.save(values,root/'raw.pt')
report={'scope':'Fixed parameter model. Fit-source profile chooses concentration diagnostically; held sources only score it. No Dev/Test.',
        'devUsed':False,'testUsed':False,'heldUsedToChooseConcentration':False,
        'scriptHash':digest(Path(__file__).read_bytes()),'checkpointEpoch':7,'familyOrder':list(demand.FAMILIES),
        'fitFamilies':sorted(fit),'heldFamilies':sorted(held),'scores':{}}
for concentration,losses in values.items():
 group={}
 for name,families in [('fit',fit),('held',held)]:
  for observed in ('all','complete','censored'):
   mask=[r['family'] in families and (observed=='all' or r['censored']==(observed=='censored')) for r in samples]
   selected=losses[mask].double()
   group[f'{name}:{observed}']={'rows':int(sum(mask)),'mean':float(selected.mean()),'families':selected.mean(0).tolist()}
 report['scores'][str(concentration)]=group
report['fitSelectedConcentration']=min(values,key=lambda a:report['scores'][str(a)]['fit:all']['mean'])
write(root/'report.json',report)
print({'chosen':report['fitSelectedConcentration'],'scores':{a:{k:round(v['mean'],6) for k,v in s.items()} for a,s in report['scores'].items()}},flush=True)
