"""Check family-gradient conflict on a fixed, reproducible Train-fit sample."""
import os
from pathlib import Path

import numpy as np
import torch

from newsvendor import demand, sequence
from newsvendor.io import digest, jsonl, lines, read, require, write

root=Path('/dev/shm/newsvendor-demand-family-gradients-v1')
require(not root.exists(),'Preserve prior audit')
require(os.environ.get('CUDA_VISIBLE_DEVICES')=='GPU-674d64b8-4bdf-7006-1791-5dc7f7245409','L40S only')
torch.set_num_threads(1)
parent=read('results/research-checks/demand-curve-audit/report.json')
fitting=set(parent['fitFamilies'])
dataset=Path('data/processed/core-retail-train-v1')
rows=[r for r in lines(dataset/'inputs.jsonl') if r['component']=='retail' and r['split']=='train' and r['family'] in fitting]
ids={r['id'] for r in rows}
labels={r['id']:r['target'] for r in lines(dataset/'labels.jsonl') if r['id'] in ids}
allrows=sequence.samples(rows,labels)
chosen=np.random.default_rng(771).choice(len(allrows),2048,replace=False)
samples=[allrows[i] for i in chosen]
checkpoint=torch.load('results/research-checks/demand-curve-audit/epoch-07.pt',weights_only=True,map_location='cpu')
model=sequence.DemandEncoder().to('cuda');model.load_state_dict(checkpoint['weights']);model.train()
parameters=tuple(p for n,p in model.named_parameters() if n.startswith(('gru.','condition.')))
root.mkdir()
jsonl(root/'origins.jsonl',[{k:v for k,v in r.items() if k!='sequence'} for r in samples])
records=[]
for start in range(0,len(samples),128):
 batch=samples[start:start+128]
 out=model([r['sequence'] for r in batch],[r['horizon'] for r in batch],daily=True)
 losses=sequence.losses(out,batch,checkpoint['settings'])
 gradients=[]
 for index in range(3):
  parts=torch.autograd.grad(losses[:,index].mean(),parameters,retain_graph=index<2)
  gradient=torch.cat([p.flatten() for p in parts]);require(torch.isfinite(gradient).all(),'Nonfinite gradient')
  gradients.append(gradient)
 vectors=torch.stack(gradients);norms=vectors.norm(dim=1)
 cosine=(vectors@vectors.T)/(norms[:,None]*norms[None,:]).clamp_min(1e-30)
 total=vectors.mean(0)
 records.append({'start':start,'size':len(batch),'familyNLL':losses.detach().cpu().tolist(),
                 'norms':norms.tolist(),'cosines':cosine.tolist(),
                 'firstOrderChangeSharedUpdate':(-vectors@total).tolist()})
jsonl(root/'gradients.jsonl',records)
report={'scope':'2048 fixed Train-fit examples, no optimizer update or Dev/Test',
        'devUsed':False,'testUsed':False,'selectionSeed':771,'familyOrder':list(demand.FAMILIES),
        'scriptHash':digest(Path(__file__).read_bytes()),'sharedParameters':sum(p.numel() for p in parameters),
        'batches':len(records),'negativeCosineBatches':{},'worseningSharedGradientBatches':{}}
for i,family in enumerate(demand.FAMILIES):
 report['worseningSharedGradientBatches'][family]=sum(r['firstOrderChangeSharedUpdate'][i]>0 for r in records)
 for j,other in enumerate(demand.FAMILIES):
  if j>i:
   values=[r['cosines'][i][j] for r in records]
   report['negativeCosineBatches'][family+'/'+other]={'count':sum(v<0 for v in values),'mean':float(np.mean(values)),'median':float(np.median(values))}
report['medianNorms']=np.median([r['norms'] for r in records],axis=0).tolist()
write(root/'report.json',report)
print(report,flush=True)
