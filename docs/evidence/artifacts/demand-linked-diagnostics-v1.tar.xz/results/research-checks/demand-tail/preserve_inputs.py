"""Archive exact inputs and Train-only diagnostic measurements, verifying every member."""
import hashlib
import json
import lzma
import shutil
import tarfile
from pathlib import Path

CHECKS=Path('results/research-checks/demand-tail')
DEST=Path('docs/evidence/artifacts')

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f,'sha256').hexdigest()

def package(name, files):
    destination=DEST/name
    assert not destination.exists(), destination
    manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
    with tarfile.open(destination,'w:xz',preset=6) as archive:
        for name,path in files.items():
            archive.add(path,arcname=name)
    seen=set()
    with lzma.open(destination,'rb') as f, tarfile.open(fileobj=f,mode='r|') as archive:
        for member in archive:
            if not member.isfile():
                continue
            expected=manifest[member.name]
            assert member.size==expected['bytes']
            assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==expected['sha256']
            seen.add(member.name)
    assert seen==set(manifest)
    result={'path':str(destination),'bytes':destination.stat().st_size,'sha256':sha(destination),'verifiedEveryMember':True,'files':manifest}
    print({k:v for k,v in result.items() if k!='files'},flush=True)
    return result

shutil.copy2('results/smoke.json', CHECKS/'smoke.json')
files={}
for name in ('core-retail-train-v1','core-retail-linked-v1'):
    for p in sorted((Path('data/processed')/name).iterdir()):
        if p.is_file(): files[str(p)]=p
for name in ('data/processed/core-retail-holdout-v1/selection.json','results/research-checks/concentration-quadrature.json','results/research-checks/retail-linked-selection.json','scripts/expand_retail_train.py','src/newsvendor/retail_expansion.py','scripts/prepare_retail_holdout.py'):
    p=Path(name);files[name]=p
result={'data':package('retail-linked-data-v1.tar.xz',files)}
files={}
for name in ('newsvendor-demand-tail-audit-v1','newsvendor-demand-tail-allocation-v1','newsvendor-demand-family-gradients-v1'):
    for p in sorted((Path('/dev/shm')/name).iterdir()):
        if p.is_file(): files[str(Path('results/research-checks/demand-tail')/name/p.name)]=p
for p in sorted(CHECKS.iterdir()):
    if p.is_file() and p.name not in ('training.log','preservation.json','preservation.log'):
        files[str(p)]=p
for name in ('results/research-checks/demand-curve-audit/epoch-07.pt',):
    files[name]=Path(name)
result['diagnostics']=package('demand-linked-diagnostics-v1.tar.xz',files)
(CHECKS/'preservation.json').write_text(json.dumps(result,indent=2)+'\n')
