"""Train-source-held quantile and order diagnostics at the fixed selected epoch."""
import os
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

from newsvendor import demand, sequence
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_tool_eval import weights_hash

root = Path('/dev/shm/newsvendor-demand-tail-audit-v1')
require(not root.exists(), 'Preserve previous audit')
require(os.environ.get('CUDA_VISIBLE_DEVICES') == 'GPU-674d64b8-4bdf-7006-1791-5dc7f7245409'
        and torch.cuda.device_count() == 1 and 'L40S' in torch.cuda.get_device_name(0), 'L40S only')
torch.set_num_threads(1)
reference = Path('results/research-checks/demand-curve-audit')
parent = read(reference/'report.json')
epoch = min(parent['epochs'],key=lambda x:x['heldNLL'])['epoch']
held, fitting = set(parent['heldFamilies']), set(parent['fitFamilies'])
require(held and not held & fitting, 'Source leakage')
dataset = Path('data/processed/core-retail-train-v1')
rows = [r for r in lines(dataset/'inputs.jsonl') if r['component']=='retail' and r['split']=='train' and r['family'] in held]
ids = {r['id'] for r in rows}
labels = {r['id']:r['target'] for r in lines(dataset/'labels.jsonl') if r['id'] in ids}
samples = sequence.samples(rows, labels)
origins = [{k:v for k,v in r.items() if k!='sequence'} for r in samples]
require(origins == lines(reference/'held-origins.jsonl'), 'Changed Train-held origins')
checkpoint_path = reference/f'epoch-{epoch:02}.pt'
checkpoint = torch.load(checkpoint_path,map_location='cpu',weights_only=True)
model = sequence.DemandEncoder().to('cuda').eval()
model.load_state_dict(checkpoint['weights'])
root.mkdir()
report = {
    'scope':'Train-only held-source diagnosis at the already selected parameter epoch; not independent evaluation',
    'devUsed':False,'testUsed':False,'holdoutUsed':False,
    'epoch':epoch,'checkpoint':str(checkpoint_path),'checkpointHash':digest(checkpoint_path.read_bytes()),
    'weightHash':weights_hash(model.state_dict()),'parentReportHash':digest((reference/'report.json').read_bytes()),
    'scriptHash':digest(Path(__file__).read_bytes()),'source':provenance({}),
    'fitFamilies':sorted(fitting),'heldFamilies':sorted(held),'sourceOverlap':0,
    'dataManifestHash':digest(read(dataset/'manifest.json')),'originsHash':digest(origins),
    'limitations':['The same held Train sources selected parameter epoch 7 previously.',
                   'Complete periods are selected by the inventory process; their coverage is not latent-demand calibration.',
                   'Censored totals are lower bounds, not observed demand. All future values are scoring targets only.',
                   'No trained selector is used; compare each frozen family separately.'],
}
write(root/'registered.json',report)
jsonl(root/'origins.jsonl',origins)
levels = np.array([.1,.5,.75,.9,.95])
records=[]
started=time.perf_counter()
with torch.inference_mode():
    for start in range(0,len(samples),128):
        batch=samples[start:start+128]
        out=model([r['sequence'] for r in batch],[r['horizon'] for r in batch],daily=True)
        likelihood=sequence.losses(out,batch,checkpoint['settings']).cpu()
        params={f:out['raw'][f].cpu() for f in demand.FAMILIES}
        for i,row in enumerate(batch):
            record={k:v for k,v in row.items() if k!='sequence'}
            observed=row['y']*row['scale']
            record['distributions']={}
            for j,family in enumerate(demand.FAMILIES):
                raw=params[family][i]
                first,second=demand.parameters(family,raw)
                distribution={'family':family,'normalizationScale':row['scale'],
                              'parameters':{'zeroProbability':min(max(float(raw[0].sigmoid()),1e-8),1-1e-8),
                                            demand.PARAMETERS[family][0]:float(first),demand.PARAMETERS[family][1]:float(second)}}
                F=demand.pmf(distribution)
                values,mass=np.asarray(F).T
                quantiles=values[np.minimum(np.searchsorted(mass.cumsum(),levels),len(values)-1)]
                q=quantiles[[1,2,3]]
                if start < 128:
                    for k,cost in enumerate((1,3,9)):
                        actual=demand.order(F,underage=cost)['q']
                        require(abs(actual-q[k]) < 1e-9, 'Discrete quantile differs from actual optimizer')
                excess=np.maximum(q-observed,0)
                shortage=np.maximum(observed-q,0)
                record['distributions'][family]={
                    'distribution':distribution,'raw':raw.tolist(),'dailyZeroLogit':float(out['dailyZero'][family][i]),
                    'normalizedNLL':float(likelihood[i,j]),'levels':levels.tolist(),'quantiles':quantiles.tolist(),
                    'mean':float(values@mass),'q':q.tolist(),
                    'overage':None if row['censored'] else excess.tolist(),
                    'underage':None if row['censored'] else shortage.tolist(),
                    'loss':None if row['censored'] else (excess+np.array([1,3,9])*shortage).tolist(),
                    'lossLowerBound':(np.array([1,3,9])*shortage).tolist() if row['censored'] else None,
                    'knownExceedance':(observed>quantiles).tolist(),
                }
            records.append(record)
        if start % 1024 == 0:
            print({'done':len(records),'seconds':time.perf_counter()-started},flush=True)
jsonl(root/'predictions.jsonl',records)
groups={}
for horizon in (1,7):
    group=[r for r in records if r['horizon']==horizon]
    complete=[r for r in group if not r['censored']]
    by_family={}
    for family in demand.FAMILIES:
        forecasts=[r['distributions'][family] for r in group]
        exact=[r['distributions'][family] for r in complete]
        known_above=np.array([r['knownExceedance'] for r in forecasts])
        below=np.array([not r['censored'] for r in group])[:,None] & ~known_above
        by_family[family]={
            'observationNLL':float(np.mean([r['normalizedNLL'] for r in forecasts])),
            'completeOrderLoss':np.mean([r['loss'] for r in exact],axis=0).tolist(),
            'completeOverage':np.mean([r['overage'] for r in exact],axis=0).tolist(),
            'completeUnderage':np.mean([r['underage'] for r in exact],axis=0).tolist(),
            'completeQuantileCoverage':(1-np.mean([r['knownExceedance'] for r in exact],axis=0)).tolist(),
            'quantileCoverageBounds':np.stack([below.mean(0),(~known_above).mean(0)],axis=-1).tolist(),
            'completeMedianBias':float(np.mean([r['distributions'][family]['q'][0]-r['y']*r['scale'] for r in complete])),
        }
    groups[str(horizon)]={'forecasts':len(group),'sources':len({r['family'] for r in group}),
                          'complete':len(complete),'completeSources':len({r['family'] for r in complete}),
                          'levels':levels.tolist(),'costRatios':[1,3,9],'families':by_family}
report['groups']=groups
report['seconds']=time.perf_counter()-started
report['predictionsHash']=digest((root/'predictions.jsonl').read_bytes())
report['optimizerCheck']={'cases':128,'familyCount':3,'costRatios':[1,3,9],'exactWithin':1e-9}
write(root/'report.json',report)
print(groups,flush=True)
