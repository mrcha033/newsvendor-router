"""Select a supported parameter expression from observed, applicable evidence."""

import copy

from .construction import candidates, matches
from .corpus import SLOTS
from .io import require
from .structured_forecast import compatible, source_issue
from .structured_inputs import OPS


def expression_key(expression):
    return expression["op"], tuple(
        (a["kind"], a["id"], a["start"], a["end"]) for a in expression["operands"]
    )


def parameter_candidates(value, view, slot):
    """No labels or unread source tokens; retain the existing supported document scope."""
    atoms = {
        (
            a["location"]["kind"],
            a["location"]["id"],
            a["location"]["start"],
            a["location"]["end"],
        ): i
        for i, a in enumerate(view["atoms"])
    }
    result = []
    for expression in candidates(value, slot):
        if (
            not matches(expression["doc"], slot)
            or not compatible(expression, slot)
            or source_issue(value, slot, expression)
        ):
            continue
        locations = [
            {
                "kind": "document",
                "id": expression["doc"]["id"],
                "start": a["span"][0],
                "end": a["span"][1],
            }
            for a in expression["args"]
        ]
        key = expression_key({"op": expression["op"], "operands": locations})
        if not all(location in atoms for location in key[1]):
            continue
        result.append(
            {
                "id": expression["id"],
                "key": key,
                "atoms": [atoms[location] for location in key[1]],
                "value": expression["value"],
                "expression": {"op": expression["op"], "operands": locations},
            }
        )
    return result


def decode_parameters(value, view, output, fields, method="scoped"):
    """Repair rejected compute selections; do not override missing/conflict/type heads."""
    require(method in ("scoped", "first"), "Unknown parameter decoder")
    decoded, diagnostics = copy.deepcopy(fields), []
    for i, field in enumerate(decoded):
        slot = field["name"]
        if (
            slot not in SLOTS
            or field["mode"] != "compute"
            or field["state"] != "verified"
            or (slot == "b" and field["type"] != "preference")
        ):
            continue
        choices = parameter_candidates(value, view, slot)
        selected = field.get("expression")
        # Preserve every originally accepted expression, including supported
        # selected sources with arbitrary titles. Only rejected selections retry.
        if selected:
            key = expression_key(selected)
            for expression in candidates(value, slot):
                if not compatible(expression, slot) or source_issue(value, slot, expression):
                    continue
                old = {
                    "op": expression["op"],
                    "operands": [
                        {
                            "kind": "document",
                            "id": expression["doc"]["id"],
                            "start": a["span"][0],
                            "end": a["span"][1],
                        }
                        for a in expression["args"]
                    ],
                }
                if expression_key(old) == key:
                    break
            else:
                expression = None
            if expression is not None:
                continue
        if not choices:
            diagnostics.append({"field": slot, "candidates": 0, "changed": False})
            continue
        relation = output["relation"][i].float().log_softmax(-1)
        left = output["operand1"][i].float().log_softmax(-1)
        right = output["operand2"][i].float().log_softmax(-1)
        scores = []
        for choice in choices:
            ids = choice["atoms"]
            score = relation[OPS.index(choice["expression"]["op"])] + left[ids[0]]
            if len(ids) == 2:
                score = score + right[ids[1]]
            scores.append(float(score))
        index = max(range(len(choices)), key=lambda j: scores[j]) if method == "scoped" else 0
        choice = choices[index]
        field.update(
            value=choice["value"],
            expression=choice["expression"],
            evidence=choice["expression"]["operands"],
        )
        field.pop("reason", None)
        diagnostics.append(
            {
                "field": slot,
                "candidates": len(choices),
                "changed": True,
                "selected": choice["id"],
                "score": scores[index],
                "method": method,
            }
        )
    return decoded, diagnostics
