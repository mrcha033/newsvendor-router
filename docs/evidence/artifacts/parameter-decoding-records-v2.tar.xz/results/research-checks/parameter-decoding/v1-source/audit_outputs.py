"""Independently audit paired raw fields, emitted quantities and recorded costs."""

import argparse
import gzip
import json
import math
from collections import Counter
from pathlib import Path

from newsvendor.io import lines, read, require, write
from newsvendor.optimizer import optimal, risk

parser = argparse.ArgumentParser()
parser.add_argument('--split', choices=('train', 'dev'), required=True)
args = parser.parse_args()
root = Path('/dev/shm/newsvendor-parameter-decoding-v1')
directory = root / args.split
report = read(directory / 'report.json')
environment = {r['id']: r for r in lines(root / 'prepared' / f'{args.split}-environment.jsonl')}
result = {'split': args.split, 'conditions': {}, 'scope': 'Full paired raw trajectory audit, not independent source generalization'}


def equal(a, b):
    return (a is b) if a is None or b is None else math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-8)


def verify(row):
    events = row['events']
    task = events[-1]['input']['task']
    actions = [event['action'] for event in events]
    cost = sum(1.0 if a == 'retrieve' else task['costs'][a] for a in actions if a not in ('hold', 'handoff'))
    require(equal(row['requestCost'], cost), 'Request cost mismatch')
    require(row['interactions'] == sum(a not in ('hold', 'handoff') for a in actions), 'Interaction count mismatch')
    emitted = events[-1]['state']['q'] if row['result'] == 'handoff' else None
    require(equal(row['q'], emitted), 'Wrong emitted quantity')
    terminal = row['terminalLoss']
    require(equal(row['total'], None if terminal is None else terminal + cost), 'Total decomposition mismatch')
    env = environment[row['id']]
    if row['kind'] == 'generated':
        theta = env['gold']['theta']
        loss = task['hold'] if emitted is None else max(0, risk(emitted, theta) - optimal(theta, task['bounds'])['cost'])
        if row['falseHandoff']:
            loss = max(loss, task['hold'])
        require(equal(terminal, loss), 'Generated emitted-quantity loss mismatch')
    elif row['outcomeComplete'] and not row['falseHandoff']:
        theta = env['financialAnnotations']
        demand = sum(env['target']['answer'])
        loss = task['hold'] if emitted is None else (
            (theta['c'] - theta['v']) * max(emitted - demand, 0)
            + (theta['p'] - theta['c'] + theta['b']) * max(demand - emitted, 0)
        )
        require(equal(terminal, loss), 'Retail emitted-quantity loss mismatch')
    elif row['kind'] == 'retail' and row['falseHandoff']:
        require(terminal >= task['hold'], 'Invalid handoff penalty missing')


for condition in report['conditions']:
    counts, repairs, choices = Counter(), Counter(), Counter()
    streams = [gzip.open(directory / f'{condition}-{name}.jsonl.gz', 'rt') for name in ('parent', 'scoped', 'first')]
    seen_initial = set()
    try:
        for records in zip(*streams, strict=True):
            a, b, c = [json.loads(line) for line in records]
            require(a['id'] == b['id'] == c['id'] and a['missingResponses'] == b['missingResponses'] == c['missingResponses'], 'Unpaired paths')
            for name, row in zip(('parent', 'scoped', 'first'), (a, b, c), strict=True):
                verify(row)
                counts[name + 'Paths'] += 1
            if a['id'] not in seen_initial:
                seen_initial.add(a['id'])
                raw = [r['events'][0]['state']['rawFields'] for r in (a, b, c)]
                require(raw[0] == raw[1] == raw[2], 'Initial raw neural fields changed')
                for item in b['events'][0]['state']['parameterDecoding']:
                    choices[str(item['candidates'])] += 1
                    if item['changed']:
                        repairs[item['field']] += 1
            for name, row in (('scoped', b), ('first', c)):
                counts[name + 'ActionsChanged'] += int([e['action'] for e in a['events']] != [e['action'] for e in row['events']])
                counts[name + 'QuantityChanged'] += int(not equal(a['q'], row['q']))
                counts[name + 'TotalChanged'] += int(not equal(a['total'], row['total']))
            counts['scopedFirstActionsDiffer'] += int([e['action'] for e in b['events']] != [e['action'] for e in c['events']])
            counts['scopedFirstQuantityDiffer'] += int(not equal(b['q'], c['q']))
            counts['scopedFirstTotalDiffer'] += int(not equal(b['total'], c['total']))
    finally:
        for stream in streams:
            stream.close()
    result['conditions'][condition] = {
        'counts': dict(counts), 'uniqueInitialInputs': len(seen_initial),
        'initialRepairsByField': dict(repairs), 'retryCandidateCounts': dict(choices),
    }
result.update(allCostsVerified=True, initialRawNeuralFieldsIdentical=True)
write(Path('results/research-checks/parameter-decoding') / f'{args.split}-outcome-audit.json', result)
print(json.dumps(result, indent=2))
