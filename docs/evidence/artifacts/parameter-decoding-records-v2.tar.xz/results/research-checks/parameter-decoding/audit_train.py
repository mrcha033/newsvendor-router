"""Fixed Train-only diagnosis before changing the parameter decoder."""

import copy
import json
import math
import time
from collections import Counter
from pathlib import Path

import torch

from newsvendor.bundle import file_hash, load_bundle
from newsvendor.cli import provenance
from newsvendor.construction import candidates
from newsvendor.corpus import SLOTS
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_forecast import compatible, source_issue
from newsvendor.structured_inputs import OPS, prepare, research_input
from newsvendor.structured_model import extract
from newsvendor.structured_retail import parameter_metrics, parameter_record
from newsvendor.structured_rollout import FIELDS, TEXT, ResearchRouter


root = Path('results/research-checks/parameter-decoding')
require(not (root / 'audit.json').exists(), 'Preserve the earlier audit')
manifest = read('results/parameter-contrasts-v2/manifest.json')
all_rows = lines(manifest['partitions']['fit']['path'])
conditions = sorted({r['contrast'] for r in all_rows})
rows = []
for condition in conditions:
    part = [r for r in all_rows if r['contrast'] == condition]
    rows.extend(sorted(part, key=lambda r: digest([9271, r['inputHash']]))[:32])
require(all(r['split'] == 'train' for r in rows), 'Train only')
bundle = '/dev/shm/newsvendor-recovery-scope-restored-v1/composed-model'
write(root / 'audit-registration.json', {
    'source': provenance({}), 'bundleManifestHash': file_hash(Path(bundle) / 'manifest.json'),
    'inputFileHash': file_hash(manifest['partitions']['fit']['path']),
    'inputs': [{k:r[k] for k in ('id','family','contrast','inputHash')} for r in rows],
    'testUsed': False, 'devUsed': False, 'trainingPerformed': False,
})
torch.set_num_threads(4)
torch.use_deterministic_algorithms(True)
model, tokenizer, config, _ = load_bundle(bundle, 'cuda')
router = ResearchRouter(model, tokenizer, config['encoder'], False)
counts, raw = Counter(), []
started = time.perf_counter()
with torch.inference_mode():
    for index, row in enumerate(rows):
        value = row['input']
        view = prepare(research_input(value, config['encoder']), tokenizer, config['encoder'],
                       fields=FIELDS, actions=[{'id':'hold','text':TEXT['hold']}])
        output = model(view)
        predicted = extract(view, output)
        ref = parameter_record(value)  # Scoring only, after predictions and candidates.
        details = []
        for i, field in enumerate(predicted[:4]):
            slot = field['name']
            legal = []
            for expression in candidates(value, slot):
                if not compatible(expression, slot) or source_issue(value, slot, expression):
                    continue
                ids = []
                for arg in expression['args']:
                    ids.append(next((j for j,a in enumerate(view['atoms'])
                        if a['location']['kind']=='document'
                        and a['location']['id']==expression['doc']['id']
                        and [a['location']['start'], a['location']['end']]==arg['span']), None))
                if any(j is None for j in ids):
                    continue
                score = float(output['relation'][i].log_softmax(-1)[OPS.index(expression['op'])])
                score += float(output['operand1'][i].log_softmax(-1)[ids[0]])
                if len(ids)>1:
                    score += float(output['operand2'][i].log_softmax(-1)[ids[1]])
                legal.append({'id':expression['id'],'op':expression['op'],
                              'value':expression['value'],'score':score,'atoms':ids})
            expected = ref['values'].get(slot)
            actual = field['value']
            ok = actual is None if expected is None else isinstance(actual,(float,int)) and math.isclose(actual,expected,rel_tol=1e-7,abs_tol=1e-7)
            if not ok:
                counts['errors'] += 1
                counts['mode:'+field['mode']] += 1
                counts['state:'+field['state']] += 1
                counts['legal-empty' if not legal else 'legal-present'] += 1
                if legal:
                    best = max(legal,key=lambda e:e['score'])
                    counts['best-correct'] += expected is not None and math.isclose(best['value'],expected,rel_tol=1e-7,abs_tol=1e-7)
            details.append({'slot':slot,'prediction':field,'expected':expected,'expectedState':ref['state'][slot],
                            'correctValue':ok,'legal':legal})
        raw.append({k:row[k] for k in ('id','family','contrast','inputHash')} | {'fields':details})
        if (index+1)%32==0:
            print({'cases':index+1,'counts':dict(counts)},flush=True)
jsonl(root/'audit-rows.jsonl',raw)
write(root/'audit.json',{'cases':len(rows),'counts':dict(counts),'seconds':time.perf_counter()-started,
                       'rawHash':file_hash(root/'audit-rows.jsonl'),'testUsed':False,'devUsed':False})
print(read(root/'audit.json'),flush=True)
