"""Stage exact published inputs, measurements and weights without working data."""

import argparse
import gzip
import shutil
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

parser = argparse.ArgumentParser()
parser.add_argument('--split', choices=('train', 'dev'), required=True)
args = parser.parse_args()
root = Path('/dev/shm/newsvendor-parameter-decoding-reproduction-v2')
require(not root.exists(), 'Preserve prior reproduction')
project = root / 'project'
copied = {}


def put(source, destination):
    source = Path(source)
    target = project / destination
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    checksum = file_hash(source)
    require(checksum == file_hash(target), 'Copy changed bytes')
    copied[str(destination)] = {'sha256': checksum, 'bytes': target.stat().st_size}


for path in Path('src/newsvendor').glob('*.py'):
    put(path, path)
for path in [
    'scripts/evaluate_parameters.py', 'scripts/evaluate_operands.py',
    'scripts/evaluate_responses.py', 'scripts/prepare_parameter_contrasts.py',
    'scripts/predict_research.py', 'docs/evidence/scripts/reproduce-parameters.py',
    'pyproject.toml', 'uv.lock',
]:
    put(path, Path(path))
bundle = Path('/dev/shm/newsvendor-recovery-scope-restored-v1/composed-model')
for path in bundle.rglob('*'):
    if path.is_file():
        put(path, Path('public/recovery-v1') / path.relative_to(bundle))
records = Path('/dev/shm/newsvendor-parameter-decoding-v2')
directory = records / args.split
report = read(directory / 'report.json')
metadata = {}
for path in sorted(directory.iterdir()):
    if path.is_file():
        if path.name in report['rawHashes']:
            require(file_hash(path) == report['rawHashes'][path.name], 'Raw output changed')
        if path.name.endswith('.jsonl.gz'):
            name = path.name[:-3]
            destination = Path('results/parameter-decoding-v2') / args.split / name
            target = project / destination
            target.parent.mkdir(parents=True, exist_ok=True)
            with gzip.open(path, 'rb') as source, target.open('wb') as stream:
                shutil.copyfileobj(source, stream)
            metadata[path.name] = {
                'path': name, 'bytes': target.stat().st_size, 'sha256': file_hash(target),
                'sourceGzipSha256': file_hash(path), 'sourceGzipBytes': path.stat().st_size,
            }
            copied[str(destination)] = {'sha256': file_hash(target), 'bytes': target.stat().st_size}
        elif path.name != 'raw-format.json':
            put(path, Path('results/parameter-decoding-v2') / args.split / path.name)
write(directory / 'raw-format.json', metadata)
put(directory / 'raw-format.json', Path('results/parameter-decoding-v2') / args.split / 'raw-format.json')
put(records / 'prepared' / f'{args.split}-environment.jsonl',
    Path('results/parameter-decoding-v2/prepared') / f'{args.split}-environment.jsonl')
write(root / 'copied-files.json', copied)
write('results/research-checks/parameter-decoding/reproduction-stage.json', {
    'root': str(root), 'split': args.split, 'copiedFiles': copied,
    'method': 'Exact copies of the existing public inference bundle and scheduled public sources, inputs and raw measurements. Original working data/results and network are blocked during reproduction.',
})
print({'root': str(root), 'files': len(copied)})
