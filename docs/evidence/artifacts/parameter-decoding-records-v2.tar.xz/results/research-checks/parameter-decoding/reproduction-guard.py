"""Block network and access to working research data during isolated reproduction."""

import os
import sys
from pathlib import Path

blocked = [
    Path('/home/yunmin/newsvendor-router/data'),
    Path('/home/yunmin/newsvendor-router/results'),
    Path('/dev/shm/newsvendor-parameter-decoding-v1'),
    Path('/dev/shm/newsvendor-parameter-decoding-v2'),
    Path('/dev/shm/newsvendor-recovery-scope-restored-v1'),
    Path('/dev/shm/newsvendor-recovery-replay-v1'),
    Path('/dev/shm/newsvendor-response-state-generated-v1'),
    Path('/dev/shm/newsvendor-response-state-retail-v1'),
    Path('/dev/shm/newsvendor-public-download-1654e77'),
]


def audit(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo'):
        raise RuntimeError('Network forbidden during published-assets reproduction')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.path.abspath(os.fsdecode(args[0])))
        if any(path.is_relative_to(root) or path.resolve().is_relative_to(root) for root in blocked):
            raise RuntimeError('Working research data forbidden: ' + str(path))


sys.addaudithook(audit)
