"""Publish the fixed decoder comparison, exact raw streams and executed sources."""

import importlib.util
from pathlib import Path

from newsvendor.io import read, require, write

spec = importlib.util.spec_from_file_location('archive_tools', 'results/research-checks/recovery-balance/publish.py')
archive_tools = importlib.util.module_from_spec(spec)
spec.loader.exec_module(archive_tools)
root = Path('/dev/shm/newsvendor-parameter-decoding-v2')
checks = Path('results/research-checks/parameter-decoding')
destination = Path('results/parameter-decoding-v2')
files, raw = {}, {}
reports = {}
for stage in ('diagnose', 'train', 'dev'):
    directory = root / stage
    if not directory.exists():
        continue
    report = read(directory / 'report.json')
    require('seconds' in report, 'Do not publish unfinished evaluation')
    reports[stage] = report
    raw[stage] = archive_tools.raw_entries(directory, destination / stage)
    for path in directory.iterdir():
        if not path.is_file():
            continue
        if path.name in report['rawHashes']:
            require(archive_tools.sha(path) == report['rawHashes'][path.name], 'Raw bytes changed')
        if not path.name.endswith('.jsonl.gz'):
            files[str(destination / stage / path.name)] = path
for path in (root / 'prepared').iterdir():
    if path.is_file():
        files[str(destination / 'prepared' / path.name)] = path
plan = read('configs/research-parameter-decoding-v2.json')
for name, path in (
    ('train-initial-inputs.jsonl', plan['cohorts']['train']['inputs']),
    ('contrast-manifest.json', plan['contrasts']),
    ('contrast-fit.jsonl', 'results/parameter-contrasts-v2/fit.jsonl'),
    ('contrast-held.jsonl', 'results/parameter-contrasts-v2/held.jsonl'),
):
    require(archive_tools.sha(path) == plan['files'][path], 'Registered input changed')
    files[str(destination / 'prepared' / name)] = Path(path)
previous_root = Path('/dev/shm/newsvendor-parameter-decoding-v1')
previous_reports = {stage: read(previous_root / stage / 'report.json') for stage in ('diagnose', 'train')}
for stage in ('diagnose', 'train', 'dev', 'prepared'):
    for path in (previous_root / stage).iterdir():
        if path.is_file() and not path.name.endswith('.jsonl.gz'):
            files[str(Path('results/parameter-decoding-v1') / stage / path.name)] = path
for path in checks.rglob('*'):
    if path.is_file() and '__pycache__' not in path.parts and not path.name.startswith('publication'):
        files[str(path)] = path
for path in [
    *Path('src/newsvendor').glob('*.py'),
    Path('scripts/evaluate_parameters.py'), Path('scripts/evaluate_operands.py'),
    Path('scripts/evaluate_responses.py'), Path('scripts/prepare_parameter_contrasts.py'),
    Path('scripts/predict_research.py'), Path('tests/test_parameter_decode.py'),
    Path('configs/research-parameter-decoding-v1.json'), Path('configs/research-parameter-decoding-v2.json'),
    Path('docs/evidence/scripts/reproduce-parameters.py'),
    Path('.github/workflows/ci.yml'), Path('pyproject.toml'), Path('uv.lock'),
    Path('README.md'), Path('AGENTS.md'), Path('docs/parameter-decoding.md'),
    Path('docs/research-scope.md'), Path('docs/model-bundle.md'),
]:
    files[str(path)] = path
train_raw = read(checks / 'train-raw-publication-v2.json')
require(archive_tools.sha(train_raw['path']) == train_raw['sha256'], 'Prepared Train archive changed')
require(train_raw['files'] == {name: {'bytes': size, 'sha256': checksum} for name, _, size, checksum in raw['diagnose'] + raw['train']}, 'Prepared Train raw members changed')
artifacts = {
    'records': archive_tools.publish(Path('docs/evidence/artifacts/parameter-decoding-records-v2.tar.xz'), files),
    'trainRaw': train_raw,
    'v1TrainRaw': read(checks / 'train-raw-publication.json'),
    'v1InterruptedRaw': read(checks / 'interrupted-raw-publication.json'),
}
require(archive_tools.sha(artifacts['v1TrainRaw']['path']) == artifacts['v1TrainRaw']['sha256'], 'Previous measurements changed')
require(archive_tools.sha(artifacts['v1InterruptedRaw']['path']) == artifacts['v1InterruptedRaw']['sha256'], 'Interrupted measurements changed')
if 'dev' in raw:
    artifacts['devRaw'] = read(checks / 'dev-raw-publication-v2.json')
    require(archive_tools.sha(artifacts['devRaw']['path']) == artifacts['devRaw']['sha256'], 'Prepared Dev archive changed')
    require(artifacts['devRaw']['files'] == {name: {'bytes': size, 'sha256': checksum} for name, _, size, checksum in raw['dev']}, 'Prepared Dev raw members changed')
stage = read(checks / 'reproduction-stage.json')
for name, metadata in stage['copiedFiles'].items():
    if name.startswith('public/recovery-v1/'):
        continue
    actual = next((a['files'][name] for a in artifacts.values() if name in a['files']), None)
    require(actual == metadata, 'Published bytes differ from isolated reproduction: ' + name)
evidence = {
    'scope': 'Observed document parameter selection and own-state Newsvendor requests/orders. Controlled document/response conditions, not evidence on real organizational work.',
    'trainingPerformed': False, 'testUsed': False, 'newSourceHoldoutUsed': False,
    'devUsed': 'dev' in reports, 'weightsChanged': False,
    'decoderAdopted': bool(reports.get('dev', {}).get('eligible')),
    'model': {
        'name': 'recovery-v1', 'weightsHash': plan['weightsHash'],
        'sourceHash': plan['sourceHash'],
        'methods': {'parent': 'independent', 'scoped': 'existing scores over applicable observed expressions', 'first': 'first eligible expression under the same neural gates'},
        'manifest': read(Path(plan['bundle']) / 'manifest.json'),
    },
    'reports': {k: {a: b for a, b in v.items() if a not in ('source', 'rawHashes')} for k, v in reports.items()},
    'outcomeAudits': {k: read(checks / f'{k}-v2-outcome-audit.json') for k in ('train', 'dev') if (checks / f'{k}-v2-outcome-audit.json').exists()},
    'precedingAttempt': {
        'adopted': False, 'stop': read(checks / 'v1-stopped.json'),
        'reports': {k: {a: b for a, b in v.items() if a not in ('source', 'rawHashes')} for k, v in previous_reports.items()},
        'outcomeAudit': read(checks / 'train-outcome-audit.json'),
        'fitCandidateAudit': read(checks / 'fit-candidate-audit.json'),
        'conflictDiagnosis': read(checks / 'conflict-source-audit.json'),
    },
    'reproduction': read(checks / 'reproduction.json'),
    'checks': {
        'tests': {'passed': 374, 'logHash': archive_tools.sha(checks / 'tests-v2.log')},
        'sourceChecksHash': archive_tools.sha(checks / 'source-checks-v2.json'),
        'smoke': read(checks / 'smoke-v2.json'),
        'cli': read(checks / 'cli-check-v2.json'),
    },
    'artifacts': artifacts,
    'rawFormat': 'Archives contain exact decompressed JSONL bytes from every measured gzip stream, without changing records or order. raw-format.json preserves original gzip and raw-byte SHA256/size. Every archive member was checked and reproduced bytes matched the isolated run.',
    'limitations': [
        'Train contrast partitions separate augmentation families; the parent has seen original Train sources. They are not unseen-source generalization.',
        'The candidate parser supports existing document formats and observed SKU/period/version/unit metadata. This is not unrestricted document or TAT-QA extraction.',
        'Raw initial neural fields and all model weights remain unchanged. Decoded/final accuracy includes source constraints and observed manager replies.',
        'The first-candidate ablation retains neural state/type/mode gating; it is not a wholly rule-only system.',
        'Exact original retail Dev losses use five complete periods from four source families, under 35 controlled conditions. Document variants and response masks add repeated paths, not independent demand samples.',
        'Original Dev has already been used for development. No new Test or frozen 27-source holdout inference was performed.',
        'No new demand calibration or learned economic-value advantage is established.',
    ],
}
write('docs/evidence/research-parameter-decoding-results.json', evidence)
write(checks / 'publication.json', {k: {a: b for a, b in v.items() if a != 'files'} for k, v in artifacts.items()})
print({'decoderAdopted': evidence['decoderAdopted'], 'stages': list(reports)})
