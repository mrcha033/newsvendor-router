"""Replay only status transitions on immutable, deduplicated observed Train states."""
import copy
import hashlib
import json
from collections import Counter
from pathlib import Path
from newsvendor import corpus,structured_forecast
from newsvendor.construction import parameter_record
from newsvendor.io import digest,read,write,jsonl
from newsvendor.cli import provenance

plan=read('configs/l40s-parameter-state-v1.json')
root=Path('results/research-checks/response-state')
seen=set();records=[];counts=Counter();changed=[];regressions=[]
for name in plan['rollouts']:
 with Path(name).open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==plan['files'][name]
 with Path(name).open() as stream:
  for line in stream:
   rollout=json.loads(line);assert rollout['split']=='train'
   for event in rollout['events']:
    value=event['input'];key=digest([rollout['family'],value])
    if key in seen:continue
    seen.add(key)
    before=event['state'];after=copy.deepcopy(before)
    structured_forecast.copy_responses(value,after)
    for name in ('values','links','expressions','types'):assert before[name]==after[name],(rollout['id'],name)
    ref=parameter_record(value)
    for slot in corpus.SLOTS:
     old=before['state'][slot];new=after['state'][slot];expected=ref['state'][slot]
     counts['fields']+=1;counts['beforeErrors']+=old!=expected;counts['afterErrors']+=new!=expected
     if old!=new:
      item={'id':rollout['id'],'family':rollout['family'],'inputHash':key,'slot':slot,'before':old,'after':new,'expected':expected,'history':value['history'],'source':after['responseStates'].get(slot)}
      changed.append(item);counts[f'{old}->{new}']+=1
      if old==expected and new!=expected:regressions.append(item)
    records.append({'id':rollout['id'],'family':rollout['family'],'inputHash':key,'input':value,'before':before['state'],'after':after['state'],'expected':ref['state'],'responseStates':after['responseStates']})
assert len(seen)==1153
assert counts['beforeErrors']==198
assert not regressions
report={'scope':'Status transition diagnostic on fixed historical observed Train states, not sequential model effectiveness. Numeric/evidence/type fields preserved. No Dev/Test or hidden environment labels enter the transition.','testUsed':False,'devUsed':False,'states':len(seen),'families':len({r['family'] for r in records}),'counts':dict(counts),'regressions':regressions,'changed':changed,'source':provenance({}),'archives':{p:plan['files'][p] for p in plan['rollouts']}}
write(root/'train-audit.json',report);jsonl(root/'train-states.jsonl',records)
print({k:v for k,v in report.items() if k not in ('source','archives','changed')},flush=True)
