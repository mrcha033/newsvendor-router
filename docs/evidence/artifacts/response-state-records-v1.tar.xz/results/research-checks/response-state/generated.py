"""Compare observed-state validation on the original generated Dev with frozen weights."""
import copy
import gzip
import importlib.util
import json
import os
import tarfile
import time
from pathlib import Path
import torch
from newsvendor import corpus,structured_rollout,structured_train
from newsvendor.cli import provenance
from newsvendor.io import digest,jsonl,lines,read,write
from newsvendor.structured_metrics import generated_metrics
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.train import seed

plan=read('configs/research-response-state-generated-v1.json')
assert os.environ.get('CUDA_VISIBLE_DEVICES')==plan['gpu']
assert torch.cuda.device_count()==1 and 'L40S' in torch.cuda.get_device_name(0)
assert provenance({})['sourceHash']==plan['sourceHash']
for path,expected in plan['files'].items():assert digest(Path(path).read_bytes())==expected,path
assert plan['split']=='dev' and not plan['trainingAllowed']
root=Path(plan['output']);assert not root.exists();root.mkdir()
seed(42)
model,tokenizer,config,_=structured_train.load(plan['checkpoint'],'cuda')
assert weights_hash(model.state_dict())==plan['baseWeightsHash']
all_episodes=corpus.generate(read(config['researchConfig']))
corpus.audit(all_episodes)
episodes=[e for e in all_episodes if e['split']=='dev']
assert len(episodes)==60
observed=[{k:e[k] for k in ('id','family','split','input')} for e in episodes]
jsonl(root/'inputs.jsonl',observed)
jsonl(root/'environment.jsonl',[{k:e[k] for k in ('id','gold')} for e in episodes])
input_hash=digest((root/'inputs.jsonl').read_bytes())
before_path=Path(plan['beforeSource'])
spec=importlib.util.spec_from_file_location('newsvendor._response_before',before_path)
before=importlib.util.module_from_spec(spec);spec.loader.exec_module(before)
after=structured_rollout.structured_forecast
report={'scope':'Original generated Dev comparison of observed response-state validation. Same frozen encoder, field/type/state heads, demand GRU and action heads. This is a state transition correction, not learned extraction improvement.','testUsed':False,'trainingPerformed':False,'registration':plan,'source':provenance(plan),'inputHash':input_hash,'families':sorted({e['family'] for e in episodes}),'results':{},'rawHashes':{}}
write(root/'registered.json',report)
with tarfile.open(root/'source.tar.gz','w:gz') as archive:
 for p in [*sorted(Path('src').rglob('*.py')),Path(__file__),Path('configs/research-response-state-generated-v1.json'),before_path]:archive.add(p,arcname=str(p))
started=time.perf_counter();raw={}
def states(rows):
 unique={digest([r['family'],e['input']]):e for r in rows for e in r['events']}
 from newsvendor.structured_retail import parameter_metrics
 return {'states':len(unique),'fields':4*len(unique),'errors':sum(round(4*(1-parameter_metrics(e['input'],e['state'])['stateAccuracy'])) for e in unique.values()),'rawErrors':sum(round(4*(1-parameter_metrics(e['input'],e['state'])['rawStateAccuracy'])) for e in unique.values())}
for policy in ('value','checklist','no_value'):
 if policy=='no_value':
  delta=torch.load(plan['policyDelta'],map_location='cpu',weights_only=True)
  assert delta['baseWeightsHash']==plan['baseWeightsHash']
  model.load_state_dict(model.state_dict()|delta['weights'],strict=True)
  assert weights_hash(model.state_dict())==delta['weightsHash']
 weight_hash=weights_hash(model.state_dict())
 for name,module in (('before',before),('after',after)):
  structured_rollout.structured_forecast=module
  router=structured_rollout.ResearchRouter(model,tokenizer,config['encoder'],policy=='no_value');router.cache_states()
  rows=[]
  for episode in episodes:rows.append(structured_rollout.rollout(episode,router,explore=policy=='checklist'))
  key=name+'-'+policy;raw[key]=rows
  path=root/(key+'.jsonl.gz')
  with gzip.open(path,'wt',encoding='utf-8',compresslevel=3) as stream:
   for row in rows:stream.write(json.dumps(row,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n')
  report['rawHashes'][path.name]=digest(path.read_bytes())
  report['results'][key]={'metrics':generated_metrics(rows),'states':states(rows),'weightsHash':weight_hash}
  print({'condition':key,'seconds':time.perf_counter()-started,**report['results'][key]},flush=True)
  write(root/'partial.json',report)
structured_rollout.structured_forecast=after
from newsvendor.structured_compare import paired,research_measurements
report['comparisons']={p:paired(research_measurements(raw['after-'+p]),research_measurements(raw['before-'+p])) for p in ('value','checklist','no_value')}
report['changes']={p:[{'id':a['id'],'beforeActions':[e['action'] for e in a['events']],'afterActions':[e['action'] for e in b['events']],'beforeTotal':a['total'],'afterTotal':b['total']} for a,b in zip(raw['before-'+p],raw['after-'+p],strict=True) if a['total']!=b['total'] or [e['action'] for e in a['events']]!=[e['action'] for e in b['events']]] for p in ('value','checklist','no_value')}
report['historicalValueReproduced']=abs(report['results']['before-value']['metrics']['meanTotal']-plan['historicalGeneratedValue'])<1e-9
assert report['historicalValueReproduced']
report['gates']={p:{'totalNonincreasing':report['results']['after-'+p]['metrics']['meanTotal']<=report['results']['before-'+p]['metrics']['meanTotal']+1e-9,'stateErrorsNonincreasing':report['results']['after-'+p]['states']['errors']<=report['results']['before-'+p]['states']['errors']} for p in ('value','checklist','no_value')}
for policy,gates in report['gates'].items():
 a=report['results']['before-'+policy]['metrics'];b=report['results']['after-'+policy]['metrics']
 gates.update(noAdditionalFalseHandoffs=b['falseHandoffs']<=a['falseHandoffs'],noAdditionalResolvedRequests=b['resolvedFieldRequests']<=a['resolvedFieldRequests'],financialValuesPreserved=b['finalParameters']['parameterAccuracy']>=a['finalParameters']['parameterAccuracy'],financialTypesPreserved=b['finalParameters']['typeAccuracy']>=a['finalParameters']['typeAccuracy'],evidencePreserved=b['finalEvidenceAccuracy']>=a['finalEvidenceAccuracy'])
report['proceedToRetail']=all(all(g.values()) for g in report['gates'].values())
report['seconds']=time.perf_counter()-started;report['peakGpuBytes']=torch.cuda.max_memory_allocated()
assert digest((root/'inputs.jsonl').read_bytes())==input_hash
write(root/'report.json',report)
print({'completed':True,'seconds':report['seconds'],'gates':report['gates']},flush=True)
