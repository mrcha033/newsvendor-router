"""Inspect measured Train counterfactual costs after an unanswered mandatory retail field."""
import copy
import json
from collections import defaultdict
from pathlib import Path
from newsvendor import structured_forecast
from newsvendor.io import digest,read,write

plan=read('configs/l40s-parameter-state-v1.json')
groups=defaultdict(dict)
for path in plan['rollouts']:
 with Path(path).open() as stream:
  for line in stream:
   row=json.loads(line)
   if row['split']!='train':raise ValueError('Train only')
   value=row['events'][0]['input']
   if 'forecast' not in value['task']:continue
   state=copy.deepcopy(row['events'][0]['state'])
   structured_forecast.copy_responses(value,state)
   failed=[s for s in state['missing'] if state['state'].get(s)=='unavailable']
   if not failed or state['retrieval']['unreadChunks']!=0:continue
   allowed=structured_forecast.actions(value,state)
   if any(s in allowed for s in failed) or 'handoff' in allowed:continue
   key=digest([row['family'],value])
   first=row['forcedAction']
   item={'id':row['id'],'family':row['family'],'inputHash':key,'action':first,'failedFields':failed,'availableActions':allowed,'terminalLoss':row['terminalLoss'],'requestCost':row['requestCost'],'total':row['total'],'result':row['result'],'scale':row['scale'],'history':value['history'],'remaining':value['remaining'],'source':path}
   if first in groups[key]:
    old=groups[key][first]
    assert {k:v for k,v in old.items() if k!='source'}=={k:v for k,v in item.items() if k!='source'}
   groups[key][first]=item
paired=[]
for key,actions in groups.items():
 assert 'hold' in actions
 stop=actions['hold']
 for action,r in actions.items():
  if action=='hold':continue
  paired.append({**r,'holdTotal':stop['total'],'extraTotal':r['total']-stop['total'],'sameTerminalLoss':r['terminalLoss']==stop['terminalLoss']})
report={'scope':'Historical measured Train counterfactuals after an unanswered mandatory retail field; not a new rollout or deployed-policy saving estimate. Current observed-state validation applied only to identify public state conditions. No generated-minimax cases, Dev, Test or latent response probabilities used.','devUsed':False,'testUsed':False,'states':len(groups),'statesWithAnotherAction':len({r['inputHash'] for r in paired}),'otherActions':len(paired),'allOtherActionsEndInHold':all(r['result']=='hold' for r in paired),'allSameTerminalLoss':all(r['sameTerminalLoss'] for r in paired),'allPayExtra':all(r['extraTotal']>0 for r in paired),'records':paired}
write('results/research-checks/response-state/remaining-cost.json',report)
print({k:v for k,v in report.items() if k!='records'},flush=True)
