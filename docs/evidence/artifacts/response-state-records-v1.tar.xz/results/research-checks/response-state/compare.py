"""Audit fixed before/after Dev records without running further inference."""
import gzip
import hashlib
import itertools
from pathlib import Path

from newsvendor.io import lines, read, write


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


root = Path('/dev/shm/newsvendor-response-state-retail-v1')
before = Path('/dev/shm/newsvendor-response-eval-v1')
report = read(root / 'report.json')
registration = report['registration']
reference = registration['baselineEvidence']
assert sha(reference['path']) == reference['sha256']
old = read(reference['path'])
assert report['inputHash'] == old['inputHash']
assert report['environmentHash'] == old['environmentHash']
result = {'scope': 'Paired fixed-Dev comparison; no new inference or selection',
          'testUsed': False, 'beforeSourceHash': old['source']['sourceHash'],
          'sourceHash': report['source']['sourceHash'], 'policies': {}}
for policy in ('value', 'checklist', 'no_value'):
    baseline, current = old['results'][policy], report['results'][policy]
    assert current['fixedWeightsHash'] == baseline['fixedWeightsHash']
    assert sha(before / f'{policy}-rollouts.jsonl.gz') == baseline['rawHash']
    assert sha(root / f'{policy}-rollouts.jsonl.gz') == current['rawHash']
    checks = {}
    for noise in ('0', '0.1', '0.2'):
        a, b = baseline['metrics'][noise], current['metrics'][noise]
        same = ('parameterAccuracy', 'typeAccuracy', 'evidenceCorrect', 'evidenceCount')
        checks[noise] = {
            'financialValueTypeEvidencePreserved': all(a[k] == b[k] for k in same),
            'noAdditionalFalseHandoffs': b['falseHandoff']['mean'] <= a['falseHandoff']['mean'],
            'noAdditionalRedundantRequests': b['unnecessaryRequests']['mean'] <= a['unnecessaryRequests']['mean'],
            'resolvedStateAccuracyNondecreasing': b['stateAccuracy']['mean'] >= a['stateAccuracy']['mean'],
            'totalNonincreasing': b['totalOnCompletePeriods']['mean'] <= a['totalOnCompletePeriods']['mean'],
        }
    paired = 0
    for a, b in itertools.zip_longest(lines(before / f'{policy}-measurements.jsonl'),
                                    lines(root / f'{policy}-measurements.jsonl')):
        assert a is not None and b is not None
        assert (a['key'], a['missingResponses']) == (b['key'], b['missingResponses'])
        assert a['outcomeComplete'] == b['outcomeComplete'] and a['family'] == b['family']
        assert {k: v for k, v in a['metrics'].items() if k != 'stateAccuracy'} == {
            k: v for k, v in b['metrics'].items() if k != 'stateAccuracy'}
        assert b['metrics']['stateAccuracy'] >= a['metrics']['stateAccuracy']
        paired += 1
    import json
    raw_accuracy = []
    with gzip.open(before / f'{policy}-rollouts.jsonl.gz', 'rt') as left, gzip.open(
            root / f'{policy}-rollouts.jsonl.gz', 'rt') as right:
        raw_count = 0
        for x, y in itertools.zip_longest(left, right):
            assert x is not None and y is not None
            a, b = json.loads(x), json.loads(y)
            assert (a['id'], a['missingResponses']) == (b['id'], b['missingResponses'])
            assert (a['q'], a['result'], a['total']) == (b['q'], b['result'], b['total'])
            assert [e['action'] for e in a['events']] == [e['action'] for e in b['events']]
            for k in ('rawStateAccuracy', 'rawParameterAccuracy', 'rawTypeAccuracy'):
                assert a['parameters'][k] == b['parameters'][k]
            raw_accuracy.append(b['parameters']['rawStateAccuracy'])
            raw_count += 1
    assert raw_count == paired == 5376
    result['policies'][policy] = {
        'gates': checks, 'pairedMeasurements': paired,
        'allOtherCompactMetricsExactlyEqual': True,
        'allOrdersActionsAndTotalLossesExactlyEqual': True,
        'rawHeadFinalMetricsUnchanged': True,
        'rawFinalStateErrorsAcrossRepeatedResponseConditions': round(sum(4 * (1 - a) for a in raw_accuracy)),
        'resolvedStateAccuracy': {n: {'before': baseline['metrics'][n]['stateAccuracy']['mean'],
                                     'after': current['metrics'][n]['stateAccuracy']['mean']}
                                  for n in checks},
    }
result['allRegisteredGatesPassed'] = all(v for p in result['policies'].values()
                                       for g in p['gates'].values() for v in g.values())
write('results/research-checks/response-state/retail-comparison.json', result)
assert result['allRegisteredGatesPassed']
print({'allRegisteredGatesPassed': True, 'measurements': 16128}, flush=True)
