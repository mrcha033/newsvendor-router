"""Preserve observed-state correction measurements and the source used for each stage."""
import hashlib
import shutil
import tarfile
from pathlib import Path

from newsvendor.io import read, write


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def publish(path, files):
    assert not path.exists(), path
    manifest = {n: {'sha256': sha(p), 'bytes': p.stat().st_size} for n, p in files.items()}
    with tarfile.open(path, 'w:xz', preset=3) as archive:
        for name, source in files.items():
            archive.add(source, arcname=name)
    assert path.stat().st_size < 95 * 1024**2
    seen = set()
    with tarfile.open(path, 'r:xz') as archive:
        for member in archive:
            assert member.isfile()
            assert member.size == manifest[member.name]['bytes']
            assert hashlib.file_digest(archive.extractfile(member), 'sha256').hexdigest() == manifest[member.name]['sha256']
            seen.add(member.name)
    assert seen == set(manifest)
    result = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size,
              'verifiedEveryMember': True, 'files': manifest}
    print({k: v for k, v in result.items() if k != 'files'}, flush=True)
    return result


def main():
    live = Path('/dev/shm/newsvendor-response-state-retail-v1')
    generated = Path('/dev/shm/newsvendor-response-state-generated-v1')
    dest = Path('results/l40s-response-state-retail-v1')
    checks = Path('results/research-checks/response-state')
    report = read(live / 'report.json')
    comparison = read(checks / 'retail-comparison.json')
    assert comparison['allRegisteredGatesPassed']
    assert read(generated / 'report.json')['proceedToRetail']
    assert read(checks / 'checks.json')['tests'].startswith('317 passed')
    assert not dest.exists()
    dest.mkdir()
    raw = []
    for policy in ('value', 'checklist', 'no_value'):
        source = live / f'{policy}-rollouts.jsonl.gz'
        assert sha(source) == report['results'][policy]['rawHash']
        raw.append(publish(Path(f'docs/evidence/artifacts/response-state-{policy}-v1.tar.xz'),
                           {str(dest / source.name): source}))
    files = {str(dest / p.name): p for p in sorted(live.iterdir())
             if p.is_file() and not p.name.endswith('rollouts.jsonl.gz')}
    files[str(dest / 'policy-heads.pt')] = Path('results/research-checks/response-eval/policy-heads.pt')
    files.update({str(Path('results/l40s-response-state-generated-v1') / p.name): p
                  for p in sorted(generated.iterdir()) if p.is_file()})
    files.update({str(p): p for p in sorted(checks.iterdir())
                  if p.is_file() and p.name not in ('publication.log', 'publication.json')})
    for name in ('scripts/evaluate_responses.py', 'scripts/reproduce_responses.py',
                 'tests/test_response_state.py', 'configs/research-response-state-generated-v1.json',
                 'configs/research-response-state-retail-v1.json', '.github/workflows/ci.yml'):
        files[name] = Path(name)
    artifact = publish(Path('docs/evidence/artifacts/response-state-records-v1.tar.xz'), files)
    train = read(checks / 'train-audit.json')
    evidence = {**report, 'dataPrefix': str(dest), 'artifact': artifact, 'rawArtifacts': raw,
                'trainAudit': {k: v for k, v in train.items() if k not in ('changed', 'source')},
                'generatedComparison': read(generated / 'report.json'),
                'retailComparison': comparison, 'remainingCostDiagnostic': read(checks / 'remaining-cost.json'),
                'checks': read(checks / 'checks.json'),
                'policyDelta': read('results/research-checks/response-eval/policy-heads.json'),
                'interpretation': 'Observed reply-state validation corrects deterministic status handling. All weights remain fixed; raw-head metrics and actual order losses are unchanged. Controlled Dev only, with exact loss on five complete sales periods. No new Test or frozen-source holdout evaluation, no organizational efficacy claim.'}
    for name in ('report.json', 'registered.json', 'progress.json'):
        shutil.copy2(live / name, dest / name)
    write(dest / 'storage.json', {'artifact': artifact, 'rawArtifacts': raw})
    write('docs/evidence/research-response-state-results.json', evidence)
    write(checks / 'publication.json', {'artifact': artifact, 'rawArtifacts': raw})


if __name__ == '__main__':
    main()
