import hashlib
import os
import shutil
from pathlib import Path

from newsvendor.io import read, require, write

root = Path("results/l40s-research-state-replay-v3")
storage = read(root / "registered.json")["storage"]
source = Path(storage["temporary"])
logical = Path(storage["logicalOutput"])
destination = logical.with_name("42-persisted")
require(logical.is_symlink() and logical.resolve() == source.resolve(), "Wrong temporary run")
require(read(logical / "job.json")["stage"] == "complete", "Training is still active")
require(not destination.exists(), "Do not overwrite a persisted copy")
destination.mkdir()


def checksum(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


files = {}
for path in sorted(source.rglob("*")):
    if not path.is_file():
        continue
    relative = path.relative_to(source)
    require(not path.name.endswith(".tmp"), "Unfinished checkpoint")
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    expected = checksum(path)
    shutil.copy2(path, target)
    with target.open("rb") as stream:
        os.fsync(stream.fileno())
    require(checksum(target) == expected, "Copy changed file content")
    files[str(relative)] = {"sha256": expected, "bytes": path.stat().st_size}
report = {"temporary": str(source), "output": str(logical), "files": files, "allHashesVerified": True, "allCheckpointsPreserved": True, "state": "copied"}
write(root / "storage.json", report)
logical.unlink()
try:
    destination.rename(logical)
except BaseException:
    logical.symlink_to(source.resolve(), target_is_directory=True)
    raise
for path in (logical, logical.parent):
    descriptor = os.open(path, os.O_RDONLY)
    os.fsync(descriptor)
    os.close(descriptor)
report["state"] = "durable"
write(root / "storage.json", report)
print({"files": len(files), "bytes": sum(v["bytes"] for v in files.values()), "allHashesVerified": True, "output": str(logical)})
