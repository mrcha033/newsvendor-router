import hashlib
import tarfile
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import digest, read, require, write


def file_hash(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


audit = Path(__file__).resolve().parent.relative_to(Path.cwd())
roots = {v: Path(f"results/l40s-research-state-replay-{v}") for v in ["v2", "v3"]}
comparison = read(audit / "comparison.json")
parity = read(audit / "weight-parity.json")
registrations = {v: read(root / "registered.json") for v, root in roots.items()}
updates = {v: read(root / "encoder-update-verified.json") for v, root in roots.items()}
source_hash = provenance({})["sourceHash"]
require(source_hash == registrations["v3"]["source"]["sourceHash"], "Source changed")
require(parity["sameLanguageCases"] and parity["samePolicyTargetsAfterRestoration"], "Unmatched data")
for version, root in roots.items():
    run = read(root / "base/42/run.json")
    require(run["provenance"]["sourceHash"] == registrations[version]["source"]["sourceHash"], "Registration changed")
    require(comparison[version]["selectedLanguageEpoch"] == 0, "Unexpected selected model")
    require(parity["runs"][version]["matchesParent"], "Parent restoration failed")
    require(updates[version]["encoderChanged"] and updates[version]["demandUnchanged"], "Unexpected optimizer update")
    with tarfile.open(root / "base/42/source.tar.gz", "r:gz") as archive:
        for name, expected in registrations[version]["source"]["sources"].items():
            require(digest(archive.extractfile(name).read()) == expected, f"Wrong archived source: {name}")

checks = {
    "tests": {"passed": 258, "seconds": 28.17, "logHash": file_hash(audit / "tests.log")},
    "ruff": {"passed": True, "formatFiles": 82, "logHash": file_hash(audit / "ruff.log")},
    "sourceChecks": read(audit / "source-checks.json"),
    "numericalSmoke": read("results/smoke.json"),
    "researchCheck": read(audit / "data-check/manifest.json"),
    "currentSourceHash": source_hash,
}
require("258 passed in 28.17s" in (audit / "tests.log").read_text(), "Test log differs")
require("All checks passed!" in (audit / "ruff.log").read_text(), "Ruff failed")
for checked in checks["sourceChecks"].values():
    require(checked["check"]["sourceOverlaps"] == 0 and checked["check"]["inputOverlaps"] == 0, "Source/input overlap")
require(checks["numericalSmoke"]["smokeEpisodes"] == 30 and checks["numericalSmoke"]["falseHandoffs"] == 0, "Smoke failed")
write(audit / "checks.json", checks)

paths = []
private_weights = {}
for version, root in roots.items():
    for path in sorted((root / "base/42").iterdir()):
        if not path.is_file():
            continue
        if path.suffix == ".pt" and not path.name.startswith("policy-candidate-"):
            private_weights[str(path)] = {"sha256": file_hash(path), "bytes": path.stat().st_size}
        else:
            paths.append(path)
    for name in ["registered.json", "encoder-update-verified.json", "train.log"]:
        paths.append(root / name)
paths += [roots["v2"] / name for name in ["preflight.json", "construction-replay.jsonl"]]
paths += [roots["v3"] / name for name in ["storage.json", "temporary-cleanup.json"]]
paths += [audit / name for name in [
    "audit.py", "audit.log", "raw.jsonl", "report.json", "encoder_update.py",
    "aligned/audit.py", "aligned/audit.log", "aligned/raw.jsonl", "aligned/report.json",
    "comparison.json", "weight-parity.json", "tests.log", "ruff.log", "source-checks.json",
    "smoke.log", "data-check.log", "data-check/manifest.json", "checks.json", "persist.py",
    "persist.log", "publish.py",
]]
paths += [Path(name) for name in [
    "scripts/run_research.py", "src/newsvendor/structured_train.py", "tests/test_structured.py",
    "configs/l40s-research-state-replay-v2.json", "configs/l40s-research-state-replay-v3.json",
]]
paths = sorted(set(paths))
hashes = {str(path): {"sha256": file_hash(path), "bytes": path.stat().st_size} for path in paths}
archive_path = Path("docs/evidence/artifacts/research-constructor-training.tar.xz")
require(not archive_path.exists(), "Preserve published study")
print({"stage": "compress", "files": len(paths), "bytes": sum(p.stat().st_size for p in paths)}, flush=True)
with tarfile.open(archive_path, "w:xz", preset=3) as archive:
    for path in paths:
        archive.add(path, arcname=str(path))
with tarfile.open(archive_path, "r:xz") as archive:
    require(set(archive.getnames()) == set(hashes), "Archive members differ")
    for name, info in hashes.items():
        require(hashlib.file_digest(archive.extractfile(name), "sha256").hexdigest() == info["sha256"], f"Archive hash differs: {name}")

result = {
    "scope": "Train replay full-encoder continuation and matched field-query alignment; original Dev selection; both language/policy candidates rejected",
    "testUsed": False,
    "legacyTestUsedForSelection": False,
    "newSourceHoldoutUsedForSelection": False,
    "modelReplacementMade": False,
    "retainedCheckpoint": parity["parent"],
    "retainedCheckpointHash": registrations["v3"]["parentHash"],
    "retainedWeightsHash": parity["parentWeightsHash"],
    "inputAudit": {"before": read(audit / "report.json"), "aligned": read(audit / "aligned/report.json")},
    "data": read(roots["v2"] / "preflight.json"),
    "registrations": registrations,
    "encoderUpdates": updates,
    "comparison": comparison,
    "weightParity": parity,
    "privateCheckpointFiles": private_weights,
    "storage": read(roots["v3"] / "storage.json"),
    "checks": checks,
    "decision": {
        "adopted": False,
        "reason": "Query alignment reduces continued-training state errors from 46 to 14, but the parent has 12; both runs restore the parent. Subsequent value fitting also worsens generated Dev loss. Keep existing weights.",
        "languageDevFields": 3168,
        "stateErrors": {"parent": 12, "oldTrainingQueries": 46, "alignedTrainingQueries": 14},
        "economicResultsScope": "After language selection restored the parent; these are not sequential economic evaluations of the rejected language candidates.",
    },
    "limitations": [
        "Single continuation seed and reused original Dev; no independent effectiveness gain or replay-only causal effect is established.",
        "The original retail exact loss uses only five fully observed periods crossed with seven generated financial scenarios.",
        "Financial documents and manager replies are controlled/generated and do not establish real organizational effectiveness.",
        "Final public-document and economic metrics follow parent restoration. The rejected language candidates have field-level Dev evaluations only.",
        "Checkpoint write cadence/storage and concurrent CPU work differ; elapsed times are not a controlled speed comparison.",
        "All full checkpoints and optimizer state are preserved locally with hashes. Public small policy weights still require the unpublished full parent; end-to-end external reproduction is not complete.",
    ],
    "publishedRaw": {"path": str(archive_path), "sha256": file_hash(archive_path), "bytes": archive_path.stat().st_size, "files": hashes, "verified": True},
}
write("docs/evidence/research-constructor-training-results.json", result)
write(audit / "published-audit.json", {"allHashesVerified": True, "files": len(paths), "archiveHash": result["publishedRaw"]["sha256"], "archiveBytes": archive_path.stat().st_size, "modelPromoted": False})
print({"stage": "complete", "files": len(paths), "archiveBytes": archive_path.stat().st_size, "modelPromoted": False, "sourceHash": source_hash}, flush=True)
