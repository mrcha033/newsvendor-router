from pathlib import Path

from transformers import AutoTokenizer

from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import prepare, research_input
from newsvendor.structured_rollout import FIELDS, TEXT
from newsvendor.structured_train import language_view

root = Path(__file__).parent
config = read("configs/l40s-research-state-replay-v2.json")
tokenizer = AutoTokenizer.from_pretrained(config["encoder"]["model"], revision=config["encoder"]["revision"], cache_dir=".cache/torch-models", local_files_only=True)
tokenizer.model_max_length = 10**9
rows = sorted(lines(config["constructionReplay"][0]), key=lambda r: digest(r["input"]))[:16]
records = []
for row in rows:
    require(row["split"] == "train", "Train input audit only")
    value = row["input"]
    training, target = language_view(("research", row), tokenizer, config, {}, [])
    inference = prepare(research_input(value), tokenizer, config["encoder"], fields=FIELDS, actions=[{"id": "hold", "text": TEXT["hold"]}], round=sum(h["action"] == "retrieve" for h in value["history"]))
    def sequences(view):
        return [ids[mask.bool()].tolist() for ids, mask in zip(view["batch"]["input_ids"], view["batch"]["attention_mask"], strict=True)]
    left, right = sequences(training), sequences(inference)
    records.append({"id": row["id"], "family": row["family"], "inputHash": digest(research_input(value)), "trainActions": [a["id"] for a in training["actions"]], "inferenceActions": [a["id"] for a in inference["actions"]], "fieldCount": len(FIELDS), "sourceSequencesEqual": left[:training["queryStart"]] == right[:inference["queryStart"]], "querySequencesEqual": left[training["queryStart"]:] == right[inference["queryStart"]:], "targetKeys": sorted(target), "trainingQueries": left[training["queryStart"]:], "inferenceQueries": right[inference["queryStart"]:]})
jsonl(root / "raw.jsonl", records)
report = {"scope": "Train-only token/schema audit, no GPU predictions or effectiveness measurement", "testUsed": False, "devUsed": False, "cases": len(records), "differentQueries": sum(not r["querySequencesEqual"] for r in records), "equalSourceSequences": sum(r["sourceSequencesEqual"] for r in records), "supervisionKeys": sorted({key for r in records for key in r["targetKeys"]}), "provenance": provenance(config), "rawHash": digest((root / "raw.jsonl").read_bytes()), "scriptHash": digest(Path(__file__).read_bytes())}
write(root / "report.json", report)
print({k: v for k,v in report.items() if k != "provenance"})
