import argparse
from pathlib import Path

import torch

from newsvendor.io import digest, read, write
from newsvendor.structured_tool_eval import weights_hash

parser = argparse.ArgumentParser()
parser.add_argument("root")
args = parser.parse_args()
root = Path(args.root)
config = read(root / "registered.json")["config"]
torch.set_num_threads(1)
parent = torch.load(config["warmStart"], map_location="cpu", weights_only=True)
path = root / "base/42/language-progress.pt"
progress = torch.load(path, map_location="cpu", weights_only=True)
weights = progress["weights"]
changes = {prefix: sum(not torch.equal(v, parent["weights"][k]) for k,v in weights.items() if k.startswith(prefix)) for prefix in ["encoder.", "project.", "fusion.", "demand.", "heads.state."]}
report = {
    "scope": "Actual final language optimizer state before Dev restoration; this is not a claim that the candidate was adopted",
    "changedTensors": changes,
    "encoderChanged": changes["encoder."] > 0,
    "demandUnchanged": changes["demand."] == 0,
    "parentEncoderHash": weights_hash({k:v for k,v in parent["weights"].items() if k.startswith("encoder.")}),
    "trainedEncoderHash": weights_hash({k:v for k,v in weights.items() if k.startswith("encoder.")}),
    "selectedLanguageEpoch": progress["state"]["selected"],
    "languageProgressHash": digest(path.read_bytes()),
    "scriptHash": digest(Path(__file__).read_bytes()),
}
write(root / "encoder-update-verified.json", report)
print({"run": str(root), "changedTensors": changes, "selectedEpoch": progress["state"]["selected"]})
