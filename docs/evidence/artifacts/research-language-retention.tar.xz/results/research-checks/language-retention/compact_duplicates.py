import hashlib
import json
import subprocess
import tarfile
from pathlib import Path

def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()

result = {}
for variant in ("control","prefix"):
    root = Path("results/l40s-research-scope-v1")/variant
    metadata = root/"storage.json"
    saved = json.loads(metadata.read_text())
    archive = Path(saved["archive"])
    assert sha(archive) == saved["sha256"]
    original = root/"42/common.pt"
    expected = saved["files"]["common.pt"]["sha256"]
    assert sha(original) == expected
    process = subprocess.Popen(["zstd","--long=31","-dc",str(archive)],stdout=subprocess.PIPE)
    found = False
    with tarfile.open(fileobj=process.stdout,mode="r|") as stream:
        for member in stream:
            if member.name == "common.pt":
                with stream.extractfile(member) as f:
                    assert hashlib.file_digest(f,"sha256").hexdigest() == expected
                found = True
    assert process.wait() == 0 and found
    count = original.stat().st_size
    original.unlink()
    saved["archiveOnly"] = sorted(set(saved["archiveOnly"]+["common.pt"]))
    saved["note"] = "Only byte/hash-verified duplicated checkpoints removed; all archived model/optimizer versions remain durable. The final model remains directly accessible."
    metadata.write_text(json.dumps(saved,indent=2)+"\n")
    result[variant] = {"bytesFreed":count,"sha256":expected,"archive":str(archive),"streamVerifiedBeforeRemoval":True}
    print(variant,count,flush=True)
Path("results/research-checks/language-retention/duplicate-storage.json").write_text(json.dumps(result,indent=2)+"\n")
