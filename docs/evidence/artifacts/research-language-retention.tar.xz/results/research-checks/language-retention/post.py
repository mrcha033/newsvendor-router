import os
import time
from collections import defaultdict
from pathlib import Path

import torch

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import research_input
from newsvendor.structured_policy import public_validation, retained
from newsvendor.structured_retail import parameter_metrics
from newsvendor.structured_rollout import ResearchRouter
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_train import load
from newsvendor.train import seed

root = Path("results/l40s-research-retention-v1")
run = Path(read(root/"registered.json")["runtimeOutput"])
out = root/"diagnostics"
require(read(root/"queue.json")["status"] == "complete", "Training still active")
require(not out.exists(), "Preserve existing diagnostics")
require(os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "Assigned L40S only")
require(provenance({})["sourceHash"] == read(root/"registered.json")["source"]["sourceHash"], "Source changed")
out.mkdir()
report = read(run/"report.json")
parent_path = Path(report["config"]["warmStart"])
paths = {"parent":parent_path, "epoch1":run/"language-epoch-1.pt", "epoch2":run/"language-epoch-2.pt", "selected":run/"common.pt", "final":run/"model.pt"}
write(out/"registered.json", {"models":{k:{"path":str(v),"sha256":file_hash(v)} for k,v in paths.items()},"source":provenance({}),"testUsed":False,"scope":"Original public Dev for retention; existing augmentation-held Train contrast sources for diagnostics only. Report every language epoch without changing selection."})
documents = [("public",r) for r in lines(run/"documents-inputs.jsonl") if r["split"] == "dev"]
ids = {r["id"] for _,r in documents}
labels = {k:v for k,v in read(run/"documents-labels.json").items() if k in ids}
collection = lines(Path(report["config"]["dataset"])/"collection.jsonl")
manifest = read("results/parameter-contrasts-v2/manifest.json")
fit, held = (set(manifest["partitions"][k]["families"]) for k in ("fit","held"))
require(not fit & held, "Source leakage in augmentation")
rows = lines(manifest["partitions"]["held"]["path"])
require(all(r["split"] == "train" and r["family"] in held and digest(research_input(r["input"])) == r["inputHash"] for r in rows), "Held source inputs changed")
seed(42)
torch.set_num_threads(8)
results, seen = {}, {}
started = time.perf_counter()
for name,path in paths.items():
    model, tokenizer, config, _ = load(path, "cuda")
    state = model.state_dict()
    weight = weights_hash(state)
    frozen = weights_hash({k:v for k,v in state.items() if not k.startswith("heads.value.")})
    key = digest([frozen, config["encoder"]])
    if key in seen:
        previous = seen[key]
        results[name] = {**results[previous], "checkpoint":str(path),"weightsHash":weight,"reusedFrozenConstructor":previous}
        print({"model":name,"sameConstructor":previous},flush=True)
    else:
        seen[key] = name
        public = public_validation(model, tokenizer, config, documents, labels, collection, out/f"{name}-public.jsonl")
        router = ResearchRouter(model, tokenizer, config["encoder"],config["noValue"])
        records, groups = [], defaultdict(lambda:defaultdict(int))
        for index,row in enumerate(rows):
            constructed = router.construct(row["input"])
            metrics = parameter_metrics(row["input"], constructed)
            records.append({k:row[k] for k in ("id","family","contrast","inputHash")} | {"state":constructed,"metrics":metrics})
            for group in ("all",row["contrast"]):
                total = groups[group];total["states"]+=1;total["fields"]+=4
                for label,metric in [("valueErrors","parameterAccuracy"),("rawValueErrors","rawParameterAccuracy"),("stateErrors","stateAccuracy")]:
                    total[label] += round(4*(1-metrics[metric]))
                total["evidenceErrors"] += metrics["evidenceCount"]-metrics["evidenceCorrect"]
                total["evidenceFields"] += metrics["evidenceCount"]
            if (index+1)%256 == 0:print({"model":name,"held":index+1,"total":len(rows)},flush=True)
        jsonl(out/f"{name}-held.jsonl",records)
        results[name] = {"checkpoint":str(path),"weightsHash":weight,"frozenWeightsHash":frozen,"public":public,"held":dict(groups)}
        print({"model":name,"public":public,"held":dict(groups)["all"]},flush=True)
    write(out/"partial.json", results)
    del state,model,tokenizer
    if 'router' in locals():del router
    torch.cuda.empty_cache()
require(results["selected"]["frozenWeightsHash"] == results["final"]["frozenWeightsHash"], "Policy changed constructor")
common_predictions = lines(run/"documents-dev.jsonl")
source = results["selected"].get("reusedFrozenConstructor","selected")
require(common_predictions == lines(out/f"{source}-public.jsonl"), "Full public prediction replay differs")
failures = retained(results["parent"]["public"],results["final"]["public"])
base = report["initialDev"]["learned"]
after = report["finalDev"]["learned"]
before_generated = report["initialGeneratedDev"]["learned"]
after_generated = report["finalGeneratedDev"]["learned"]
gates = {
    "publicRetention": not failures,
    "retailLoss":after["meanTotalOnCompletePeriods"] <= base["meanTotalOnCompletePeriods"]+1e-9,
    "generatedLoss":after_generated["meanTotal"] <= before_generated["meanTotal"]+1e-9,
    "retailRequests":after["necessaryRequests"] >= base["necessaryRequests"] and after["unnecessaryRequests"] <= base["unnecessaryRequests"] and after["missingParametersAtStop"] <= base["missingParametersAtStop"],
    "validHandoffs":after["falseHandoffs"] == after_generated["falseHandoffs"] == 0,
    "parameterAndEvidence":all(after["finalParameters"][k] >= base["finalParameters"][k] for k in ("parameterAccuracy","stateAccuracy","rawParameterAccuracy","rawStateAccuracy")) and after["finalEvidenceAccuracy"] >= base["finalEvidenceAccuracy"] and all(after_generated["finalParameters"][k] >= before_generated["finalParameters"][k] for k in ("parameterAccuracy","stateAccuracy")) and after_generated["finalEvidenceAccuracy"] >= before_generated["finalEvidenceAccuracy"],
}
result = {"source":provenance({}),"testUsed":False,"seconds":time.perf_counter()-started,"publicCases":len(documents),"heldStates":len(rows),"heldFamilies":len(held),"models":results,"publicRetentionFailures":failures,"adoptionGates":gates,"allGatesPassed":all(gates.values()),"publicSelectedReplayExact":True,"limits":["Held augmentation sources were observed in original parent Train; not independent effectiveness evidence.","Original Dev exact retail loss uses five complete periods; generated Dev uses 60 cases from 12 families.","Candidate outputs are measured without Test selection."]}
write(out/"report.json",result)
print({"adoptionGates":gates,"seconds":result["seconds"]},flush=True)
