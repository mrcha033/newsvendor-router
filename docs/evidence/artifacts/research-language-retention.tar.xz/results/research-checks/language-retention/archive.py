import hashlib
import os
import shutil
import subprocess
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

root = Path("results/l40s-research-retention-v1")
run = Path(read(root/"registered.json")["runtimeOutput"])
require(read(root/"queue.json")["status"] == "complete" and read(run/"job.json")["stage"] == "complete", "Run is active")
paths = sorted(p for p in run.rglob("*") if p.is_file())
files = {str(p.relative_to(run)):{"sha256":file_hash(p),"bytes":p.stat().st_size} for p in paths}
# Keep full model files close together so repeated frozen tensors compress together.
order = {"language-epoch-1.pt":0,"language-epoch-2.pt":1,"common.pt":2,"model.pt":3,"policy-base.pt":4,"language-progress.pt":5}
paths.sort(key=lambda p:(0,order[p.name]) if p.name in order else (1,str(p)))
archive = Path("/dev/shm/newsvendor-language-retention-v1.tar.zst")
require(not archive.exists(), "Preserve prior archive")
with archive.open("xb") as stream:
    process = subprocess.Popen(["zstd","-T2","-3","--long=31","-c"],stdin=subprocess.PIPE,stdout=stream)
    with tarfile.open(fileobj=process.stdin,mode="w|") as tar:
        for path in paths:tar.add(path,arcname=str(path.relative_to(run)))
    process.stdin.close()
    require(process.wait() == 0,"Compression failed")
process = subprocess.Popen(["zstd","--long=31","-dc",str(archive)],stdout=subprocess.PIPE)
seen = set()
with tarfile.open(fileobj=process.stdout,mode="r|") as tar:
    for member in tar:
        require(member.isfile() and member.name in files and member.name not in seen,"Unexpected member")
        require(hashlib.file_digest(tar.extractfile(member),"sha256").hexdigest() == files[member.name]["sha256"],"Member hash mismatch")
        seen.add(member.name)
require(process.wait() == 0 and seen == set(files),"Incomplete archive")
sha = file_hash(archive)
target = root/"full-run.tar.zst"
require(not target.exists(),"Preserve existing durable archive")
require(shutil.disk_usage(root).free > archive.stat().st_size+300_000_000,"Insufficient durable space")
with archive.open("rb") as src,target.open("xb") as dst:
    shutil.copyfileobj(src,dst,8*1024*1024);dst.flush();os.fsync(dst.fileno())
require(file_hash(target) == sha,"Durable copy mismatch")
# Keep raw records directly available on disk; checkpoint bytes are verified in the archive.
records = root/"base/42"
records.mkdir(parents=True,exist_ok=True)
for path in paths:
    if path.suffix == ".pt":continue
    destination = records/path.relative_to(run)
    destination.parent.mkdir(parents=True,exist_ok=True)
    require(not destination.exists(),"Preserve an existing record")
    shutil.copyfile(path,destination)
    require(file_hash(destination) == files[str(path.relative_to(run))]["sha256"],"Record copy mismatch")
write(root/"storage.json",{"archive":str(target),"sha256":sha,"bytes":target.stat().st_size,"files":files,"allMemberHashesVerified":True,"durableCopyVerified":True,"liveCheckpointDirectory":str(run),"archiveOnlyOnDurableStorage":[k for k in files if k.endswith('.pt')],"languageCandidatesPreserved":[1,2],"languageOptimizer":"last completed epoch","allPolicyCandidatesAndOptimizersPreserved":True,"restore":"zstd --long=31 -dc "+str(target)+" | tar -xf - -C <new-directory>"})
print({"archive":str(target),"bytes":target.stat().st_size,"files":len(files),"allHashesVerified":True},flush=True)
