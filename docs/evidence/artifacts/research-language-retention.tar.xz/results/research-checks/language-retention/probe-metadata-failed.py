import copy
import importlib.util
import os
import subprocess
import time
from pathlib import Path

import numpy as np
import torch

from newsvendor import corpus, structured_train as training
from newsvendor.cli import provenance
from newsvendor.io import digest, lines, read, require, write
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.train import seed

root = Path(__file__).resolve().parent
require(os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "Assigned L40S only")
require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(), "Wrong GPU")
config = read("configs/l40s-research-retention-v1.json")
previous = root / "before-structured_train.py"
previous.write_bytes(subprocess.check_output(["git", "show", "4c79e53:src/newsvendor/structured_train.py"]))
spec = importlib.util.spec_from_file_location("newsvendor._retention_before", previous)
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)

data = Path("results/l40s-research-scope-v1/control/42")
episodes = []
scenarios = {r["id"]: r["scenario"] for r in corpus.generate(read(config["researchConfig"])) if r["split"] == "train"}
for prefix in ("", "generated-"):
    inputs = [r for r in lines(data / f"{prefix}inputs.jsonl") if r["split"] == "train"]
    ids = {r["id"] for r in inputs}
    labels = {r["id"]: r for r in lines(data / f"{prefix}environment.jsonl") if r["id"] in ids}
    episodes.extend({**r, **labels[r["id"]], "scenario": scenarios[r["id"]] if prefix else r["id"].rsplit(":",1)[-1]} for r in inputs)
cases = training.research_cases(episodes, replay=config["constructionReplay"])
documents = [r for r in lines(data / "documents-inputs.jsonl") if r["split"] == "train"]
cases += [("public", r) for r in documents]
cases = training.balance_cases(cases, config["training"])
expected = read(data / "language-cases.json")["train"]
observed = [{"mode": mode, "id": r["id"], "family": r["family"], "inputHash": digest(r["input"])} for mode, r in cases]
require(observed == expected, "Training cases differ from historical control")
chosen = np.random.default_rng(config["seed"]).permutation(len(cases))[:64]
train = [cases[int(i)] for i in chosen]
ids = {r["id"] for mode, r in train if mode == "public"}
labels = {k:v for k,v in read(data / "documents-labels.json").items() if k in ids}
collection = lines(Path(config["dataset"]) / "collection.jsonl")
write(root / "probe-registered.json", {"source": provenance(config), "config": config, "trainCasesHash": digest(observed), "cases": [{"mode":m,"id":r["id"],"family":r["family"],"inputHash":digest(r["input"])} for m,r in train], "testUsed": False, "oldSourceHash": digest(previous.read_bytes())})
seed(42)
model, tokenizer, parent = training.initialize(config)
initial = {k:v.clone() for k,v in model.state_dict().items()}
model.to("cuda")
prepared = []
for index, case in enumerate(train):
    view, target = training.language_view(case, tokenizer, config, labels, collection)
    target.update(caseIndex=index, retrievalRound=1)
    prepared.append((view, target))

def run(module, distill):
    model.load_state_dict(initial)
    seed(42)
    teacher, identity = training.language_teacher(model, config, train) if distill else (None, None)
    before_teacher = weights_hash(teacher.state_dict()) if teacher is not None else None
    optimizer = model.optimizer(config["training"])
    model.train()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    started = time.perf_counter()
    losses, anchors, workload = [], [], []
    for start in range(0, len(prepared), 32):
        group = prepared[start:start+32]
        optimizer.zero_grad(set_to_none=True)
        for lo,hi in model.training_batches([v for v,_ in group]):
            values, measured, cost = module.language_backward(model, group[lo:hi], tokenizer, config, train, labels, collection, teacher=teacher, distill_weight=4.0 if distill else 0.0)
            losses.extend(values)
            anchors.extend(m["distillation"] for m in measured if "distillation" in m)
            workload.append(cost)
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        torch._foreach_div_(gradients, len(group))
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5, error_if_nonfinite=True)
        optimizer.step()
    torch.cuda.synchronize()
    elapsed = time.perf_counter()-started
    peak = torch.cuda.max_memory_allocated()
    final_hash = weights_hash(model.state_dict())
    require(weights_hash(model.demand.state_dict()) == parent["demandWeightsHash"], "Demand changed")
    require(not torch.equal(initial["encoder.embeddings.tok_embeddings.weight"], model.encoder.embeddings.tok_embeddings.weight.cpu()), "Encoder did not update")
    if teacher is not None:
        require(weights_hash(teacher.state_dict()) == before_teacher == parent["coreWeightsHash"], "Teacher changed")
        require(all(p.grad is None for p in teacher.parameters()), "Teacher received gradients")
        require(anchors and max(anchors)>0, "Missing distillation gradients")
    result = {"seconds":elapsed,"peakGpuBytes":peak,"weightsHash":final_hash,"losses":losses,"anchors":anchors,"workload":workload,"teacher":identity,"teacherUnchanged":teacher is not None}
    del optimizer, teacher
    model.zero_grad(set_to_none=True)
    torch.cuda.empty_cache()
    return result

results = {}
for name, module, enabled in [("before", old, False), ("disabled", training, False), ("enabled", training, True)]:
    results[name] = run(module, enabled)
    write(root / "probe-partial.json", results)
    print(name, {k:v for k,v in results[name].items() if k in ("seconds","peakGpuBytes","weightsHash","teacherUnchanged")}, flush=True)
require(results["before"]["weightsHash"] == results["disabled"]["weightsHash"], "Disabled path changed updates")
require(results["before"]["losses"] == results["disabled"]["losses"], "Disabled path changed losses")
require(results["enabled"]["weightsHash"] != results["disabled"]["weightsHash"], "Anchor did not change learning")
write(root / "probe.json", {"source":provenance(config),"parent":parent,"cases":64,"publicCases":len(ids),"disabledExact":True,"demandUnchanged":True,"encoderUpdated":True,"testUsed":False,"results":results})
print("probe complete", flush=True)
