import hashlib
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write

checks_root = Path("results/research-checks/language-retention")
run = Path("results/l40s-research-retention-v1")
output = run/"base/42"
registration = read(run/"registered.json")
live = Path(registration["runtimeOutput"])
training = read(output/"report.json")
diagnostics = read(run/"diagnostics/report.json")
storage = read(run/"storage.json")
checks = read(checks_root/"checks.json")
decision = read(run/"decision.json")
require(read(run/"queue.json")["status"] == "complete", "Training is live")
require(storage["allMemberHashesVerified"] and storage["durableCopyVerified"], "Training archive missing")
require(file_hash(storage["archive"]) == storage["sha256"], "Training archive changed")
require(provenance({})["sourceHash"] == registration["source"]["sourceHash"] == diagnostics["source"]["sourceHash"] == checks["source"]["sourceHash"], "Sources differ")
with tarfile.open(output/"source.tar.gz","r:gz") as tar:
    for name,expected in registration["source"]["sources"].items():
        require(hashlib.sha256(tar.extractfile(name).read()).hexdigest() == expected, "Training source changed")
require("286 passed in 34.45s" in (checks_root/"tests.log").read_text(), "Tests not verified")
require("All checks passed!" in (checks_root/"ruff.log").read_text(), "Ruff failed")
require(all(c["check"]["sourceOverlaps"] == c["check"]["inputOverlaps"] == 0 for c in checks["sourceChecks"].values()), "Source leakage")
require(checks["smoke"]["smokeEpisodes"] == 30 and checks["smoke"]["falseHandoffs"] == 0, "Smoke failed")
paths = {}
for root in (checks_root,run):
    for path in root.rglob("*"):
        if path.is_file() and path.suffix not in (".pt",".pyc",".zst") and path != checks_root/"publish.log":
            paths[str(path)] = path
for path in live.glob("policy-candidate-*.pt"):
    paths[str(output/path.name)] = path
for name in ["configs/l40s-research-retention-v1.json","src/newsvendor/structured_train.py","tests/test_structured.py","results/parameter-contrasts-v2/manifest.json","results/parameter-contrasts-v2/held.jsonl"]:
    paths[name] = Path(name)
files = {name:{"sha256":file_hash(path),"bytes":path.stat().st_size} for name,path in sorted(paths.items())}
archive = Path("docs/evidence/artifacts/research-language-retention.tar.xz")
require(not archive.exists(), "Preserve previous publication")
print({"stage":"archive","files":len(files),"rawBytes":sum(r["bytes"] for r in files.values())},flush=True)
with tarfile.open(archive,"w:xz",preset=3) as tar:
    for name,path in sorted(paths.items()):tar.add(path,arcname=name)
with tarfile.open(archive,"r:xz") as tar:
    require(set(tar.getnames()) == set(files), "Published members differ")
    for name,record in files.items():
        require(hashlib.file_digest(tar.extractfile(name),"sha256").hexdigest() == record["sha256"], "Published hash mismatch")
publication = {"path":str(archive),"sha256":file_hash(archive),"bytes":archive.stat().st_size,"files":files,"allHashesVerified":True}
result = {"scope":"Public Train output retention during full-encoder parameter-construction learning, followed by fresh own-state action-value fitting","testUsed":False,"modelReplacementMade":decision["adopted"],"registration":registration,"checks":checks,"dataParity":read(checks_root/"data-parity.json"),"trainCoverage":read(checks_root/"train-coverage.json"),"l40sProbe":read(checks_root/"probe.json"),"training":training,"diagnostics":diagnostics,"generatedLossDecomposition":read(checks_root/"loss-decomposition.json"),"privateStorage":storage,"decision":decision,"publishedRaw":publication,"limitations":["One fixed seed and one preregistered distillation weight; not a grid search or universal claim.","Historical control training is reused as a reference; exact disabled-code update parity was checked on 64 Train cases, not a second full rerun.","Held augmentation sources were observed during the parent's original Train; they do not constitute a blind model evaluation.","Retail exact loss covers five unique complete periods crossed with seven generated financial conditions; generated Dev has 60 cases from 12 families.","A frozen teacher can preserve its previous errors; supervised source annotations remain the primary training signal.","No latent demand calibration or legacy Test improvement is established by this document-learning experiment.","Full candidate and optimizer files are retained in a hash-verified local archive. Published small value-head candidates require the corresponding local full constructor base."]}
write("docs/evidence/research-language-retention-results.json",result)
print({"stage":"published","files":len(files),"bytes":archive.stat().st_size},flush=True)
