import copy
import hashlib
import tarfile
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.construction import parameter_record
from newsvendor.io import digest, lines, read, require, write
from newsvendor.structured_inputs import research_input


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


audit = Path(__file__).resolve().parent.relative_to(Path.cwd())
run = Path("results/l40s-parameter-contrast-format-v1")
probe = Path("results/parameter-contrast-format-v1")
data = Path("results/parameter-contrasts-v2")
report = read(run / "report.json")
plan = read(run / "registered.json")
manifest = read(data / "manifest.json")
old_path = Path("docs/evidence/research-parameter-contrasts-results.json")
old = read(old_path)
old_archive = Path(old["publishedRaw"]["path"])
require(sha(old_archive) == old["publishedRaw"]["sha256"], "Historical v1 archive changed")
require(provenance({})["sourceHash"] == plan["sourceHash"], "Measured inference source changed")
for path, expected in plan["files"].items():
    require(sha(path) == expected, "Format probe input/checkpoint changed: " + path)
for name, measured in report["models"].items():
    require(sha(run / (name + ".jsonl")) == measured["rawHash"], "Raw prediction changed")
require(report["cases"] == 552 and report["families"] == 19, "Wrong comparison cohort")
require(report["models"]["parent"]["groups"]["all"]["valueErrors"] == 726, "Wrong parent score")
require(report["models"]["candidate"]["groups"]["all"]["valueErrors"] == 1450, "Wrong candidate score")

# Independently check that only the documented foreign applicability metadata changed.
def key(row):
    return tuple(row[k] for k in ("id", "family", "originHash", "contrast"))


original = {key(r): r for r in lines("results/parameter-contrasts-v1/held.jsonl")}
probe_rows = lines(probe / "held.jsonl")
for row in probe_rows:
    prior = original[key(row)]
    expected = copy.deepcopy(prior["input"])
    by_id = {d["id"]: d for d in expected["docs"]}
    for change in row["formatChanges"]:
        doc = by_id[change["id"]]
        require(change["field"] in ("sku", "period"), "Non-scope alteration")
        require(doc[change["field"]] == change["before"], "Wrong original scope")
        doc[change["field"]] = change["after"]
    require(expected == row["input"], "Unexpected format-probe change")
    require(parameter_record(prior["input"]) == parameter_record(row["input"]), "Target changed")
    require(digest(research_input(row["input"])) == row["inputHash"], "Input hash changed")

for path, expected in manifest["plan"]["files"].items():
    require(sha(path) == expected, "V2 source changed")
require(sha("scripts/prepare_parameter_contrasts.py") == manifest["scriptHash"], "V2 generator changed")
partitions, families, inputs = {}, {}, {}
for name, part in manifest["partitions"].items():
    require(sha(part["path"]) == part["sha256"], "V2 data changed")
    rows = lines(part["path"])
    require(all(r["split"] == "train" for r in rows), "Non-Train contrast")
    require(all(not r["input"]["history"] for r in rows), "Invented response history")
    require(all(digest(research_input(r["input"])) == r["inputHash"] for r in rows), "V2 input mismatch")
    families[name] = {r["family"] for r in rows}
    inputs[name] = {r["inputHash"] for r in rows}
    require(families[name] == set(part["families"]), "V2 source membership changed")
    require(len(rows) == part["cases"], "V2 case count changed")
    partitions[name] = {"cases": len(rows), "families": len(families[name]), "sha256": part["sha256"]}
require(not families["fit"] & families["held"], "V2 source overlap")
require(not inputs["fit"] & inputs["held"], "V2 input overlap")
require(not (families["fit"] | families["held"]) & set(manifest["sourceFamilies"].get("dev", [])), "Dev source entered augmentation")
require(not (families["fit"] | families["held"]) & set(manifest["sourceFamilies"].get("test", [])), "Test source entered augmentation")
require("273 passed in 31.18s" in (audit / "tests-v2.log").read_text(), "Tests failed")
require("All checks passed!" in (audit / "ruff-v2.log").read_text(), "Ruff failed")
require("85 files already formatted" in (audit / "ruff-v2.log").read_text(), "Format failed")
source_checks = read(audit / "source-checks-final.json")
for check in source_checks.values():
    require(check["check"]["sourceOverlaps"] == check["check"]["inputOverlaps"] == 0, "Source leakage")
smoke = read("results/smoke.json")
require(smoke["smokeEpisodes"] == 30 and smoke["falseHandoffs"] == 0, "Smoke failed")
checks = {
    "tests": {"passed": 273, "seconds": 31.18, "logHash": sha(audit / "tests-v2.log")},
    "ruff": {"passed": True, "formatFiles": 85, "logHash": sha(audit / "ruff-v2.log")},
    "sourceChecks": source_checks,
    "numericalSmoke": smoke,
    "v2": {"partitions": partitions, "sourceOverlaps": 0, "inputOverlaps": 0, "allTrain": True, "noInventedHistory": True},
    "formatProbe": {"cases": len(probe_rows), "onlyForeignScopeChanged": True, "valuesStatesTypesAndEvidenceUnchanged": True},
    "currentSourceHash": provenance({})["sourceHash"],
}
write(audit / "format-checks.json", checks)
paths = [p for root in (run, probe, data) for p in sorted(root.iterdir()) if p.is_file()]
paths += [audit / n for n in (
    "format_probe.py", "format-prepare.log", "format-evaluate.log", "context_audit.py",
    "context-report.json", "context-raw.jsonl", "context-audit.log", "context-final.log",
    "prepare-v2.log", "tests-v2.log", "ruff-v2.log", "source-checks-final.json",
    "smoke-final.log", "format-checks.json", "publish_format.py",
)]
paths += [Path(n) for n in (
    "configs/parameter-contrasts-v2.json", "configs/parameter-contrast-format-v1.json",
    "configs/l40s-research-parameter-contrasts-v1.json", "scripts/prepare_parameter_contrasts.py",
    "scripts/evaluate_parameter_contrasts.py", "tests/test_parameter_contrasts.py",
    "tests/test_structured.py", "src/newsvendor/structured_train.py",
)]
paths = sorted(set(paths))
files = {str(p): {"sha256": sha(p), "bytes": p.stat().st_size} for p in paths}
archive_path = Path("docs/evidence/artifacts/research-parameter-format.tar.xz")
require(not archive_path.exists(), "Preserve earlier published archive")
print({"stage": "compress", "files": len(files), "rawBytes": sum(v["bytes"] for v in files.values())}, flush=True)
with tarfile.open(archive_path, "w:xz", preset=3) as archive:
    for path in paths:
        archive.add(path, arcname=str(path))
with tarfile.open(archive_path, "r:xz") as archive:
    require(set(archive.getnames()) == set(files), "Published members differ")
    for name, entry in files.items():
        require(hashlib.file_digest(archive.extractfile(name), "sha256").hexdigest() == entry["sha256"], "Published raw hash differs")
result = {
    "scope": "Follow-up Train diagnosis rejects the interpretation that the v1 candidate learned general SKU/period applicability; normal-format v2 data prepared but not trained",
    "testUsed": False,
    "trainingPerformed": False,
    "modelReplacementMade": False,
    "retainedCheckpoint": old["retainedCheckpoint"],
    "retainedCheckpointHash": old["retainedCheckpointHash"],
    "historicalV1": {"path": str(old_path), "sha256": sha(old_path), "rawArchive": str(old_archive), "rawArchiveHash": sha(old_archive)},
    "formatProbe": report,
    "contextAudit": read(audit / "context-report.json"),
    "correctedData": manifest,
    "checks": checks,
    "decision": {
        "adopted": False,
        "reason": "Candidate depends on artificial scope formats and regresses original Dev constructor/request/public performance.",
        "candidateValueErrors": 1450,
        "parentValueErrors": 726,
        "fields": 2208,
        "v2Trained": False,
        "correctedSelectionGateRetrained": False,
    },
    "limitations": [
        "The 552 cases reuse the same 19 augmentation-held Train sources, already seen as original Train. This is a follow-up diagnosis, not a new blind test or organizational effectiveness result.",
        "The v1 zero-error comparison remains a measurement of the artificial-marker condition; it does not demonstrate general applicability reasoning.",
        "Task SKU and period are absent in 420 repeated document query prefixes, but the full request is also a separate source. No causal contribution of this truncation to prediction errors has been isolated.",
        "The corrected generator and checkpoint gate pass tests; no retraining or improved model result under these corrections is claimed.",
        "Full ModernBERT checkpoints remain local. Published raw inputs, predictions, configs and source snapshots do not alone enable full model reevaluation.",
    ],
    "publishedRaw": {"path": str(archive_path), "sha256": sha(archive_path), "bytes": archive_path.stat().st_size, "files": files, "verified": True},
}
write("docs/evidence/research-parameter-format-results.json", result)
write(audit / "format-published-audit.json", {"allHashesVerified": True, "files": len(files), "archiveHash": result["publishedRaw"]["sha256"], "archiveBytes": archive_path.stat().st_size, "modelPromoted": False})
print({"stage": "complete", "files": len(files), "archiveBytes": archive_path.stat().st_size}, flush=True)
