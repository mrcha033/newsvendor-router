from collections import Counter
from pathlib import Path

from transformers import AutoTokenizer

from newsvendor.io import digest, jsonl, lines, read, write
from newsvendor.structured_inputs import query_tokens, research_input

root = Path(__file__).resolve().parent
config = read("configs/l40s-research-parameter-contrasts-v1.json")["encoder"]
tokenizer = AutoTokenizer.from_pretrained(config["model"], revision=config["revision"], cache_dir=".cache/torch-models", token=False, trust_remote_code=False)
raw, counts = [], Counter()
for row in lines("results/parameter-contrast-format-v1/held.jsonl"):
    observed = research_input(row["input"])
    context = "{}\n\n" + observed["request"]
    prefix = tokenizer.decode(query_tokens(tokenizer, context)[:config["queryTokens"]])
    record = {"id": row["id"], "family": row["family"], "contrast": row["contrast"], "prefix": prefix, "contains": {k: row["input"]["task"][k] in prefix for k in ("sku", "period")}}
    for key, exists in record["contains"].items():
        counts[key + ("Present" if exists else "Absent")] += 1
    raw.append(record)
jsonl(root / "context-raw.jsonl", raw)
write(root / "context-report.json", {"scope": "Train format-probe tokenizer audit; only repeated document prefix, not the separate complete request source", "cases": len(raw), "counts": dict(counts), "testUsed": False, "scriptHash": digest(Path(__file__).read_bytes()), "rawHash": digest((root / "context-raw.jsonl").read_bytes())})
print(dict(counts))
