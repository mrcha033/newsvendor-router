import copy
import hashlib
import random
import re
from datetime import date, timedelta
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.construction import parameter_record
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import research_input

root = Path("results/parameter-contrast-format-v1")
require(not root.exists(), "Preserve previous probe")
root.mkdir()
manifest = read("results/parameter-contrasts-v1/manifest.json")
rows = []
for original in lines(manifest["partitions"]["held"]["path"]):
    if original["contrast"] not in ("wrong_sku", "wrong_period"):
        continue
    row = copy.deepcopy(original)
    value = row["input"]
    require(row["split"] == "train", "Train-only format probe")
    key = "sku" if row["contrast"] == "wrong_sku" else "period"
    current = value["task"][key]
    rng = random.Random(digest([109, row["family"], original["inputHash"], key]))
    if key == "sku":
        # Preserve retail's numeric ID format and the generated SKU hash format.
        if current.startswith("retail:"):
            parts = current.split(":")
            parts[-1] = str(int(parts[-1]) + rng.choice([1, 3, 7, 11]))
            foreign = ":".join(parts)
        else:
            require(re.fullmatch(r"SKU-[0-9a-f]{10}", current), "Unknown SKU format")
            foreign = "SKU-" + digest([current, row["family"], 109])[:10]
    elif "/" in current:
        start, end = [date.fromisoformat(s) for s in current.split("/")]
        delta = timedelta(days=rng.choice([-28, -14, -7, 7, 14, 28]))
        foreign = (start + delta).isoformat() + "/" + (end + delta).isoformat()
    else:
        require(current == "next-day", "Unknown relative period")
        foreign = rng.choice(["previous-day", "next-week", "previous-week"])
    require(foreign != current, "Unchanged foreign scope")
    before = parameter_record(value)
    changed = []
    for doc in value["docs"]:
        if doc[key] != current:
            changed.append({"id": doc["id"], "field": key, "before": doc[key], "after": foreign})
            doc[key] = foreign
    require(changed, "No foreign document")
    after = parameter_record(value)
    require(before == after, "Format probe changed correct values, states, types or evidence")
    row["inputHash"] = digest(research_input(value))
    row["formatChanges"] = changed
    rows.append(row)
jsonl(root / "held.jsonl", rows)
updated = copy.deepcopy(manifest)
updated["scope"] = "Follow-up diagnostic on the same held Train sources: same-format alternative SKU/date identifiers; no training, no Test, no new independent cohort"
updated["parentManifest"] = "results/parameter-contrasts-v1/manifest.json"
updated["scriptHash"] = digest(Path(__file__).read_bytes())
updated["partitions"]["held"].update(path=str(root / "held.jsonl"), sha256=digest((root / "held.jsonl").read_bytes()), cases=len(rows), conditions={c: sum(r["contrast"] == c for r in rows) for c in ("wrong_sku", "wrong_period")})
write(root / "manifest.json", updated)
models = {
    "parent": {"checkpoint": "results/l40s-research-forecast-v1/base/42/model.pt"},
    "candidate": {"checkpoint": "results/l40s-research-parameter-contrasts-v1/base/42/common.pt"},
}
files = {m["checkpoint"] for m in models.values()}
files.update([str(root / "manifest.json"), str(root / "held.jsonl"), "scripts/evaluate_parameter_contrasts.py", str(Path(__file__).resolve().relative_to(Path.cwd()))])
hashes = {}
for name in files:
    with Path(name).open("rb") as stream:
        hashes[name] = hashlib.file_digest(stream, "sha256").hexdigest()
plan = {"models": models, "manifest": str(root / "manifest.json"), "output": "results/l40s-parameter-contrast-format-v1", "gpu": "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "sourceHash": provenance({})["sourceHash"], "files": hashes, "testUsed": False, "trainingPerformed": False, "scope": updated["scope"]}
write("configs/parameter-contrast-format-v1.json", plan)
print({"states": len(rows), "families": len({r["family"] for r in rows}), "sourceHash": plan["sourceHash"]})
