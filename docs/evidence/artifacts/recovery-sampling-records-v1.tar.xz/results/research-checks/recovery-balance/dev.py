"""Evaluate frozen refitted heads on the original Dev cohorts and shared responses."""

import copy
import gzip
import json
import os
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evaluate_responses import CachedRouter, conditions, expectations, file_hash, measurement
from sequential import observed_key

from newsvendor import structured_compare, structured_retail, structured_train
from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_metrics import generated_metrics
from newsvendor.structured_policy import public_validation, retained
from newsvendor.structured_rollout import rollout
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_value import constrain


def gates(reference, current):
    a, b = reference["generated"], current["generated"]
    result = {
        "generatedTotal": b["meanTotal"] <= a["meanTotal"] + 1e-9,
        "generatedFalseHandoffs": b["falseHandoffs"] <= a["falseHandoffs"],
        "generatedResolvedRequests": b["resolvedFieldRequests"] <= a["resolvedFieldRequests"],
        "generatedParameters": all(
            b["finalParameters"][k] >= a["finalParameters"][k] - 1e-12
            for k in ("parameterAccuracy", "stateAccuracy", "typeAccuracy")
        ),
        "generatedEvidence": b["finalEvidenceAccuracy"] >= a["finalEvidenceAccuracy"] - 1e-12,
    }
    for rate in ("0", "0.1", "0.2"):
        a, b = reference["retail"][rate], current["retail"][rate]
        result["retailTotal-" + rate] = (
            b["totalOnCompletePeriods"]["mean"] <= a["totalOnCompletePeriods"]["mean"] + 1e-9
        )
        for metric in ("falseHandoff", "unnecessaryRequests"):
            result[metric + "-" + rate] = b[metric]["mean"] <= a[metric]["mean"] + 1e-12
        for metric in ("parameterAccuracy", "stateAccuracy", "typeAccuracy"):
            result[metric + "-" + rate] = b[metric]["mean"] >= a[metric]["mean"] - 1e-12
        result["evidence-" + rate] = (
            b["evidenceCorrect"]["mean"] / b["evidenceCount"]["mean"]
            >= a["evidenceCorrect"]["mean"] / a["evidenceCount"]["mean"] - 1e-12
        )
    for metric in ("necessaryRequests", "recoveredAfterRequest", "handoffRate"):
        result[metric + "-no-dropout"] = (
            current["retail"]["0"][metric]["mean"]
            >= reference["retail"]["0"][metric]["mean"] - 1e-12
        )
    result["missingAtStop-no-dropout"] = (
        current["retail"]["0"]["missingAtStop"]["mean"]
        <= reference["retail"]["0"]["missingAtStop"]["mean"] + 1e-12
    )
    return result


def main():
    plan = read("configs/research-recovery-balanced-dev-v1.json")
    require(file_hash(__file__) == plan["scriptHash"], "Dev source differs")
    require(provenance({})["sourceHash"] == plan["sourceHash"], "Package source differs")
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    for path, sha in plan["files"].items():
        require(file_hash(path) == sha, "Registered asset changed: " + path)
    refit = read(Path(plan["refit"]) / "report.json")
    root = Path(plan["output"])
    require(not root.exists(), "Preserve previous Dev evaluation")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    start = time.perf_counter()
    episodes = {}
    for name, directory in plan["cohorts"].items():
        inputs = lines(Path(directory) / "inputs.jsonl")
        environment = {r["id"]: r for r in lines(Path(directory) / "environment.jsonl")}
        require(all(r["split"] == "dev" for r in inputs), "Original Dev cohorts only")
        episodes[name] = [r | environment[r["id"]] for r in inputs]
        if name == "retail":
            for e in episodes[name]:
                e.update(
                    benchmark=structured_retail.VERSION, cutoffIndex=len(e["input"]["observations"])
                )
        jsonl(root / f"{name}-inputs.jsonl", inputs)
        jsonl(root / f"{name}-environment.jsonl", list(environment.values()))
    require(
        len(episodes["generated"]) == 60 and len(episodes["retail"]) == 336,
        "Dev cohort size differs",
    )
    historical = read(plan["reference"])
    require(historical["source"]["sourceHash"] == plan["sourceHash"], "Historical source differs")
    parent_metrics = {
        "generated": historical["generatedComparison"]["results"]["after-value"]["metrics"],
        "retail": historical["results"]["value"]["metrics"],
    }
    model, tokenizer, config, _ = structured_train.load(plan["checkpoint"], "cuda")
    require(weights_hash(model.state_dict()) == refit["plan"]["parentWeightsHash"], "Wrong parent")
    model.requires_grad_(False).eval()
    public_dir = Path(plan["publicDataset"])
    public_rows = [
        r
        for r in lines(public_dir / "inputs.jsonl")
        if r["split"] == "dev" and r["component"] in ("contractnli", "cuad", "orsharc", "tatqa")
    ]
    require(len(public_rows) == 258, "Public document cohort changed")
    cases = [("public", r) for r in public_rows]
    labels = {
        r["id"]: r["target"]
        for r in lines(public_dir / "labels.jsonl")
        if r["id"] in {e["id"] for e in public_rows}
    }
    collection = lines(public_dir / "collection.jsonl")
    public_parent = public_validation(
        model, tokenizer, config, cases, labels, collection, root / "public-parent.jsonl"
    )
    for name in ("value", "recovery"):
        old = model.heads[name]
        replacement = Head(350, 128, old.layers[-1].out_features).cuda().eval()
        weights = copy.deepcopy(old.state_dict())
        weights["layers.0.weight"] = torch.cat(
            [weights["layers.0.weight"], weights["layers.0.weight"].new_zeros((128, 94))], 1
        )
        replacement.load_state_dict(weights)
        model.heads[name] = replacement
    config["encoder"].update(numericState=True, actionPrecision="float32")
    model.config.update(numericState=True, actionPrecision="float32")
    model.requires_grad_(False).eval()
    frozen_hash = weights_hash(
        {k: v for k, v in model.state_dict().items() if not k.startswith("heads.value.")}
    )
    original_forward, outputs, fresh_checks = model.forward, {}, []

    @torch.inference_mode()
    def cached_forward(view):
        key = digest(observed_key(view))
        if key not in outputs:
            outputs[key] = original_forward(view)
        result = dict(outputs[key])
        with torch.autocast("cuda", enabled=False):
            result["value"] = constrain(
                torch.nn.functional.softplus(model.heads["value"](result["valueState"]).float()),
                view.get("valueCosts"),
            )
        if len(fresh_checks) < 12:
            direct = original_forward(view)
            require(
                all(torch.equal(v, direct[k]) for k, v in result.items()),
                "Cached Dev inference differs",
            )
            fresh_checks.append(key)
        return result

    model.forward = cached_forward
    state_cache = {}
    report = {
        "scope": "Frozen full-Train refits on the original controlled Dev; no Test or new-source holdout.",
        "testUsed": False,
        "devUsed": True,
        "trainingPerformed": False,
        "registration": plan,
        "source": provenance({}),
        "parent": parent_metrics,
        "publicParent": public_parent,
        "results": {},
        "gates": {},
    }
    write(root / "registered.json", report)
    for random_seed in refit["plan"]["seeds"]:
        for condition in ("uniform", "balanced"):
            name = f"{condition}-{random_seed}"
            payload = torch.load(
                Path(plan["refit"]) / f"{name}.pt", map_location="cpu", weights_only=True
            )
            require(
                payload["selectedEpoch"] == refit["plan"]["selectedEpochs"][name],
                "Fixed epoch changed",
            )
            model.heads["value"].load_state_dict(payload["weights"])
            require(
                weights_hash(model.heads["value"].state_dict())
                == refit["results"][name]["weightsHash"],
                "Wrong selected head",
            )
            fresh_checks.clear()
            router = CachedRouter(model, tokenizer, config["encoder"])
            router.reset()
            router.cache = state_cache
            generated = []
            with gzip.open(root / f"{name}-generated.jsonl.gz", "wt", compresslevel=3) as stream:
                for e in episodes["generated"]:
                    record = rollout(e, router)
                    stream.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
                    generated.append(record)
            measured = []
            with gzip.open(root / f"{name}-retail.jsonl.gz", "wt", compresslevel=3) as stream:
                for i, e in enumerate(episodes["retail"]):
                    for missing in conditions(0):
                        record = rollout(e, router, missing_responses=frozenset(missing))
                        record["missingResponses"] = list(missing)
                        stream.write(
                            json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n"
                        )
                        measured.append(measurement(record) | {"missingResponses": list(missing)})
                    if (i + 1) % 32 == 0:
                        write(
                            root / "progress.json",
                            {
                                "condition": name,
                                "retailCases": i + 1,
                                "seconds": time.perf_counter() - start,
                            },
                        )
            jsonl(root / f"{name}-retail-measurements.jsonl", measured)
            expected = {str(rate): expectations(measured, rate) for rate in (0, 0.1, 0.2)}
            write(root / f"{name}-retail-expectations.json", expected)
            public = public_validation(
                model, tokenizer, config, cases, labels, collection, root / f"{name}-public.jsonl"
            )
            report["results"][name] = {
                "selectedEpoch": payload["selectedEpoch"],
                "headHash": file_hash(Path(plan["refit"]) / f"{name}.pt"),
                "generated": generated_metrics(generated),
                "retail": {k: structured_compare.means(v) for k, v in expected.items()},
                "public": public,
                "publicRetentionFailures": retained(public_parent, public),
                "cachedForwardChecks": len(fresh_checks),
                "generatedTerminalLoss": sum(r["terminalLoss"] for r in generated) / len(generated),
            }
            write(root / "partial.json", report)
            print(
                {
                    "condition": name,
                    "generatedTotal": report["results"][name]["generated"]["meanTotal"],
                    "retailTotals": {
                        k: v["totalOnCompletePeriods"]["mean"]
                        for k, v in report["results"][name]["retail"].items()
                    },
                    "publicFailures": report["results"][name]["publicRetentionFailures"],
                    "seconds": time.perf_counter() - start,
                },
                flush=True,
            )
        candidate = report["results"][f"balanced-{random_seed}"]
        control = report["results"][f"uniform-{random_seed}"]
        result = {"parent-" + k: v for k, v in gates(parent_metrics, candidate).items()}
        result.update({"uniform-" + k: v for k, v in gates(control, candidate).items()})
        result["publicRetention"] = not candidate["publicRetentionFailures"]
        result["actualImprovementOverParent"] = candidate["generated"][
            "meanTotal"
        ] < parent_metrics["generated"]["meanTotal"] - 1e-9 or any(
            candidate["retail"][k]["totalOnCompletePeriods"]["mean"]
            < parent_metrics["retail"][k]["totalOnCompletePeriods"]["mean"] - 1e-9
            for k in parent_metrics["retail"]
        )
        report["gates"][str(random_seed)] = result
    require(
        weights_hash(
            {k: v for k, v in model.state_dict().items() if not k.startswith("heads.value.")}
        )
        == frozen_hash,
        "Frozen weights changed",
    )
    report.update(
        eligibleForAdoption=all(all(g.values()) for g in report["gates"].values()),
        seconds=time.perf_counter() - start,
        peakGpuBytes=torch.cuda.max_memory_allocated(),
        frozenWeightsPreserved=True,
        rawRollouts=6 * (60 + 16 * 336),
    )
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print(
        {
            "completed": True,
            "seconds": report["seconds"],
            "eligibleForAdoption": report["eligibleForAdoption"],
            "failedGates": {
                s: [k for k, v in g.items() if not v] for s, g in report["gates"].items()
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
