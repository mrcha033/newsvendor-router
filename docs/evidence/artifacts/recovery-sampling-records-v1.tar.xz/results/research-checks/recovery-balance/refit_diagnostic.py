"""Check whether full refitting preserved the selected behavior on cached Train states."""

import os
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from study_recovery_replay import measure, scores

from newsvendor.heads import Head
from newsvendor.io import lines, read, require, write

require(
    os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409",
    "Assigned L40S only",
)
require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
torch.set_num_threads(4)
torch.use_deterministic_algorithms(True)
root = Path("/dev/shm/newsvendor-recovery-balanced-v1")
rows = lines("/dev/shm/newsvendor-recovery-replay-v1/targets.jsonl")
payload = torch.load(
    "/dev/shm/newsvendor-recovery-numeric-v1/features.pt", map_location="cpu", weights_only=True
)
features = [(x.cuda(), y.cuda(), c) for x, y, c in payload["features"]]
families = set(read(root / "report.json")["partitions"]["held"]["families"])
held = [i for i, r in enumerate(rows) if r["family"] in families]
failures = [
    i
    for i, r in enumerate(rows)
    if r["benchmark"] == "retail"
    and len(r["actions"]) > 1
    and "unavailable" in r["state"]["state"].values()
]
head = Head(350, 128, 2).cuda().eval()
report = {
    "scope": "L40S diagnosis on the same cached Train states; not a new sequential evaluation or selection. No changes to registered selected epochs.",
    "devUsed": False,
    "testUsed": False,
    "heldTrainStates": len(held),
    "failureStates": len(failures),
    "results": {},
}
with torch.no_grad():
    for seed in (42, 43, 44):
        for stage, path in (
            ("inner", root / f"balanced-{seed}.pt"),
            (
                "refit",
                Path("/dev/shm/newsvendor-recovery-balanced-refit-v1") / f"balanced-{seed}.pt",
            ),
        ):
            saved = torch.load(path, map_location="cpu", weights_only=True)
            head.load_state_dict(saved["weights"])
            measured = measure(head, features, rows, held)
            decisions = []
            for i in failures:
                values = scores(head, features[i]).sum(-1)
                decisions.append(
                    {
                        "stateKey": rows[i]["inputHash"],
                        "id": rows[i]["id"],
                        "actions": rows[i]["actions"],
                        "values": values.tolist(),
                        "choice": rows[i]["actions"][int(values.argmin())],
                    }
                )
            report["results"][f"{stage}-{seed}"] = {
                "selectedEpoch": saved["selectedEpoch"],
                "held": {k: v for k, v in measured.items() if k != "selectedActions"},
                "heldSelectedActions": measured["selectedActions"],
                "failureDecisions": decisions,
                "failureHolds": sum(d["choice"] == "hold" for d in decisions),
            }
write("results/research-checks/recovery-balance/refit-diagnostic.json", report)
print(
    {
        k: {"heldTargetLoss": v["held"]["meanTargetLoss"], "failureHolds": v["failureHolds"]}
        for k, v in report["results"].items()
    },
    flush=True,
)
