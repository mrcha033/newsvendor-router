"""Inspect fitted Train failure states and explicit-status sensitivity after full refit."""

import copy
import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from study_recovery_replay import scores

from newsvendor.heads import Head
from newsvendor.io import lines, read, write
from newsvendor.structured_value import state_features

torch.set_num_threads(4)
rows = lines("/dev/shm/newsvendor-recovery-replay-v1/targets.jsonl")
payload = torch.load(
    "/dev/shm/newsvendor-recovery-numeric-v1/features.pt", map_location="cpu", weights_only=True
)
features = payload["features"]
directory = Path("/dev/shm/newsvendor-recovery-balanced-refit-v1")
ids = [
    i
    for i, row in enumerate(rows)
    if row["benchmark"] == "retail"
    and len(row["actions"]) > 1
    and "unavailable" in row["state"]["state"].values()
]
assert len(ids) == 6
head = Head(350, 128, 2).eval()
report = {
    "scope": "Six previously observed Train failure states, all included in full refit. Status-only changes are sensitivity probes, not reachable new data or effectiveness evidence.",
    "devUsed": False,
    "testUsed": False,
    "states": len(ids),
    "results": {},
}
with torch.no_grad():
    for name in read(directory / "report.json")["results"]:
        head.load_state_dict(
            torch.load(directory / f"{name}.pt", map_location="cpu", weights_only=True)["weights"]
        )
        outcomes = []
        for i in ids:
            row = rows[i]
            x, y, costs = features[i]
            values = scores(head, features[i]).sum(-1)
            altered = copy.deepcopy(row["state"])
            changed = [k for k, v in altered["state"].items() if v == "unavailable"]
            for key in changed:
                altered["state"][key] = "unconfirmed"
            numeric = state_features(row["input"], altered, row["actions"])
            alternative = torch.cat([x[:, :256], x.new_tensor(numeric)], dim=1)
            altered_values = scores(head, (alternative, y, costs)).sum(-1)
            outcomes.append(
                {
                    "stateKey": row["inputHash"],
                    "id": row["id"],
                    "actions": row["actions"],
                    "changedStatusFields": changed,
                    "estimates": values.tolist(),
                    "statusOnlyAlternative": altered_values.tolist(),
                    "measuredTargets": y.sum(-1).tolist(),
                    "choice": row["actions"][int(values.argmin())],
                    "tanhSaturationFraction": float(
                        (head.layers[0](x).tanh().abs() > 0.99).float().mean()
                    ),
                }
            )
        report["results"][name] = {
            "holds": sum(r["choice"] == "hold" for r in outcomes),
            "rows": outcomes,
        }
write("results/research-checks/recovery-balance/failure-response.json", report)
print({k: {"holds": v["holds"], "cases": len(v["rows"])} for k, v in report["results"].items()})
