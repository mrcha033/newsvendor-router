"""Publish exact raw JSON bytes, fitted heads, measurements and executed sources."""

import gzip
import hashlib
import tarfile
from pathlib import Path

from newsvendor.io import read, write


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def publish(path, files, raw=()):
    require_new = Path(path)
    assert not require_new.exists(), path
    manifest = {
        name: {"bytes": source.stat().st_size, "sha256": sha(source)}
        for name, source in files.items()
    }
    for name, _source, size, checksum in raw:
        assert name not in manifest
        manifest[name] = {"bytes": size, "sha256": checksum}
    with tarfile.open(path, "w:xz", preset=3) as archive:
        for name, source in files.items():
            archive.add(source, arcname=name)
        for name, source, size, _ in raw:
            member = tarfile.TarInfo(name)
            member.size = size
            with gzip.open(source, "rb") as stream:
                archive.addfile(member, stream)
    assert Path(path).stat().st_size < 95 * 1024**2
    seen = set()
    with tarfile.open(path, "r:xz") as archive:
        for member in archive:
            assert member.isfile() and member.size == manifest[member.name]["bytes"]
            assert (
                hashlib.file_digest(archive.extractfile(member), "sha256").hexdigest()
                == manifest[member.name]["sha256"]
            )
            seen.add(member.name)
    assert seen == set(manifest)
    result = {
        "path": str(path),
        "bytes": Path(path).stat().st_size,
        "sha256": sha(path),
        "verifiedEveryMember": True,
        "files": manifest,
    }
    print({k: v for k, v in result.items() if k != "files"}, flush=True)
    return result


def raw_entries(root, destination):
    report = read(root / "report.json")
    entries, metadata = [], {}
    for source in sorted(root.glob("*.jsonl.gz")):
        original = sha(source)
        assert original == report["rawHashes"][source.name]
        size, checksum = 0, hashlib.sha256()
        with gzip.open(source, "rb") as stream:
            while chunk := stream.read(1024 * 1024):
                size += len(chunk)
                checksum.update(chunk)
        name = source.name[:-3]
        metadata[source.name] = {
            "path": name,
            "bytes": size,
            "sha256": checksum.hexdigest(),
            "sourceGzipSha256": original,
            "sourceGzipBytes": source.stat().st_size,
        }
        entries.append((str(Path(destination) / name), source, size, checksum.hexdigest()))
    write(root / "raw-format.json", metadata)
    return entries


def compact_screen(report):
    result = {k: v for k, v in report.items() if k not in ("results", "rawHashes")}
    result["initial"] = {k: v for k, v in result["initial"].items() if k != "selectedActions"}
    result["results"] = {
        k: {
            "selectedEpoch": v["selectedEpoch"],
            "selected": {a: b for a, b in v["selected"].items() if a != "selectedActions"},
            "fit": {a: b for a, b in v["fit"].items() if a != "selectedActions"},
        }
        for k, v in report["results"].items()
    }
    return result


def main():
    checks = Path("results/research-checks/recovery-balance")
    screen = Path("/dev/shm/newsvendor-recovery-balanced-v1")
    sequential = Path("/dev/shm/newsvendor-recovery-balanced-sequential-r2")
    refit = Path("/dev/shm/newsvendor-recovery-balanced-refit-v1")
    dev = Path("/dev/shm/newsvendor-recovery-balanced-dev-v1")
    reports = {
        k: read(p / "report.json")
        for k, p in (("screen", screen), ("sequential", sequential), ("refit", refit), ("dev", dev))
    }
    assert reports["screen"]["eligibleForSequentialTrainCheck"]
    assert reports["sequential"]["eligibleForFullRefit"]
    destinations = {
        screen: "results/l40s-recovery-balanced-v1",
        sequential: "results/l40s-recovery-balanced-sequential-v1",
        refit: "results/l40s-recovery-balanced-refit-v1",
        dev: "results/l40s-recovery-balanced-dev-v1",
    }
    raw = []
    for directory in (sequential, dev):
        raw += raw_entries(directory, destinations[directory])
    raw_archive = publish(
        Path("docs/evidence/artifacts/recovery-sampling-rollouts-v1.tar.xz"), {}, raw
    )
    files = {}
    for directory, destination in destinations.items():
        files.update(
            {
                str(Path(destination) / p.name): p
                for p in directory.iterdir()
                if p.is_file() and not p.name.endswith(".jsonl.gz")
            }
        )
    for failed in (
        "newsvendor-recovery-balanced-sequential-v1",
        "newsvendor-recovery-balanced-sequential-r1",
    ):
        directory = Path("/dev/shm") / failed
        files.update(
            {
                str(Path("results/failed-recovery-preparation") / failed / p.name): p
                for p in directory.iterdir()
                if p.is_file()
            }
        )
    files.update(
        {
            str(p): p
            for p in checks.iterdir()
            if p.is_file() and not p.name.startswith("publication")
        }
    )
    for p in [
        *Path("configs").glob("research-recovery-balanced*.json"),
        *Path("src/newsvendor").glob("*.py"),
        Path("scripts/study_recovery_sampling.py"),
        Path("scripts/study_recovery_replay.py"),
        Path("scripts/evaluate_responses.py"),
        Path("tests/test_recovery_sampling.py"),
        Path("docs/evidence/scripts/reproduce-recovery-sampling.py"),
        Path(".github/workflows/ci.yml"),
    ]:
        files[str(p)] = p
    records = publish(Path("docs/evidence/artifacts/recovery-sampling-records-v1.tar.xz"), files)
    evidence = {
        "scope": "Observed-response sampling, source-held Train screening, new-response sequential Train validation and fixed full-Train refits on original Dev. Controlled documents and responses, not organizational effectiveness.",
        "testUsed": False,
        "devUsed": True,
        "weightsAdopted": False,
        "screen": compact_screen(reports["screen"]),
        "sequential": {k: v for k, v in reports["sequential"].items() if k != "rawHashes"},
        "refit": {k: v for k, v in reports["refit"].items() if k != "rawHashes"},
        "dev": {k: v for k, v in reports["dev"].items() if k != "rawHashes"},
        "diagnostic": read(checks / "diagnostic.json"),
        "samplingAudit": read(checks / "sampling-audit.json"),
        "checks": read(checks / "checks.json"),
        "rawArtifact": raw_archive,
        "artifact": records,
        "rawFormat": "The archive contains decompressed .jsonl records, byte-for-byte identical to the measured gzip contents. raw-format.json preserves original gzip hashes and exact raw-byte hashes. This avoids recompressing already compressed streams; no measurements or their order were changed.",
    }
    if (checks / "outcome-audit.json").exists():
        evidence["outcomeAudit"] = read(checks / "outcome-audit.json")
    diagnostic = read(checks / "refit-diagnostic.json")
    evidence["refitDiagnostic"] = {
        **{k: v for k, v in diagnostic.items() if k != "results"},
        "results": {
            k: {a: b for a, b in v.items() if a != "heldSelectedActions"}
            for k, v in diagnostic["results"].items()
        },
    }
    write("docs/evidence/research-recovery-sampling-results.json", evidence)
    write(checks / "publication.json", {"artifact": records, "rawArtifact": raw_archive})


if __name__ == "__main__":
    main()
