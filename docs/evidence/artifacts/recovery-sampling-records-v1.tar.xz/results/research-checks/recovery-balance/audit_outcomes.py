"""Independently cross-check measured raw trajectories, costs and cohort identities."""

import gzip
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import expectations, measurement

from newsvendor.io import digest, lines, read, write
from newsvendor.structured_compare import means
from newsvendor.structured_metrics import generated_metrics


def checked(path, inputs, expected_split):
    with gzip.open(path, "rt") as stream:
        for row in map(json.loads, stream):
            original = inputs[row["id"]]
            assert row["family"] == original["family"] and row["split"] == expected_split
            assert digest(row["events"][0]["input"]) == digest(original["input"])
            costs = 0.0
            for event in row["events"]:
                if event["action"] in ("c", "p", "v", "b", "demand"):
                    costs += event["input"]["task"]["costs"][event["action"]]
                elif event["action"] == "retrieve":
                    costs += 1.0
            assert math.isclose(costs, row["requestCost"], abs_tol=1e-9)
            if row["total"] is not None:
                assert math.isclose(row["total"], row["terminalLoss"] + costs, abs_tol=1e-9)
            if row["result"] == "handoff":
                assert row["q"] == row["events"][-1]["state"]["q"]
            yield row


report = {
    "scope": "Raw saved trajectories and measurements only; no new inference or selection.",
    "testUsed": False,
    "sequential": {},
    "dev": {},
}
root = Path("/dev/shm/newsvendor-recovery-balanced-sequential-r2")
source = read(root / "report.json")
inputs = {r["id"]: r for r in lines(root / "inputs.jsonl")}
for name, result in source["results"].items():
    records = list(checked(root / f"{name}-rollouts.jsonl.gz", inputs, "train"))
    assert len(records) == 2056
    assert set(Counter(r["id"] for r in records).values()) == {4}
    saved = {(r["id"], r["responseSeed"]): r for r in lines(root / f"{name}-measurements.jsonl")}
    for row in records:
        compare = saved[row["id"], row["responseSeed"]]
        assert all(
            row[k] == compare[k]
            for k in (
                "total",
                "terminalLoss",
                "requestCost",
                "interactions",
                "falseHandoff",
                "q",
                "result",
            )
        )
        assert compare["actions"] == [e["action"] for e in row["events"]]
    for benchmark, expected in result["metrics"]["benchmarks"].items():
        rows = [r for r in records if r["benchmark"] == benchmark]
        assert float(np.mean([r["total"] for r in rows])) == expected["total"]
        assert float(np.mean([r["requestCost"] for r in rows])) == expected["requestCost"]
    report["sequential"][name] = {
        "rawRollouts": len(records),
        "cohortAndCostsExact": True,
        "measurementsExact": True,
    }
    del records

root = Path("/dev/shm/newsvendor-recovery-balanced-dev-v1")
source = read(root / "report.json")
for name, result in source["results"].items():
    inputs = {r["id"]: r for r in lines(root / "generated-inputs.jsonl")}
    generated = list(checked(root / f"{name}-generated.jsonl.gz", inputs, "dev"))
    assert len(generated) == 60 and generated_metrics(generated) == result["generated"]
    inputs = {r["id"]: r for r in lines(root / "retail-inputs.jsonl")}
    measured = []
    for row in checked(root / f"{name}-retail.jsonl.gz", inputs, "dev"):
        measured.append(measurement(row) | {"missingResponses": row["missingResponses"]})
    assert len(measured) == 5376
    assert measured == lines(root / f"{name}-retail-measurements.jsonl")
    for rate in (0, 0.1, 0.2):
        assert means(expectations(measured, rate)) == result["retail"][str(rate)]
    report["dev"][name] = {
        "rawRollouts": 5436,
        "cohortAndCostsExact": True,
        "allMetricsExact": True,
    }
report["verifiedRawRollouts"] = sum(
    v["rawRollouts"] for group in (report["sequential"], report["dev"]) for v in group.values()
)
write("results/research-checks/recovery-balance/outcome-audit.json", report)
print(report, flush=True)
