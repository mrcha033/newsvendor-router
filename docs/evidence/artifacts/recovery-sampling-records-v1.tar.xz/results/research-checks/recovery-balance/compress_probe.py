"""Check lossless raw-record compression without changing any measured JSON bytes."""

import gzip
import hashlib
import tarfile
from pathlib import Path

from newsvendor.io import write

source = Path("/dev/shm/newsvendor-recovery-balanced-dev-v1/uniform-42-retail.jsonl.gz")
destination = Path("/dev/shm/newsvendor-recovery-compression-probe.tar.xz")
assert not destination.exists()
size, checksum = 0, hashlib.sha256()
with gzip.open(source, "rb") as stream:
    while chunk := stream.read(1024 * 1024):
        size += len(chunk)
        checksum.update(chunk)
member = tarfile.TarInfo("uniform-42-retail.jsonl")
member.size = size
with tarfile.open(destination, "w:xz", preset=3) as archive:
    with gzip.open(source, "rb") as stream:
        archive.addfile(member, stream)
with tarfile.open(destination, "r:xz") as archive:
    restored = archive.extractfile(member.name)
    assert hashlib.file_digest(restored, "sha256").hexdigest() == checksum.hexdigest()
report = {
    "source": str(source), "sourceGzipBytes": source.stat().st_size,
    "rawBytes": size, "rawSha256": checksum.hexdigest(),
    "artifactBytes": destination.stat().st_size,
    "allRawBytesPreserved": True,
    "scope": "Lossless container conversion only; all measurements and their order stay unchanged.",
}
write("results/research-checks/recovery-balance/compression-probe.json", report)
print(report, flush=True)
