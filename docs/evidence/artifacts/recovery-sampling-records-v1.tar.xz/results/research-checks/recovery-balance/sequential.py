"""Execute paired uniform/balanced policies on fresh common Train response draws."""

import copy
import gzip
import json
import os
import sys
import time
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import CachedRouter, file_hash

from newsvendor import structured_train
from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_rollout import rollout
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_value import constrain


def observed_key(value):
    if torch.is_tensor(value):
        return ["tensor", str(value.dtype), list(value.shape), value.tolist()]
    if isinstance(value, dict):
        pairs = [[observed_key(k), observed_key(v)] for k, v in value.items()]
        return ["dict", sorted(pairs, key=lambda pair: digest(pair[0]))]
    if isinstance(value, list):
        return ["list", [observed_key(v) for v in value]]
    if isinstance(value, tuple):
        return ["tuple", [observed_key(v) for v in value]]
    return value


def aggregate(records):
    grouped = defaultdict(list)
    for row in records:
        grouped[row["benchmark"]].append(row)
    metrics = {}
    for name, values in grouped.items():
        metrics[name] = {
            "records": len(values),
            "episodes": len({r["id"] for r in values}),
            "families": len({r["family"] for r in values}),
            **{
                k: float(np.mean([r[k] for r in values]))
                for k in ("total", "normalizedTotal", "terminalLoss", "requestCost", "interactions")
            },
            "falseHandoffs": sum(r["falseHandoff"] for r in values),
            "handoffs": sum(r["result"] == "handoff" for r in values),
        }
    return {
        "meanNormalizedTotal": float(np.mean([v["normalizedTotal"] for v in metrics.values()])),
        "benchmarks": metrics,
    }


def main():
    registration = read("configs/research-recovery-balanced-sequential-v1.json")
    require(file_hash(__file__) == registration["scriptHash"], "Sequential source differs")
    require(provenance({})["sourceHash"] == registration["sourceHash"], "Package source differs")
    for path, sha in registration["files"].items():
        require(file_hash(path) == sha, "Registered asset changed: " + path)
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == registration["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    balanced = read(Path(registration["balanced"]) / "report.json")
    require(balanced["eligibleForSequentialTrainCheck"], "Prior registered gates failed")
    plan = balanced["plan"]["sequentialTrainCheck"]
    root = Path(registration["output"])
    require(not root.exists(), "Preserve previous runs")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    start = time.perf_counter()
    prior = read(Path(registration["encoded"]) / "report.json")
    inputs = {r["id"]: r for r in lines(Path(registration["encoded"]) / "initial-inputs.jsonl")}
    environments = lines(Path(registration["encoded"]) / "environment.jsonl")
    episodes = [inputs[r["id"]] | r for r in environments]
    require(
        len(episodes) == 514 and all(e["split"] == "train" for e in episodes),
        "Train cohort changed",
    )
    jsonl(root / "inputs.jsonl", [inputs[r["id"]] for r in environments])
    jsonl(root / "environment.jsonl", environments)
    model, tokenizer, config, _ = structured_train.load(prior["plan"]["checkpoint"], "cuda")
    require(weights_hash(model.state_dict()) == prior["plan"]["weightsHash"], "Wrong parent model")
    original_heads = {k: model.heads[k] for k in ("value", "recovery")}
    for name, old in original_heads.items():
        replacement = Head(350, 128, old.layers[-1].out_features).cuda().eval()
        weights = copy.deepcopy(old.state_dict())
        weights["layers.0.weight"] = torch.cat(
            [weights["layers.0.weight"], weights["layers.0.weight"].new_zeros((128, 94))], dim=1
        )
        replacement.load_state_dict(weights)
        model.heads[name] = replacement
    config["encoder"].update(numericState=True, actionPrecision="float32")
    model.config.update(numericState=True, actionPrecision="float32")
    model.requires_grad_(False).eval()
    frozen = {k: v for k, v in model.state_dict().items() if not k.startswith("heads.value.")}
    frozen_hash = weights_hash(frozen)
    original_forward = model.forward
    outputs = {}
    fresh_checks = []

    @torch.inference_mode()
    def cached_forward(view):
        key = digest(observed_key(view))
        if key not in outputs:
            outputs[key] = original_forward(view)
        result = dict(outputs[key])
        with torch.autocast("cuda", enabled=False):
            result["value"] = constrain(
                torch.nn.functional.softplus(model.heads["value"](result["valueState"]).float()),
                view.get("valueCosts"),
            )
        if len(fresh_checks) < 12:
            direct = original_forward(view)
            require(
                all(torch.equal(v, direct[k]) for k, v in result.items()),
                "Cached inference differs",
            )
            fresh_checks.append(key)
        return result

    model.forward = cached_forward
    state_cache = {}
    report = {
        "scope": "Actual sequential Train policies with new common channel-wise response draws; controlled documents and responses, not independent effectiveness.",
        "source": provenance({}),
        "registration": registration,
        "responsePlan": plan,
        "devUsed": False,
        "testUsed": False,
        "episodes": len(episodes),
        "families": len({e["family"] for e in episodes}),
        "results": {},
        "gates": {},
    }
    write(root / "registered.json", report)
    responses = {}
    for random_seed in balanced["plan"]["seeds"]:
        for condition in ("uniform", "balanced"):
            name = f"{condition}-{random_seed}"
            path = Path(
                registration["numeric"] if condition == "uniform" else registration["balanced"]
            )
            path /= (
                f"continuations-{random_seed}.pt"
                if condition == "uniform"
                else f"balanced-{random_seed}.pt"
            )
            payload = torch.load(path, map_location="cpu", weights_only=True)
            require(
                payload["parentWeightsHash"] == prior["plan"]["weightsHash"], "Wrong parent head"
            )
            model.heads["value"].load_state_dict(payload["weights"])
            fresh_checks.clear()
            router = CachedRouter(model, tokenizer, config["encoder"])
            router.reset()
            router.cache = state_cache
            measurements = []
            with gzip.open(root / f"{name}-rollouts.jsonl.gz", "wt", compresslevel=3) as stream:
                for sample in range(plan["samples"]):
                    draw = digest([plan["responseSeed"], "sequential", sample])
                    for e in episodes:
                        benchmark = "retail" if "forecast" in e["input"]["task"] else "generated"
                        result = rollout(
                            e, router, noise=plan["noise"][benchmark], response_seed=draw
                        )
                        record = {"responseSeed": draw, "benchmark": benchmark, **result}
                        stream.write(json.dumps(record, allow_nan=False) + "\n")
                        for event in result["events"]:
                            if event["action"] not in ("hold", "handoff", "retrieve"):
                                key = (e["id"], draw, event["action"])
                                observed = event["observedResponse"]
                                require(
                                    key not in responses or responses[key] == observed,
                                    "Unpaired channel response",
                                )
                                responses[key] = observed
                        measurements.append(
                            {
                                "id": e["id"],
                                "family": e["family"],
                                "benchmark": benchmark,
                                "sample": sample,
                                "responseSeed": draw,
                                "actions": [v["action"] for v in result["events"]],
                                **{
                                    k: result[k]
                                    for k in (
                                        "total",
                                        "terminalLoss",
                                        "requestCost",
                                        "interactions",
                                        "falseHandoff",
                                        "result",
                                        "q",
                                    )
                                },
                                "normalizedTotal": result["total"] / e["input"]["task"]["hold"],
                            }
                        )
                    write(
                        root / "progress.json",
                        {
                            "condition": name,
                            "sample": sample + 1,
                            "seconds": time.perf_counter() - start,
                        },
                    )
            jsonl(root / f"{name}-measurements.jsonl", measurements)
            report["results"][name] = {
                "headHash": file_hash(path),
                "selectedEpoch": payload["selectedEpoch"],
                "metrics": aggregate(measurements),
                "cachedForwardChecks": len(fresh_checks),
            }
            write(root / "partial.json", report)
            print(
                {
                    "condition": name,
                    "metrics": report["results"][name]["metrics"],
                    "seconds": time.perf_counter() - start,
                },
                flush=True,
            )
        a = report["results"][f"uniform-{random_seed}"]["metrics"]
        b = report["results"][f"balanced-{random_seed}"]["metrics"]
        report["gates"][str(random_seed)] = {
            "improvesActualTotal": b["meanNormalizedTotal"] < a["meanNormalizedTotal"] - 1e-10,
            "neitherBenchmarkWorse": all(
                b["benchmarks"][k]["total"] <= a["benchmarks"][k]["total"] + 1e-10
                for k in a["benchmarks"]
            ),
            "noMoreFalseHandoffs": all(
                b["benchmarks"][k]["falseHandoffs"] <= a["benchmarks"][k]["falseHandoffs"]
                for k in a["benchmarks"]
            ),
        }
    require(
        weights_hash(
            {k: v for k, v in model.state_dict().items() if not k.startswith("heads.value.")}
        )
        == frozen_hash,
        "Frozen weights changed",
    )
    report.update(
        eligibleForFullRefit=all(all(g.values()) for g in report["gates"].values()),
        seconds=time.perf_counter() - start,
        peakGpuBytes=torch.cuda.max_memory_allocated(),
        rawRollouts=len(episodes) * plan["samples"] * len(report["results"]),
        pairedObservedChannels=len(responses),
        cachedViews=len(outputs),
        constructedStates=len(state_cache),
        frozenWeightsPreserved=True,
    )
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print({"completed": True, "seconds": report["seconds"], "gates": report["gates"]}, flush=True)


if __name__ == "__main__":
    main()
