"""Refit both sampling conditions on all Train states at fixed inner-selected epochs."""

import copy
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import file_hash
from study_recovery_sampling import sampling_probabilities

from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import jsonl, lines, read, require, write
from newsvendor.structured_critic import value_loss
from newsvendor.structured_tool_eval import weights_hash


def main():
    plan = read("configs/research-recovery-balanced-refit-v1.json")
    require(file_hash(__file__) == plan["scriptHash"], "Refit source differs")
    require(provenance({})["sourceHash"] == plan["sourceHash"], "Package source differs")
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    for path, sha in plan["files"].items():
        require(file_hash(path) == sha, "Registered asset changed: " + path)
    require(
        read(Path(plan["sequential"]) / "report.json")["eligibleForFullRefit"],
        "Sequential gate failed",
    )
    root = Path(plan["output"])
    require(not root.exists(), "Preserve previous runs")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    start = time.perf_counter()
    payload = torch.load(
        Path(plan["numeric"]) / "features.pt", map_location="cpu", weights_only=True
    )
    rows = lines(Path(plan["encoded"]) / "targets.jsonl")
    require(all(r["split"] == "train" for r in rows), "Train states required")
    features = [(x.cuda(), y.cuda(), c) for x, y, c in payload["features"]]
    require(len(features) == len(rows) == 1204, "Original Train states changed")
    initial = payload["initial"]
    indices = list(range(len(rows)))
    head = Head(350, 128, 2).cuda().eval()
    updates = (len(rows) + plan["batchSize"] - 1) // plan["batchSize"]
    report = {
        "scope": "Full Train refit at epochs fixed by the prior source-held screen; no epoch selection or evaluation on Dev/Test.",
        "devUsed": False,
        "testUsed": False,
        "plan": plan,
        "source": provenance({}),
        "states": len(rows),
        "families": len({r["family"] for r in rows}),
        "initialHeadHash": weights_hash(initial),
        "updatesPerEpoch": updates,
        "results": {},
    }
    write(root / "registered.json", report)
    for condition in ("uniform", "balanced"):
        probability = sampling_probabilities(
            rows, indices, 0 if condition == "uniform" else plan["mixture"]
        )
        jsonl(
            root / f"{condition}-sampling.jsonl",
            [
                {
                    "index": i,
                    "stateKey": rows[i]["inputHash"],
                    "family": rows[i]["family"],
                    "probability": float(p),
                }
                for i, p in zip(indices, probability, strict=True)
            ],
        )
        for random_seed in plan["seeds"]:
            name = f"{condition}-{random_seed}"
            epoch_fixed = plan["selectedEpochs"][name]
            require(0 < epoch_fixed <= plan["epochs"], "Invalid fixed refit epoch")
            head.load_state_dict(initial)
            random = np.random.default_rng(random_seed)
            optimizer = torch.optim.AdamW(
                head.parameters(), lr=plan["lr"], weight_decay=0.01, fused=True
            )
            history, orders = [], []
            saved, saved_optimizer = None, None
            for epoch in range(1, plan["epochs"] + 1):
                losses = []
                for _ in range(updates):
                    order = random.choice(
                        indices,
                        size=plan["batchSize"],
                        replace=True,
                        **({"p": probability} if condition == "balanced" else {}),
                    )
                    orders.append(order.tolist())
                    optimizer.zero_grad(set_to_none=True)
                    loss = value_loss(head, [features[int(i)] for i in order], plan["rankWeight"])
                    require(torch.isfinite(loss).item(), "Nonfinite refit loss")
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(head.parameters(), 5, error_if_nonfinite=True)
                    optimizer.step()
                    losses.append(float(loss.detach()))
                history.append({"epoch": epoch, "meanSampledLoss": float(np.mean(losses))})
                if epoch == epoch_fixed:
                    saved, saved_optimizer = (
                        copy.deepcopy(head.state_dict()),
                        copy.deepcopy(optimizer.state_dict()),
                    )
            require(saved is not None, "Fixed checkpoint not captured")
            torch.save(
                {
                    "weights": saved,
                    "optimizer": saved_optimizer,
                    "finalWeights": head.state_dict(),
                    "finalOptimizer": optimizer.state_dict(),
                    "selectedEpoch": epoch_fixed,
                    "finalEpoch": plan["epochs"],
                    "seed": random_seed,
                    "numericState": True,
                    "actionPrecision": "float32",
                    "parentWeightsHash": plan["parentWeightsHash"],
                    "initialHeadHash": report["initialHeadHash"],
                },
                root / f"{name}.pt",
            )
            write(root / f"{name}-batches.json", orders)
            report["results"][name] = {
                "selectedEpoch": epoch_fixed,
                "epochs": history,
                "weightsHash": weights_hash(saved),
                "headFileHash": file_hash(root / f"{name}.pt"),
            }
            write(root / "partial.json", report)
            print(
                {"condition": name, "epoch": epoch_fixed, "seconds": time.perf_counter() - start},
                flush=True,
            )
    report.update(
        seconds=time.perf_counter() - start, peakGpuBytes=torch.cuda.max_memory_allocated()
    )
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print({"completed": True, "seconds": report["seconds"]}, flush=True)


if __name__ == "__main__":
    main()
