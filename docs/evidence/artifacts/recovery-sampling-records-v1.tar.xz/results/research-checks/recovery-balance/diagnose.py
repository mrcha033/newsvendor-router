"""Inspect only the registered fitting sources before a sampling comparison."""

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from study_recovery_replay import scores
from newsvendor.heads import Head
from newsvendor.io import lines, read, write
from newsvendor.structured_critic import value_loss


def response_group(row):
    answers = [
        h.get("answer") for h in row["input"]["history"]
        if h["action"] in ("c", "p", "v", "b", "demand")
    ]
    if any(a is None or (isinstance(a, str) and a == "no_response") for a in answers):
        return "unanswered"
    if any(isinstance(a, str) and a == "partial" for a in answers):
        return "partial"
    return "answered" if answers else "initial"


torch.set_num_threads(4)
root = Path("/dev/shm/newsvendor-recovery-replay-v1")
rows = lines(root / "targets.jsonl")
prior = read(root / "report.json")
families = set(prior["partitions"]["fit"]["families"])
payload = torch.load(
    "/dev/shm/newsvendor-recovery-numeric-v1/features.pt", map_location="cpu", weights_only=True
)
features = payload["features"]
head = Head(350, 128, 2).eval()
head.load_state_dict(payload["initial"])
groups = defaultdict(list)
failed = []
for i, row in enumerate(rows):
    if row["family"] not in families:
        continue
    groups[(row["benchmark"], response_group(row))].append(i)
    if row["benchmark"] == "retail" and len(row["actions"]) > 1 and "unavailable" in row["state"]["state"].values():
        failed.append(i)
fit = [i for ids in groups.values() for i in ids]


def gradient(ids):
    head.zero_grad(set_to_none=True)
    value_loss(head, [features[i] for i in ids]).backward()
    return torch.cat([p.grad.flatten() for p in head.parameters()]).detach().clone()


grad = gradient(fit)
rare = gradient(failed)
report = {
    "scope": "Training-fit sources only; no held-source gradient or outcome selection.",
    "testUsed": False,
    "devUsed": False,
    "fitStates": len(fit),
    "fittedRetailFailureChoices": len(failed),
    "rareUniformMass": len(failed) / len(fit),
    "expectedRareVisitsPerEpoch": 15 * 64 * len(failed) / len(fit),
    "gradientNorm": float(grad.norm()),
    "rareGradientNorm": float(rare.norm()),
    "rareGlobalGradientCosine": float(torch.nn.functional.cosine_similarity(grad, rare, dim=0)),
    "groups": {},
    "rare": [],
}
with torch.no_grad():
    for (benchmark, group), ids in groups.items():
        activations = torch.cat([head.layers[0](features[i][0]) for i in ids])
        report["groups"][benchmark + ":" + group] = {
            "states": len(ids),
            "families": len({rows[i]["family"] for i in ids}),
            "actions": dict(Counter(len(rows[i]["actions"]) for i in ids)),
            "meanLoss": float(value_loss(head, [features[i] for i in ids])),
            "tanhSaturationFraction": float((activations.tanh().abs() > 0.99).float().mean()),
            "preactivationAbsMean": float(activations.abs().mean()),
        }
    for i in failed:
        x, target, costs = features[i]
        estimates = scores(head, features[i])
        report["rare"].append({
            "id": rows[i]["id"],
            "stateKey": rows[i]["inputHash"],
            "actions": rows[i]["actions"],
            "history": rows[i]["input"]["history"],
            "state": rows[i]["state"]["state"],
            "target": target.tolist(),
            "estimate": estimates.tolist(),
            "inputNorm": float(x.norm()),
        })
write("results/research-checks/recovery-balance/diagnostic.json", report)
print(json.dumps({k: v for k, v in report.items() if k != "rare"}))
