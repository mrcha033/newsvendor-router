import hashlib
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import read, require, write


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


root = Path("results/l40s-research-scope-v1")
plan = read(root / "registered.json")
require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned GPU only")
require(provenance({})["sourceHash"] == plan["source"]["sourceHash"], "Source changed")
for name, expected in plan["files"].items():
    require(sha(name) == expected, "Registered file changed: " + name)
started = time.perf_counter()
state = {"status": "running", "pid": os.getpid(), "completed": [], "testUsed": False}
for mode, path in plan["configs"].items():
    config = read(path)
    output = Path(config["output"])
    require(not output.exists(), "Preserve prior run: " + str(output))
    require(shutil.disk_usage(root).free > 6.5 * 1024**3, "Insufficient space for full optimizer checkpoints")
    log = root / (mode + ".log")
    with log.open("w") as stream:
        child = subprocess.Popen([sys.executable, "scripts/run_research.py", "--config", path, "--stage", "train"], stdout=stream, stderr=subprocess.STDOUT)
        state.update(mode=mode, childPid=child.pid, output=str(output))
        write(root / "queue.json", state)
        print({"stage": "start", "mode": mode, "pid": child.pid}, flush=True)
        code = child.wait()
    state["exitCode"] = code
    if code:
        state["status"] = "failed"
        write(root / "queue.json", state)
        raise SystemExit(code)
    require(read(output / "job.json")["stage"] == "complete", "Incomplete training output")
    state["completed"].append(mode)
    write(root / "queue.json", state)
    print({"stage": "complete", "mode": mode}, flush=True)
state.update(status="complete", childPid=None, seconds=time.perf_counter() - started)
write(root / "queue.json", state)
print(state, flush=True)
