import argparse
import hashlib
import subprocess
import tarfile
from pathlib import Path

from newsvendor.io import read, require, write


def sha(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument("mode", choices=("control", "prefix"))
args = parser.parse_args()
root = Path("results/l40s-research-scope-v1") / args.mode
output = root / "42"
require(read(output / "job.json")["stage"] == "complete", "Training is still running")
paths = {str(p.relative_to(output)): p for p in sorted(output.rglob("*")) if p.is_file()}
if args.mode == "prefix":
    paths["epoch1.pt"] = Path("/dev/shm/newsvendor-scope-prefix-epoch1.pt")
files = {name: {"sha256": sha(p), "bytes": p.stat().st_size} for name, p in paths.items()}
archive = Path("/dev/shm/newsvendor-scope-" + args.mode + ".tar.zst")
require(not archive.exists(), "Preserve prior archive")
with archive.open("wb") as stream:
    process = subprocess.Popen(["zstd", "-T2", "-3", "--long=31", "-c"], stdin=subprocess.PIPE, stdout=stream)
    with tarfile.open(fileobj=process.stdin, mode="w|") as tar:
        for name, path in paths.items():
            tar.add(path, arcname=name)
    process.stdin.close()
    require(process.wait() == 0, "Archive compression failed")
process = subprocess.Popen(["zstd", "--long=31", "-dc", str(archive)], stdout=subprocess.PIPE)
seen = set()
with tarfile.open(fileobj=process.stdout, mode="r|") as tar:
    for member in tar:
        if not member.isfile():
            continue
        require(member.name in files and member.name not in seen, "Unexpected archive entry")
        entry = files[member.name]
        require(member.size == entry["bytes"], "Archive size differs")
        require(hashlib.file_digest(tar.extractfile(member), "sha256").hexdigest() == entry["sha256"], "Archive hash differs")
        seen.add(member.name)
require(process.wait() == 0 and seen == set(files), "Incomplete verification")
write(root / "archive.json", {"temporaryArchive": str(archive), "sha256": sha(archive), "bytes": archive.stat().st_size, "files": files, "allHashesVerified": True, "durable": False})
print({"mode": args.mode, "files": len(files), "archiveBytes": archive.stat().st_size}, flush=True)
