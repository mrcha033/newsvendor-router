from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, write
from newsvendor.suite import check

root = Path(__file__).resolve().parent
result = {}
for name in read(root / "source-checks.json"):
    directory = Path("data/processed") / name
    result[name] = {"manifestHash": file_hash(directory / "manifest.json"), "check": check(directory)}
    write(root / "source-checks-final.json", result)
write(root / "verification-source.json", provenance({}))
print({k:{n:r["check"][n] for n in ("sourceOverlaps", "inputOverlaps")} for k,r in result.items()})
