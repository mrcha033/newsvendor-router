import argparse
import hashlib
import os
import tarfile
import time
from collections import defaultdict
from pathlib import Path

import torch

from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import prepare, research_input
from newsvendor.structured_retail import parameter_metrics
from newsvendor.structured_rollout import FIELDS, TEXT, ResearchRouter
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_train import load


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    plan = read(args.config)
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned GPU only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    require(provenance({})["sourceHash"] == plan["source"]["sourceHash"], "Source changed")
    for name, expected in plan["files"].items():
        require(sha(name) == expected, "Registered file changed: " + name)
    root = Path(plan["output"])
    require(not root.exists(), "Preserve prior measurements")
    root.mkdir(parents=True)
    write(root / "registered.json", plan)
    with tarfile.open(root / "source.tar.gz", "w:gz") as archive:
        for name in plan["source"]["sources"]:
            archive.add(name, arcname=name)
    rows = lines(plan["inputs"])
    require(all(r["split"] == "train" for r in rows), "Train-only diagnosis")
    torch.set_num_threads(8)
    torch.manual_seed(42)
    started = time.perf_counter()
    report = {"scope": plan["scope"], "testUsed": False, "trainingPerformed": False, "registration": plan, "models": {}}
    for name, checkpoint in plan["models"].items():
        model, tokenizer, config, _ = load(checkpoint, "cuda")
        model_hash = weights_hash(model.state_dict())
        model_result = {}
        source_locations = {}
        for enabled in (False, True):
            mode = "scope" if enabled else "original"
            settings = config["encoder"] | {"scopePrefix": enabled}
            router = ResearchRouter(model, tokenizer, settings, config["noValue"])
            raw, groups = [], defaultdict(lambda: defaultdict(int))
            for index, row in enumerate(rows):
                state = router.construct(row["input"])
                metrics = parameter_metrics(row["input"], state)
                observed = research_input(row["input"], settings)
                view = prepare(observed, tokenizer, settings, fields=FIELDS, actions=[{"id": "hold", "text": TEXT["hold"]}], round=sum(h["action"] == "retrieve" for h in row["input"]["history"]))
                budget = min(settings["queryTokens"], settings["maxLength"] // 3)
                prefix = tokenizer.decode(view["batch"]["input_ids"][0, 1:1 + budget])
                visible = {k: row["input"]["task"][k] in prefix for k in ("sku", "period")}
                loc_hash = digest(view["locations"])
                if enabled:
                    require(loc_hash == source_locations[index], "Changed pointer sources")
                else:
                    source_locations[index] = loc_hash
                raw.append({k: row[k] for k in ("id", "family", "condition", "inputHash")} | {"modelInputHash": digest(observed), "state": state, "metrics": metrics, "prefix": prefix, "scopeVisible": visible, "locationHash": loc_hash})
                for group_name in ("all", row["condition"]):
                    g = groups[group_name]
                    g["states"] += 1
                    g["fields"] += 4
                    for out, key in (("valueErrors", "parameterAccuracy"), ("rawValueErrors", "rawParameterAccuracy"), ("stateErrors", "stateAccuracy")):
                        g[out] += round(4 * (1 - metrics[key]))
                    g["evidenceErrors"] += metrics["evidenceCount"] - metrics["evidenceCorrect"]
                    g["evidenceFields"] += metrics["evidenceCount"]
                    g["scopeAbsent"] += not all(visible.values())
                    g["unreadCases"] += state["retrieval"]["unreadChunks"] > 0
                if (index + 1) % 256 == 0:
                    print({"model": name, "mode": mode, "processed": index + 1, "total": len(rows)}, flush=True)
            path = root / (name + "-" + mode + ".jsonl")
            jsonl(path, raw)
            model_result[mode] = {"groups": dict(groups), "rawHash": sha(path)}
            report["models"][name] = {"checkpoint": checkpoint, "weightsHash": model_hash, "conditions": model_result}
            write(root / "report.json", report)
            print({"model": name, "mode": mode, "groups": dict(groups)}, flush=True)
            del router
        require(weights_hash(model.state_dict()) == model_hash, "Weights changed during diagnosis")
        del model, tokenizer
        torch.cuda.empty_cache()
    report["seconds"] = time.perf_counter() - started
    write(root / "report.json", report)


if __name__ == "__main__":
    main()
