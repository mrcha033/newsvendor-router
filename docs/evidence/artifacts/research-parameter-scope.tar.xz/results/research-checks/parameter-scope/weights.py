from pathlib import Path

import torch

from newsvendor.bundle import file_hash
from newsvendor.io import write
from newsvendor.structured_tool_eval import weights_hash

torch.set_num_threads(4)
parent_path = Path("results/l40s-research-forecast-v1/base/42/model.pt")
parent = torch.load(parent_path, map_location="cpu", weights_only=True, mmap=True)
print(list(parent), flush=True)
base = parent["weights"]
result = {"parentHash": file_hash(parent_path), "parentWeightsHash": weights_hash(base), "models": {}}
for mode in ("control", "prefix"):
    root = Path(f"results/l40s-research-scope-v1/{mode}/42")
    current = torch.load(root / "language-progress.pt", map_location="cpu", weights_only=True, mmap=True)
    weights = current["weights"]
    groups = {}
    for key, before in base.items():
        group = key.split(".")[0]
        record = groups.setdefault(group, {"tensors": 0, "changed": 0, "maxAbsoluteChange": 0.0})
        record["tensors"] += 1
        if not torch.equal(before, weights[key]):
            record["changed"] += 1
            record["maxAbsoluteChange"] = max(record["maxAbsoluteChange"], float((weights[key].float() - before.float()).abs().max()))
    result["models"][mode] = {"lastCheckpointHash": file_hash(root / "language-progress.pt"), "weightsHash": weights_hash(weights), "groups": groups}
write("results/research-checks/parameter-scope/weight-updates.json", result)
print(result, flush=True)
