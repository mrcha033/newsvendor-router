import os
import shutil
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

require(Path("results/l40s-parameter-scope-held-v1/report.json").exists(), "Held evaluation is not complete")
updates = read("results/research-checks/parameter-scope/weight-updates.json")
for mode in ("control", "prefix"):
    root = Path("results/l40s-research-scope-v1") / mode
    metadata = read(root / "archive.json")
    require(metadata["allHashesVerified"], "Archive members not verified")
    source = Path(metadata["temporaryArchive"])
    target = root / "full-run.tar.zst"
    require(not target.exists(), "Preserve existing durable archive")
    require(shutil.disk_usage(root).free > metadata["bytes"] + 400_000_000, "Insufficient durable storage")
    require(file_hash(source) == metadata["sha256"], "Temporary archive changed")
    with source.open("rb") as src, target.open("xb") as dst:
        shutil.copyfileobj(src, dst, 8 * 1024 * 1024)
        dst.flush()
        os.fsync(dst.fileno())
    require(target.stat().st_size == metadata["bytes"] and file_hash(target) == metadata["sha256"], "Durable copy verification failed")
    archived = []
    for name in ("language-progress.pt", "policy-base.pt"):
        path = root / "42" / name
        require(file_hash(path) == metadata["files"][name]["sha256"], "Checkpoint changed after archiving")
        if name == "language-progress.pt":
            require(updates["models"][mode]["lastCheckpointHash"] == file_hash(path), "Wrong audited checkpoint")
        path.unlink()
        archived.append(name)
    write(root / "storage.json", {
        "archive": str(target), "sha256": metadata["sha256"], "bytes": metadata["bytes"],
        "allMemberHashesVerified": True, "durableCopyVerified": True, "archiveOnly": archived + (["epoch1.pt"] if mode == "prefix" else []),
        "files": metadata["files"], "restore": "zstd --long=31 -dc " + str(target) + " | tar -xf - -C <new-directory>",
        "note": "Only identical verified local checkpoint duplicates were removed. All measurements and both selected/common checkpoints remain directly accessible."})
    print({"mode": mode, "durable": str(target), "archiveOnly": archived}, flush=True)
