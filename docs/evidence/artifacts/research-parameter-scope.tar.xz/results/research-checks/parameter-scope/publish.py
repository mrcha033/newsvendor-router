import hashlib
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write

root = Path("results/research-checks/parameter-scope")
run = Path("results/l40s-research-scope-v1")
probe = Path("results/l40s-parameter-scope-v1")
held = Path("results/l40s-parameter-scope-held-v1")
registered = read(run / "registered.json")
comparison = read(held / "report.json")
require(read(run / "queue.json")["status"] == "complete", "Training unfinished")
reports = {m: read(run / m / "42/report.json") for m in ("control", "prefix")}
storage = {m: read(run / m / "storage.json") for m in reports}
for mode, record in storage.items():
    require(record["allMemberHashesVerified"] and record["durableCopyVerified"], "Checkpoint archive incomplete")
    require(file_hash(record["archive"]) == record["sha256"], "Private archive changed")
    with tarfile.open(run / mode / "42/source.tar.gz", "r:gz") as archive:
        for name, expected in registered["source"]["sources"].items():
            require(hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected, "Training source snapshot changed")
for name, record in comparison["models"].items():
    require(file_hash(held / (name + ".jsonl")) == record["rawHash"], "Held raw prediction changed")
require("279 passed in 30.89s" in (root / "tests-final.log").read_text(), "Tests not verified")
require("All checks passed!" in (root / "ruff-final.log").read_text(), "Ruff failed")
checks = {
    "tests": {"passed": 279, "seconds": 30.89, "logHash": file_hash(root / "tests-final.log")},
    "ruff": {"passed": True, "formatFiles": 87, "logHash": file_hash(root / "ruff-final.log")},
    "sourceChecks": read(root / "source-checks-final.json"),
    "numericalSmoke": read("results/smoke.json"),
    "preflight": read(root / "preflight.json"),
    "currentSourceHash": provenance({})["sourceHash"],
}
require(len(checks["sourceChecks"]) == 4, "Incomplete source checks")
for record in checks["sourceChecks"].values():
    require(record["check"]["sourceOverlaps"] == record["check"]["inputOverlaps"] == 0, "Source leakage")
require(checks["numericalSmoke"]["smokeEpisodes"] == 30 and checks["numericalSmoke"]["falseHandoffs"] == 0, "Numerical smoke failed")
write(root / "checks.json", checks)
summary = {}
for mode, report in reports.items():
    summary[mode] = {
        "seconds": report["seconds"], "peakGpuGiB": report["peakGpuBytes"] / 1024**3,
        "selectedEpoch": report["language"]["selectedEpoch"], "language": report["language"],
        "generated": report["finalGeneratedDev"], "retail": report["finalDev"], "publicDocuments": report["documentsDev"],
        "adopted": False,
        "reason": "Public TAT-QA regression and 20 new missed retail requests" if mode == "control" else "Public TAT-QA/ContractNLI regression and increased generated Dev loss",
    }
write(root / "training-summary.json", summary)
paths = set()
for directory in (root, probe, held, run):
    paths.update(p for p in directory.rglob("*") if p.is_file() and p.suffix not in (".pt", ".zst", ".pyc") and p != root / "publish.log")
paths.update(Path(p) for p in ("configs/parameter-scope-probe-v1.json", "configs/parameter-scope-held-v1.json", "configs/l40s-research-scope-control-v1.json", "configs/l40s-research-scope-prefix-v1.json", "src/newsvendor/structured_inputs.py", "src/newsvendor/structured_rollout.py", "src/newsvendor/structured_train.py", "tests/test_structured.py"))
files = {str(p): {"sha256": file_hash(p), "bytes": p.stat().st_size} for p in sorted(paths)}
archive = Path("docs/evidence/artifacts/research-parameter-scope.tar.xz")
require(not archive.exists(), "Preserve prior public evidence")
print({"stage": "archive", "files": len(files), "rawBytes": sum(x["bytes"] for x in files.values())}, flush=True)
with tarfile.open(archive, "w:xz", preset=3) as tar:
    for name in files:
        tar.add(name, arcname=name)
with tarfile.open(archive, "r:xz") as tar:
    require(set(tar.getnames()) == set(files), "Public archive file set changed")
    for name, entry in files.items():
        require(hashlib.file_digest(tar.extractfile(name), "sha256").hexdigest() == entry["sha256"], "Public archive hash changed")
result = {
    "scope": "Matched two-epoch full-encoder comparison using normal-format Train contrasts with and without an explicit SKU/period prefix; neither candidate adopted",
    "testUsed": False, "modelReplacementMade": False,
    "retainedCheckpoint": "results/l40s-research-forecast-v1/base/42/model.pt",
    "retainedCheckpointHash": "e2fb23ee44b7a6c7158b111d122280d41f3626027f33323ff98f0fddc765904a",
    "fixedWeightProbe": read(probe / "report.json"), "registration": registered,
    "training": summary, "heldContrasts": comparison, "weightUpdates": read(root / "weight-updates.json"),
    "checks": checks, "privateStorage": storage,
    "publishedRaw": {"path": str(archive), "sha256": file_hash(archive), "bytes": archive.stat().st_size, "files": files, "allHashesVerified": True},
    "limitations": [
        "Held augmentation sources were previously observed as original Train; this is not independent-source or real organizational effectiveness.",
        "One seed, two epochs, unchanged GRU and no additional action-value fitting. Changed shared representations can affect existing action scores; this comparison does not isolate the cause of every missed request.",
        "The prefix first epoch has the fewest held contrast errors, but failed the predeclared original Dev state-retention gate. It was preserved and reported, not selected post hoc.",
        "Retail exact loss covers five unique periods crossed with seven conditions. Generated Dev has 60 cases from 12 families. Neither is the legacy Test target.",
        "The optional prefix remains disabled in the selected model. The full candidate/optimizer archives are local; their raw measurements and hashes are public.",
    ],
}
write("docs/evidence/research-parameter-scope-results.json", result)
print({"stage": "published-evidence", "archive": str(archive), "bytes": archive.stat().st_size}, flush=True)
