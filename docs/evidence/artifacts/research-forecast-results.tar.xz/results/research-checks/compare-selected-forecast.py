"""Registered Dev rollout with only the GRU changed, after forecast gates pass."""

import copy
import os
import tarfile
import time
from pathlib import Path

import torch

from newsvendor import structured_retail, structured_train
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_rollout import ResearchRouter, rollout
from newsvendor.structured_tool_eval import weights_hash

study = Path("results/l40s-demand-selection-v2")
comparison = read(study / "comparison.json")
require(comparison["eligibleForCoreRollout"], "Forecast adoption gates failed")
require(
    comparison["candidateSeed"] == 42 and not comparison["testUsed"], "Wrong candidate or split"
)
require(
    os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409"
    and torch.cuda.device_count() == 1
    and "L40S" in torch.cuda.get_device_name(0),
    "Assigned L40S only",
)
torch.set_num_threads(4)
torch.use_deterministic_algorithms(True)
root = Path("results/l40s-research-forecast-v1")
require(not root.exists(), "Preserve previous rollouts")
parent = Path("results/l40s-research-replay-v1/base/42/model.pt")
candidate = study / "42/model.pt"
require(
    digest(parent.read_bytes())
    == "2461f9fa09a4587a0988119c7bd55139346365c5675501422428a6c15a8a7c5b",
    "Changed selected parent",
)
require(
    digest(candidate.read_bytes())
    == read(study / "report.json")["runs"]["42"]["rawHashes"]["model.pt"],
    "Changed forecast candidate",
)
rows = [
    r
    for r in lines("data/processed/core-retail-train-v1/inputs.jsonl")
    if r["component"] == "retail" and r["split"] == "dev"
]
episodes = structured_retail.cases(rows, 53, 7)
root.mkdir()
jsonl(
    root / "inputs.jsonl", [{k: e[k] for k in ("id", "family", "split", "input")} for e in episodes]
)
input_hash = digest((root / "inputs.jsonl").read_bytes())
ids = {r["id"] for r in rows}
labels = {
    r["id"]: r["target"]
    for r in lines("data/processed/core-retail-train-v1/labels.jsonl")
    if r["id"] in ids
}
episodes = structured_retail.attach_targets(episodes, rows, labels)
plan = {
    "scope": "Actual linked retail Dev manager-request rollouts; frozen language/parameter/action weights and only GRU changed. Controlled financial documents, not organizational effectiveness.",
    "testUsed": False,
    "trainingPerformed": False,
    "parent": str(parent),
    "parentHash": digest(parent.read_bytes()),
    "candidate": str(candidate),
    "candidateHash": digest(candidate.read_bytes()),
    "comparisonHash": digest((study / "comparison.json").read_bytes()),
    "source": provenance(read("configs/l40s-demand-selection-v2.json")),
    "scriptHash": digest(Path(__file__).read_bytes()),
    "inputHash": input_hash,
    "episodes": len(episodes),
    "families": sorted({e["family"] for e in episodes}),
    "adoption": [
        "Candidate value-policy total loss on complete periods must be lower than same-parent retained GRU.",
        "Invalid handoffs and unnecessary requests may not increase; parameter, state and evidence accuracy may not decrease.",
        "Necessary requests and recovery may not decrease, and missing parameters at stop may not increase.",
        "Report checklist and all censored lower-bound results; complete periods are not independent financial conditions.",
    ],
    "historicalReference": {
        "path": "docs/evidence/research-replay-results.json",
        "sha256": digest(Path("docs/evidence/research-replay-results.json").read_bytes()),
    },
    "results": {},
}
write(root / "registered.json", plan)
with tarfile.open(root / "source.tar.gz", "w:gz") as archive:
    for p in sorted(Path("src/newsvendor").glob("*.py")):
        archive.add(p, arcname=str(p))
    archive.add(Path(__file__), arcname="results/research-checks/compare-selected-forecast.py")
started = time.perf_counter()
model, tokenizer, config, parent_report = structured_train.load(parent, "cuda")
fixed = weights_hash({k: v for k, v in model.state_dict().items() if not k.startswith("demand.")})
old_demand = {k: v.detach().cpu().clone() for k, v in model.demand.state_dict().items()}
payload = torch.load(candidate, weights_only=True, map_location="cpu")
new_demand = {k.removeprefix("demand."): v for k, v in payload["weights"].items()}
for condition, weights in (("retained", old_demand), ("candidate", new_demand)):
    model.demand.load_state_dict(weights)
    require(
        weights_hash({k: v for k, v in model.state_dict().items() if not k.startswith("demand.")})
        == fixed,
        "Constructor/action weights changed",
    )
    router = ResearchRouter(model, tokenizer, config["encoder"], config["noValue"])
    router.cache_states()
    for policy in ("value", "checklist"):
        records = []
        for index, episode in enumerate(episodes):
            records.append(rollout(episode, router, explore=policy == "checklist", noise=0))
            if (index + 1) % 32 == 0:
                status = {
                    "condition": condition,
                    "policy": policy,
                    "processed": index + 1,
                    "total": len(episodes),
                    "seconds": time.perf_counter() - started,
                }
                write(root / "progress.json", status)
                print(status, flush=True)
        path = root / f"{condition}-{policy}.jsonl"
        jsonl(path, records)
        plan["results"][f"{condition}-{policy}"] = {
            **structured_retail.summarize(records),
            "rawHash": digest(path.read_bytes()),
        }
        write(root / "partial.json", plan)
    router.cache_states(False)
old, new = [plan["results"][f"{name}-value"] for name in ("retained", "candidate")]
historical = read(plan["historicalReference"]["path"])["finalRetailDev"]["learned"]
for metric in (
    "meanTotalOnCompletePeriods",
    "necessaryRequests",
    "unnecessaryRequests",
    "falseHandoffs",
    "finalEvidenceAccuracy",
):
    require(
        abs(old[metric] - historical[metric]) < 1e-8, "Changed retained rollout metric: " + metric
    )
plan["historicalReference"]["metricsReproduced"] = True
gates = {
    "totalLossImproves": new["meanTotalOnCompletePeriods"] < old["meanTotalOnCompletePeriods"],
    "noAdditionalFalseHandoffs": new["falseHandoffs"] <= old["falseHandoffs"],
    "noAdditionalUnnecessaryRequests": new["unnecessaryRequests"] <= old["unnecessaryRequests"],
    "parameterAndStateAccuracyPreserved": all(
        new["finalParameters"][k] >= old["finalParameters"][k]
        for k in ("parameterAccuracy", "allParametersCorrect", "stateAccuracy")
    ),
    "evidenceAccuracyPreserved": new["finalEvidenceAccuracy"] >= old["finalEvidenceAccuracy"],
}
gates["necessaryRequestsAndRecoveryPreserved"] = (
    new["necessaryRequests"] >= old["necessaryRequests"]
    and new["recoveredAfterRequest"] >= old["recoveredAfterRequest"]
)
gates["noAdditionalMissingAtStop"] = (
    new["missingParametersAtStop"] <= old["missingParametersAtStop"]
)
require(digest((root / "inputs.jsonl").read_bytes()) == input_hash, "Outcome labels changed inputs")
require(
    digest(parent.read_bytes()) == plan["parentHash"]
    and digest(candidate.read_bytes()) == plan["candidateHash"],
    "Checkpoint modified",
)
plan.update(
    gates=gates,
    eligible=all(gates.values()),
    fixedWeightsHash=fixed,
    seconds=time.perf_counter() - started,
    peakGpuBytes=torch.cuda.max_memory_allocated(),
    demandHashes={"retained": weights_hash(old_demand), "candidate": weights_hash(new_demand)},
)
if plan["eligible"]:
    saved_config = copy.deepcopy(config)
    saved_config["output"] = str(root / "base/42")
    saved_config["selectedComponents"] = {
        "languageAndActions": {"checkpoint": str(parent), "sha256": plan["parentHash"]},
        "demand": {
            "checkpoint": str(candidate),
            "sha256": plan["candidateHash"],
            "datasetHashes": payload["datasetHashes"],
            "settings": payload["config"]["demand"],
        },
    }
    saved_report = copy.deepcopy(parent_report)
    saved_report["demandReplacement"] = {
        k: plan[k]
        for k in (
            "candidate",
            "candidateHash",
            "comparisonHash",
            "gates",
            "fixedWeightsHash",
            "demandHashes",
        )
    }
    path = root / "base/42/model.pt"
    structured_train.save(path, model, saved_config, saved_report)
    plan["selectedCheckpoint"] = {
        "path": str(path),
        "sha256": digest(path.read_bytes()),
        "configurationHash": digest(saved_config),
    }
write(root / "report.json", plan)
write(root / "job.json", {"stage": "complete", "eligible": plan["eligible"], "testUsed": False})
print(
    {
        "gates": gates,
        "eligible": plan["eligible"],
        "results": {
            k: {
                m: v[m]
                for m in (
                    "meanTotalOnCompletePeriods",
                    "falseHandoffs",
                    "unnecessaryRequests",
                    "finalEvidenceAccuracy",
                )
            }
            for k, v in plan["results"].items()
        },
    },
    flush=True,
)
