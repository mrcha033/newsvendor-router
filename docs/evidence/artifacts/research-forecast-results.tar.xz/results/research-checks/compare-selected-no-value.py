"""Measure the paired no-value policy with the same selected forecast and constructor."""

import copy
import os
import tarfile
import time
from pathlib import Path

import torch

from newsvendor import structured_retail, structured_train
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_rollout import ResearchRouter, rollout
from newsvendor.structured_tool_eval import weights_hash

root = Path("results/l40s-research-forecast-v1")
core = read(root / "report.json")
require(core["eligible"] and not core["testUsed"], "No selected Dev candidate")
require(not (root / "no-value.json").exists(), "Preserve previous evaluation")
require(
    os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409"
    and torch.cuda.device_count() == 1
    and "L40S" in torch.cuda.get_device_name(0),
    "Assigned L40S only",
)
torch.set_num_threads(4)
torch.use_deterministic_algorithms(True)
parent = Path("results/l40s-research-replay-v1/no_value/42/model.pt")
parent_hash = digest(parent.read_bytes())
require(
    parent_hash == "b48ead97bd18b7011cdd364416b0124ebee8c55fad1b2dfbf24825854db1b69e",
    "Changed no-value parent",
)
selected = Path(core["selectedCheckpoint"]["path"])
require(digest(selected.read_bytes()) == core["selectedCheckpoint"]["sha256"], "Changed base")
candidate = Path(core["candidate"])
require(digest(candidate.read_bytes()) == core["candidateHash"], "Changed demand weights")
rows = [
    r
    for r in lines("data/processed/core-retail-train-v1/inputs.jsonl")
    if r["component"] == "retail" and r["split"] == "dev"
]
episodes = structured_retail.cases(rows, 53, 7)
public_inputs = [{k: e[k] for k in ("id", "family", "split", "input")} for e in episodes]
require(public_inputs == lines(root / "inputs.jsonl"), "Changed rollout inputs")
ids = {r["id"] for r in rows}
labels = {
    r["id"]: r["target"]
    for r in lines("data/processed/core-retail-train-v1/labels.jsonl")
    if r["id"] in ids
}
episodes = structured_retail.attach_targets(episodes, rows, labels)
report = {
    "scope": "Paired no-value Dev policy with the selected GRU and identical language/parameter weights; no training and no Test",
    "testUsed": False,
    "trainingPerformed": False,
    "parent": str(parent),
    "parentHash": parent_hash,
    "base": core["selectedCheckpoint"],
    "candidate": str(candidate),
    "candidateHash": core["candidateHash"],
    "inputHash": core["inputHash"],
    "source": core["source"],
    "scriptHash": digest(Path(__file__).read_bytes()),
    "policy": "no_value",
    "episodes": len(episodes),
    "families": core["families"],
}
write(root / "no-value-registered.json", report)
with tarfile.open(root / "no-value-source.tar.gz", "w:gz") as archive:
    for path in sorted(Path("src/newsvendor").glob("*.py")):
        archive.add(path, arcname=str(path))
    archive.add(Path(__file__), arcname="results/research-checks/compare-selected-no-value.py")
started = time.perf_counter()
model, tokenizer, config, parent_report = structured_train.load(parent, "cuda")
require(config["noValue"], "Economic value head must be disabled")
payload = torch.load(candidate, weights_only=True, map_location="cpu")
model.demand.load_state_dict({k.removeprefix("demand."): v for k, v in payload["weights"].items()})
base = torch.load(selected, weights_only=True, map_location="cpu")


def common(weights):
    return weights_hash(
        {k: v for k, v in weights.items() if not k.startswith(("heads.value.", "heads.recovery."))}
    )


fixed = common(model.state_dict())
require(fixed == common(base["weights"]), "Different constructor or forecast")
router = ResearchRouter(model, tokenizer, config["encoder"], no_value=True)
router.cache_states()
records = []
for index, episode in enumerate(episodes):
    records.append(rollout(episode, router, noise=0))
    if (index + 1) % 32 == 0:
        print(
            {
                "processed": index + 1,
                "total": len(episodes),
                "seconds": time.perf_counter() - started,
            },
            flush=True,
        )
router.cache_states(False)
raw = root / "candidate-no-value.jsonl"
jsonl(raw, records)
require(fixed == common(model.state_dict()), "Evaluation modified weights")
require(digest(parent.read_bytes()) == parent_hash, "Parent checkpoint changed")
config = copy.deepcopy(config)
config["output"] = str(root / "no_value/42")
config["selectedComponents"] = {
    "languageAndActions": {"checkpoint": str(parent), "sha256": parent_hash},
    "demand": base["config"]["selectedComponents"]["demand"],
}
saved_report = copy.deepcopy(parent_report)
saved_report["demandReplacement"] = base["report"]["demandReplacement"]
path = root / "no_value/42/model.pt"
structured_train.save(path, model, config, saved_report)
report.update(
    summary=structured_retail.summarize(records),
    rawHash=digest(raw.read_bytes()),
    commonWeightsHash=fixed,
    seconds=time.perf_counter() - started,
    peakGpuBytes=torch.cuda.max_memory_allocated(),
    selectedCheckpoint={"path": str(path), "sha256": digest(path.read_bytes())},
)
write(root / "no-value.json", report)
print(
    {"summary": report["summary"], "sameConstructorAndDemand": True, "seconds": report["seconds"]},
    flush=True,
)
