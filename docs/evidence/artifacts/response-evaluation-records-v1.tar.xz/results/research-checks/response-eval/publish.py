"""Publish all paired response rollouts and the assets needed for offline reproduction."""
import hashlib
import shutil
import tarfile
from pathlib import Path
from newsvendor.io import read,write

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def publish(path, files):
 assert not path.exists(),path
 manifest={n:{'sha256':sha(p),'bytes':p.stat().st_size} for n,p in files.items()}
 with tarfile.open(path,'w:xz',preset=3) as archive:
  for name,p in files.items():archive.add(p,arcname=name)
 assert path.stat().st_size<95*1024**2
 seen=set()
 with tarfile.open(path,'r:xz') as archive:
  for member in archive:
   if not member.isfile():continue
   assert member.size==manifest[member.name]['bytes']
   assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==manifest[member.name]['sha256']
   seen.add(member.name)
 assert seen==set(manifest)
 result={'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'verifiedEveryMember':True,'files':manifest}
 print({k:v for k,v in result.items() if k!='files'},flush=True)
 return result

live=Path('/dev/shm/newsvendor-response-eval-v1');dest=Path('results/l40s-response-eval-v1')
checks=Path('results/research-checks/response-eval')
report=read(live/'report.json')
assert set(report['results'])=={'value','no_value','checklist'}
assert all(r['noDropoutMatchesHistoricalMeasurementsAndOrders'] for r in report['results'].values())
assert read(checks/'checks.json')['tests'].startswith('303 passed')
assert not dest.exists();dest.mkdir()
raw=[]
for policy in ('value','checklist','no_value'):
 p=live/f'{policy}-rollouts.jsonl.gz'
 assert sha(p)==report['results'][policy]['rawHash']
 raw.append(publish(Path(f'docs/evidence/artifacts/response-evaluation-{policy}-v1.tar.xz'),{str(dest/p.name):p}))
files={str(dest/p.name):p for p in sorted(live.iterdir()) if p.is_file() and not p.name.endswith('rollouts.jsonl.gz')}
files[str(dest/'policy-heads.pt')]=checks/'policy-heads.pt'
files.update({str(p):p for p in sorted(checks.iterdir()) if p.is_file() and p.name not in ('publication.log','publication.json')})
for name in ('scripts/evaluate_responses.py','scripts/reproduce_responses.py','tests/test_response_eval.py','configs/research-responses-v1.json','.github/workflows/ci.yml'):
 files[name]=Path(name)
artifact=publish(Path('docs/evidence/artifacts/response-evaluation-records-v1.tar.xz'),files)
evidence={**report,'artifact':artifact,'rawArtifacts':raw,'checks':read(checks/'checks.json'),'policyDelta':read(checks/'policy-heads.json'),'interpretation':'Exact finite response expectation under the stated independent missingness model. Generated contracts and response channels; only five complete observed sales periods. This is a Dev sensitivity comparison, not performance model selection or real organizational effectiveness.'}
for name in ('report.json','registered.json','progress.json'):
 shutil.copy2(live/name,dest/name)
write(dest/'storage.json',{'artifact':artifact,'rawArtifacts':raw})
write('docs/evidence/research-paired-response-results.json',evidence)
write(checks/'publication.json',{'artifact':artifact,'rawArtifacts':raw})
