"""Publish the small no-value policy delta against the already released full base model."""
from pathlib import Path
import torch
from newsvendor.bundle import file_hash
from newsvendor.io import read,write,digest
from newsvendor.structured_tool_eval import weights_hash

plan=read('configs/research-responses-v1.json')
base=torch.load(plan['models']['value']['path'],map_location='cpu',weights_only=True,mmap=True)
other=torch.load(plan['models']['no_value']['path'],map_location='cpu',weights_only=True,mmap=True)
manifest=read('/dev/shm/newsvendor-public-download-1654e77/forecast-v1/manifest.json')
assert weights_hash(base['weights'])==manifest['weightsHash']
assert base['config']['encoder']==other['config']['encoder']==manifest['config']['encoder']
prefixes=('heads.value.','heads.recovery.')
assert all(torch.equal(v,other['weights'][k]) for k,v in base['weights'].items() if not k.startswith(prefixes))
assert base['weights'].keys()==other['weights'].keys()
heads={k:v.clone() for k,v in other['weights'].items() if k.startswith(prefixes)}
out=Path('results/research-checks/response-eval/policy-heads.pt');assert not out.exists()
torch.save({'schema':'newsvendor-policy-delta-v1','baseWeightsHash':manifest['weightsHash'],'weightsHash':weights_hash(other['weights']),'config':{'encoder':other['config']['encoder'],'noValue':True},'weights':heads},out)
meta={'path':str(out),'sha256':file_hash(out),'bytes':out.stat().st_size,'baseBundleWeightsHash':manifest['weightsHash'],'baseCheckpointHash':plan['models']['value']['sha256'],'noValueCheckpointHash':plan['models']['no_value']['sha256'],'noValueWeightsHash':weights_hash(other['weights']),'changedHeadPrefixes':list(prefixes),'allOtherTensorsIdentical':True,'encoderConfigurationIdentical':True,'release':'https://github.com/mrcha033/newsvendor-router/releases/tag/research-forecast-v1'}
write('results/research-checks/response-eval/policy-heads.json',meta)
print(meta,flush=True)
