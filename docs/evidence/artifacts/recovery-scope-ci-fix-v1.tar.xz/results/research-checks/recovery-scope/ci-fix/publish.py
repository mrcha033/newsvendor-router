"""Preserve the original CI failure and the exact-layout test correction."""

import hashlib
import importlib.util
import re
import subprocess
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import read, write

root = Path("results/research-checks/recovery-scope/ci-fix")
source = provenance({})["sourceHash"]
r = read("docs/evidence/research-recovery-scope-results.json")
assert source == r["reports"]["scoped-dev-v1"]["source"]["sourceHash"]
assert "334 passed in 37.49s" in (root / "tests.log").read_text()
assert "2 passed" in (root / "targeted.log").read_text()
old = subprocess.run(
    ["git", "show", "HEAD:tests/test_structured.py"], capture_output=True, check=True
).stdout
patch = subprocess.run(
    ["git", "diff", "--", "tests/test_structured.py"], capture_output=True, check=True
).stdout
(root / "test-fix.patch").write_bytes(patch)
lint = {}
for block in re.findall(
    r"      - run: >-\n((?:          .+\n)+)", Path(".github/workflows/ci.yml").read_text()
):
    command = block.split()
    assert command[:3] == ["uv", "run", "ruff"]
    command = [".venv/bin/ruff", *command[3:]]
    lint[" ".join(command)] = subprocess.run(
        command, text=True, capture_output=True, check=True
    ).stdout.strip()
write(root / "lint.json", lint)
spec = importlib.util.spec_from_file_location(
    "archive_helper", "results/research-checks/recovery-balance/publish.py"
)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
files = {str(p): p for p in root.iterdir() if p.is_file() and p.name != "publication.log"}
files["tests/test_structured.py"] = Path("tests/test_structured.py")
artifact = helper.publish(Path("docs/evidence/artifacts/recovery-scope-ci-fix-v1.tar.xz"), files)
subprocess.run(["git", "diff", "--check"], check=True)
links = 0
for name in [
    "README.md",
    "docs/research-scope.md",
    "docs/recovery-scope.md",
    "docs/model-bundle.md",
]:
    p = Path(name)
    for target in re.findall(r"\]\(([^)]+)\)", p.read_text()):
        if "://" in target or target.startswith("#"):
            continue
        assert (p.parent / target.split("#")[0]).exists(), (name, target)
        links += 1
r["checksBeforeCiCorrection"] = r["finalChecks"]
r["finalChecks"] = {
    **r["finalChecks"],
    "lint": lint,
    "tests": "334 passed in 37.49s",
    "localDocumentLinks": links,
    "sourceHash": source,
    "postCiCorrection": True,
}
r["ciCorrection"] = {
    "failedRun": "https://github.com/mrcha033/newsvendor-router/actions/runs/38014861488",
    "failedParameterizedCases": 2,
    "passedBeforeCorrection": 332,
    "largestAbsoluteDifference": 1.1920928955078125e-7,
    "cause": "The test passed a contiguous 350-column state to the prior, while RecoveryHead uses a strided slice of the 351-column state. CPU GEMM rounding differed for equivalent values with different strides.",
    "change": "Assert both inputs have exactly equal values, then compare the prior with the same sliced input layout used by the head. Keep rtol=atol=0 for the preserved/corrected scores.",
    "oldTestHash": hashlib.sha256(old).hexdigest(),
    "newTestHash": helper.sha(Path("tests/test_structured.py")),
    "runtimeSourceUnchanged": True,
    "modelWeightsUnchanged": True,
    "sourceHash": source,
    "tests": 334,
    "sourceAudits": 5,
    "numericalSmoke": 30,
    "artifact": artifact,
}
write("docs/evidence/research-recovery-scope-results.json", r)
print({"verified": True, "tests": 334, "sourceUnchanged": True, "links": links}, flush=True)
