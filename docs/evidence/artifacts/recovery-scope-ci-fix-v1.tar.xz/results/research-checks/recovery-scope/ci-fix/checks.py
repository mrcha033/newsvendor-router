"""Source-family separation and required numerical smoke before publication."""

import shutil
from pathlib import Path

from newsvendor.cli import provenance, smoke
from newsvendor.io import read, write
from newsvendor.suite import check

root = Path("results/research-checks/recovery-scope/ci-fix")
if Path("results/smoke.json").exists():
    shutil.copy2("results/smoke.json", root / "previous-smoke.json")
names = (
    "complementary",
    "core-retail-train-v1",
    "core-tatqa-train-v1",
    "core-retail-holdout-v1",
    "core-retail-linked-v1",
)
audits = {name: check(Path("data/processed") / name) for name in names}
assert all(v["sourceOverlaps"] == v["inputOverlaps"] == 0 for v in audits.values())
smoke(read("configs/full.json"))
write(root / "checks.json", {
    "source": provenance({}),
    "sources": audits,
    "smoke": read("results/smoke.json"),
})
print({"sourceAudits": len(audits), "overlaps": 0, "smoke": 30}, flush=True)
