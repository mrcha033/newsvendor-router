"""Controlled Newsvendor routing experiments."""
