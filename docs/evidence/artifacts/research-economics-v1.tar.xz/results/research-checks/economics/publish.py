import hashlib,json,tarfile
from pathlib import Path


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


checks=Path('results/research-checks/economics')
analysis=Path('results/decision-effects-v1')
report=json.loads((analysis/'report.json').read_text())
reproduction=json.loads((checks/'reproduction.json').read_text())
assert reproduction['allMatch']
assert '387 passed' in (checks/'tests.log').read_text()
paths=[*Path('src/newsvendor').glob('*.py'),Path('scripts/analyze_decisions.py'),Path('scripts/export_proposal.py'),Path('tests/test_decision_effects.py'),Path('configs/research-economics-v1.json'),Path('pyproject.toml'),Path('uv.lock'),Path('.github/workflows/ci.yml'),Path('README.md'),*[Path('docs')/n for n in ('research.md','research-scope.md','protocol.md','performance-goal.md','verification.md','decision-effects.md','experiment-history.md','proposal.docx','source.json')],*analysis.glob('*'),*[p for p in checks.glob('*') if p.is_file() and not p.name.startswith('publication')]]
files={str(p):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths if p.is_file()}
archive=Path('docs/evidence/artifacts/research-economics-v1.tar.xz');assert not archive.exists()
with tarfile.open(archive,'w:xz',preset=3) as a:
    for p in files: a.add(p,arcname=p)
seen=set()
with tarfile.open(archive,'r:xz') as a:
    for m in a:
        assert m.isfile() and m.size==files[m.name]['bytes']
        assert hashlib.file_digest(a.extractfile(m),'sha256').hexdigest()==files[m.name]['sha256']
        seen.add(m.name)
assert seen==set(files)
artifact={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'verifiedEveryMember':True,'files':files}
evidence={
    'scope':'Exploratory paired decoder modification effects on already-inspected Dev; not AI adoption or human behavior',
    'status':'exploratory-existing-dev','newInference':False,'trainingPerformed':False,'testUsed':False,'humanParticipants':0,
    'report':report,'reproduction':reproduction,
    'checks':{'testsPassed':387,'testLogHash':sha(checks/'tests.log'),'sources':json.loads((checks/'source-checks.json').read_text()),'smoke':json.loads((checks/'smoke.json').read_text()),'logistics':json.loads((checks/'logistics.json').read_text())},
    'documents':json.loads(Path('docs/source.json').read_text()),
    'archive':artifact,
    'nextDesignStatus':'AI x manager-request 2x2 is designed but not executed or preregistered; non-AI control, independent sample and power plan remain required.',
}
Path('docs/evidence/research-economics-results.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
(checks/'publication.json').write_text(json.dumps({k:v for k,v in artifact.items() if k!='files'},indent=2)+'\n')
print({k:v for k,v in artifact.items() if k!='files'})
