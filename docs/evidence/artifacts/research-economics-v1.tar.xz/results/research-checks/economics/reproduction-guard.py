import os,sys
from pathlib import Path
blocked=[Path('/home/yunmin/newsvendor-router')/p for p in ('src','scripts','data','results')]
def check(event,args):
 if event in ('socket.connect','socket.getaddrinfo'): raise RuntimeError('Network disabled for public-data reproduction')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  path=Path(os.fsdecode(args[0])).resolve()
  if any(path.is_relative_to(root) for root in blocked): raise RuntimeError('Original working data/source disabled: '+str(path))
sys.addaudithook(check)
