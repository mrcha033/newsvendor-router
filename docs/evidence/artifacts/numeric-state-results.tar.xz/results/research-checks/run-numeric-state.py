"""Run the three preregistered policy-only conditions sequentially on the assigned L40S."""
import os, subprocess, time, sys
from pathlib import Path
from newsvendor.io import read,write,digest,require
from newsvendor.cli import provenance
from newsvendor.structured_value import STATE_FEATURES
root=Path('results/l40s-research-numeric-v1')
require(not root.exists(),'Preserve previous study')
root.mkdir(parents=True)
configs={name:read(f'configs/l40s-research-numeric-v1-{name}.json') for name in ['control','value','no_value']}
record={'testUsed':False,'source':provenance(configs['value']),'features':list(STATE_FEATURES),'conditions':configs,'scriptHash':digest(Path(__file__).read_bytes()),'results':{}}
write(root/'registered.json',record)
env=dict(os.environ,CUDA_VISIBLE_DEVICES='GPU-674d64b8-4bdf-7006-1791-5dc7f7245409',CUBLAS_WORKSPACE_CONFIG=':4096:8',HF_HUB_OFFLINE='1',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True',PYTHONPATH='src')
for name in configs:
 started=time.perf_counter()
 log=Path(f'results/research-checks/numeric-state-{name}.log')
 with log.open('w') as stream:
  proc=subprocess.Popen(['.venv-l40s/bin/python','scripts/run_research.py','--config',f'configs/l40s-research-numeric-v1-{name}.json','--stage','policy'],env=env,stdout=stream,stderr=subprocess.STDOUT)
  write(root/'queue.json',{'stage':'running','condition':name,'pid':proc.pid,'completed':list(record['results'])})
  print({'condition':name,'pid':proc.pid},flush=True)
  code=proc.wait()
 result={'exitCode':code,'seconds':time.perf_counter()-started,'log':str(log)}
 record['results'][name]=result
 write(root/'queue-results.json',record)
 if code:
  write(root/'queue.json',{'stage':'failed','condition':name,**result})
  raise SystemExit(code)
 print({'condition':name,**result},flush=True)
write(root/'queue.json',{'stage':'complete','completed':list(record['results']),'testUsed':False})
