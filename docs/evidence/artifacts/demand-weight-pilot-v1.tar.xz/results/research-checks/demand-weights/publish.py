"""Preserve the rejected Train-only source-weighting prototype and every raw epoch loss."""
import hashlib
import tarfile
from pathlib import Path
from newsvendor.io import read,write

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

checks=Path('results/research-checks/demand-weights')
live=Path('/dev/shm/newsvendor-demand-weight-pilot-v1')
report=read(live/'report.json')
assert not report['proceedToDevStudy']
files={str(Path('results/l40s-demand-weight-pilot-v1')/p.relative_to(live)):p for p in sorted(live.rglob('*')) if p.is_file()}
files.update({str(p):p for p in sorted(checks.rglob('*')) if p.is_file() and p.name not in ('publication.log','publication.json')})
files[str(checks/'train-audit.json')]=Path('/dev/shm/newsvendor-demand-weight-audit-v1/report.json')
files[str(checks/'baseline-sequence.py')]=Path('/dev/shm/newsvendor-sequence-before-source-weights.py')
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in files.items()}
path=Path('docs/evidence/artifacts/demand-weight-pilot-v1.tar.xz')
assert not path.exists()
with tarfile.open(path,'w:xz',preset=3) as archive:
 for name,p in files.items():archive.add(p,arcname=name)
seen=set()
with tarfile.open(path,'r:xz') as archive:
 for member in archive:
  if not member.isfile():continue
  assert member.name in manifest
  assert member.size==manifest[member.name]['bytes']
  assert hashlib.file_digest(archive.extractfile(member),'sha256').hexdigest()==manifest[member.name]['sha256']
  seen.add(member.name)
assert seen==set(manifest)
record={'path':str(path),'sha256':sha(path),'bytes':path.stat().st_size,'verifiedEveryMember':True,'files':manifest}
write(checks/'publication.json',record)
evidence={k:v for k,v in report.items() if k not in ('curves','origins')}
evidence['curves']=[{k:v for k,v in r.items() if k!='familyNLL'} for r in report['curves']]
evidence['originsCount']=len(report['origins'])
evidence['originHash']=manifest['results/l40s-demand-weight-pilot-v1/origins.jsonl']['sha256']
evidence['trainAudit']=read(files[str(checks/'train-audit.json')])
evidence['defaultCompatibility']=read(checks/'default-check.json')
evidence['prototypeTests']=(checks/'tests.log').read_text().strip()
evidence['decision']=read(checks/'decision.json')
evidence['artifact']=record
write('docs/evidence/research-demand-weight-results.json',evidence)
print({k:v for k,v in record.items() if k!='files'},flush=True)
