"""Inspect Train-only source weighting and paired out-of-fold losses after expansion."""
from collections import Counter
from pathlib import Path
import numpy as np
from newsvendor.io import digest,lines,read,write

old_root=Path('results/l40s-demand-selection-v2')
new_root=Path('/dev/shm/newsvendor-demand-linked-v1')
output=Path('/dev/shm/newsvendor-demand-weight-audit-v1')
assert not output.exists()
output.mkdir()
old_rows=lines('data/processed/core-retail-train-v1/inputs.jsonl')
new_rows=lines('data/processed/core-retail-linked-v1/inputs.jsonl')
old_train=[r for r in old_rows if r['component']=='retail' and r['split']=='train']
new_train=[r for r in new_rows if r['component']=='retail' and r['split']=='train']
old_ids={r['id'] for r in old_train}
added_families={r['family'] for r in new_train if r['id'] not in old_ids}
counts=Counter(r['family'] for r in new_train)
result={'scope':'Train-only identity and existing source-held loss diagnosis; no Dev/Test scores, fitting or seed selection','devUsed':False,'testUsed':False,'scriptHash':digest(Path(__file__).read_bytes()),'sourceHistories':dict(sorted(Counter(counts.values()).items())),'families':len(counts),'familiesWithAdditions':len(added_families),'addedFamilyWeight':{'old':sum(r['family'] in added_families for r in old_train)/len(old_train),'expanded':sum(r['family'] in added_families for r in new_train)/len(new_train),'equalSource':len(added_families)/len(counts)},'runs':{}}
for seed in (42,43,44):
    old=lines(old_root/str(seed)/'crossfit.jsonl');new=lines(new_root/str(seed)/'crossfit.jsonl')
    def key(r):return r['id'],r['cutoff'],r['horizon']
    oi={key(r):r for r in old};ni={key(r):r for r in new}
    assert len(oi)==len(old) and len(ni)==len(new) and oi.keys()<=ni.keys()
    for identity,row in oi.items():
        assert all(ni[identity][k]==v for k,v in row.items() if k!='familyNLL')
    per_source=Counter(r['family'] for r in new)
    run={'pairedOriginal':{},'expanded':{},'artifacts':{str(root/str(seed)/'crossfit.jsonl'):digest((root/str(seed)/'crossfit.jsonl').read_bytes()) for root in (old_root,new_root)}}
    for h in (1,7):
        for censored in (False,True):
            group=[r for r in old if r['horizon']==h and r['censored']==censored]
            a=np.array([r['familyNLL'] for r in group]);b=np.array([ni[key(r)]['familyNLL'] for r in group])
            run['pairedOriginal'][f'{h}/{censored}']={'rows':len(group),'sources':len({r['family'] for r in group}),'controlFamilyNLL':a.mean(0).tolist(),'candidateFamilyNLL':b.mean(0).tolist(),'difference':(b-a).mean(0).tolist(),'improvedForecastFraction':float((b.mean(1)<a.mean(1)).mean())}
    for cohort in ('all','original','added'):
        group=[r for r in new if cohort=='all' or (r['id'] in old_ids)==(cohort=='original')]
        for h in (1,7):
            selected=[r for r in group if r['horizon']==h]
            values=np.array([r['familyNLL'] for r in selected]);weights=np.array([1/per_source[r['family']] for r in selected])
            run['expanded'][f'{cohort}/{h}']={'rows':len(selected),'censoredFraction':float(np.mean([r['censored'] for r in selected])),'rowMean':values.mean(0).tolist(),'sourceMean':np.average(values,axis=0,weights=weights).tolist()}
    result['runs'][str(seed)]=run
write(output/'report.json',result)
print({k:v for k,v in result.items() if k!='runs'},flush=True)
for seed,run in result['runs'].items():
 print({'seed':seed,'pairedDifferences':{k:v['difference'] for k,v in run['pairedOriginal'].items()},'allRowSourceMeans':{k:v for k,v in run['expanded'].items() if k.startswith('all/')}},flush=True)
