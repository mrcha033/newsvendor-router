"""Compare the default training path to the committed source, including all learned weights."""
import copy
import importlib.util
import runpy
from pathlib import Path
import torch
from newsvendor import sequence
from newsvendor.io import digest,write
from newsvendor.structured_tool_eval import weights_hash

spec=importlib.util.spec_from_file_location('newsvendor.sequence_before_source_weight','/dev/shm/newsvendor-sequence-before-source-weights.py')
old=importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
torch.set_num_threads(1)
original,targets=runpy.run_path('tests/test_observations.py')['observation_cases']()
rows=[];labels={}
for i in range(7):
    r=copy.deepcopy(original[0]);r.update(id=f'compat-{i}',family=f'compat-{i}',split='dev' if i==6 else 'train')
    rows.append(r);labels[r['id']]=copy.deepcopy(targets[original[0]['id']])
samples=sequence.samples(rows,labels)
train=[r for r in samples if r['split']=='train'];dev=[r for r in samples if r['split']=='dev']
settings={'epochs':2,'selectorEpochs':2,'folds':2,'lr':.001,'batchSize':8,'dailyWeight':.3,'observation':'daily_allocation','allocationConcentration':1,'parameterValidationFraction':.25}
results={}
for name,module,config in (('committed',old,settings),('default',sequence,settings),('explicit',sequence,{**settings,'weighting':'forecast'})):
    torch.manual_seed(192)
    model=module.DemandEncoder(hidden=8)
    report,records=module.cross_fit(model,train,dev,config,42)
    results[name]={'weights':weights_hash(model.state_dict()),'raw':digest(records),'parameterLosses':report['parameterLosses'],'selectorLosses':report['selectorLosses'],'selectedEpoch':report['selectedEpoch'],'devSelectedNLL':report['devSelectedNLL']}
assert results['committed']==results['default']==results['explicit']
write('results/research-checks/demand-weights/default-check.json',{'scope':'Exact CPU default-path comparison with committed sequence.py on a small production training graph; no efficacy claim','committedSourceHash':digest(Path('/dev/shm/newsvendor-sequence-before-source-weights.py').read_bytes()),'currentSourceHash':digest(Path('src/newsvendor/sequence.py').read_bytes()),'scriptHash':digest(Path(__file__).read_bytes()),'settings':settings,'results':results,'allWeightsRawTargetsAndLossesIdentical':True})
print({'allWeightsRawTargetsAndLossesIdentical':True,'weights':results['committed']['weights']},flush=True)
