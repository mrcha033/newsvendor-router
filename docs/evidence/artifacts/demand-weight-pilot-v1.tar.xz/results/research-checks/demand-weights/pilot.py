"""Test equal-source fitting on an existing Train-only inner split before any new Dev run."""
import copy
import os
import tarfile
import time
from pathlib import Path

import numpy as np
import torch
from newsvendor import observations,sequence
from newsvendor.cli import provenance
from newsvendor.io import digest,jsonl,lines,read,write
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.train import seed

GPU='GPU-674d64b8-4bdf-7006-1791-5dc7f7245409'
assert os.environ.get('CUDA_VISIBLE_DEVICES')==GPU
assert torch.cuda.device_count()==1 and 'L40S' in torch.cuda.get_device_name(0)
seed(42)
root=Path('/dev/shm/newsvendor-demand-weight-pilot-v1')
assert not root.exists()
parent=Path('/dev/shm/newsvendor-demand-linked-v1/42/model.pt')
previous=torch.load(parent,map_location='cpu',weights_only=True)
selected=previous['report']['parameterSelection']
settings={**previous['config']['demand'],'weighting':'source'}
raw=lines('data/processed/core-retail-linked-v1/inputs.jsonl')
rows=[r for r in raw if r['component']=='retail' and r['split']=='train']
ids={r['id'] for r in rows}
labels={r['id']:r['target'] for r in lines('data/processed/core-retail-linked-v1/labels.jsonl') if r['id'] in ids}
training=sequence.samples(rows,labels,settings['minHistory'])
fit=[r for r in training if r['family'] in selected['fitFamilies']]
held=[r for r in training if r['family'] in selected['heldFamilies']]
assert len(fit)+len(held)==len(training)
assert not {r['family'] for r in fit}&{r['family'] for r in held}
assert [{k:r[k] for k in ('id','family','cutoff','horizon','historyHash')} for r in held]==selected['origins']
allocation=observations.fit_concentration(fit)
assert allocation==selected['allocationFit']
settings['allocationConcentration']=allocation['concentration']
model=sequence.DemandEncoder().to('cuda')
assert weights_hash(model.state_dict())==previous['initialHash']
weights=sequence.source_weights(held,settings['dailyWeight'])

def summarize(values):
    result={'sourceObjective':float((values.mean(-1)*weights).sum()/weights.sum()),'rowObjective':float(values.mean())}
    for h in (1,7):
        mask=torch.tensor([r['horizon']==h for r in held])
        result[f'h{h}']=float((values[mask].mean(-1)*weights[mask]).sum()/weights[mask].sum())
        for c in (False,True):
            mask=torch.tensor([r['horizon']==h and r['censored']==c for r in held])
            result[f'h{h}/c{c}']=float((values[mask].mean(-1)*weights[mask]).sum()/weights[mask].sum())
    return result

baseline=[{'epoch':c['epoch'],**summarize(torch.tensor(c['familyNLL']))} for c in selected['curves']]
control=min(baseline,key=lambda r:r['sourceObjective'])
root.mkdir()
report={'scope':'Train-only source-weighted gradient pilot on the unchanged full-fit inner partition; no new Dev/Test prediction or selection','devUsed':False,'testUsed':False,'holdoutUsed':False,'source':provenance(settings),'scriptHash':digest(Path(__file__).read_bytes()),'parentHash':digest(parent.read_bytes()),'initialHash':previous['initialHash'],'config':settings,'fitFamilies':selected['fitFamilies'],'heldFamilies':selected['heldFamilies'],'allocationFit':allocation,'origins':selected['origins'],'fittingForecasts':len(fit),'heldForecasts':len(held),'controlCurves':baseline,'controlSelectedBySameSourceObjective':control,'historicalRowSelectedEpoch':selected['selectedEpoch'],'selectionRule':'Proceed to registered three-seed Dev comparison only if the best of the same 20 epochs improves source-weighted held-Train mean NLL against the preserved unweighted training selected by that identical source-weighted criterion. Preserve every horizon/censor stratum; no family or example is removed or loss clipped.','curves':[]}
write(root/'registered.json',report)
with tarfile.open(root/'source.tar.gz','w:gz') as archive:
    for p in sorted(Path('src').rglob('*.py')): archive.add(p,arcname=str(p))
    archive.add(Path(__file__),arcname=str(Path(__file__).relative_to(Path.cwd())))
jsonl(root/'origins.jsonl',[{k:v for k,v in r.items() if k!='sequence'} for r in training])
started=time.perf_counter()
best=float('inf')

def observe(current,epoch):
    global best
    values=sequence.measure(current,held,settings['batchSize'],settings)
    assert torch.isfinite(values).all()
    summary=summarize(values)
    report['curves'].append({'epoch':epoch,**summary,'familyNLL':values.tolist()})
    if summary['sourceObjective']<best:
        best=summary['sourceObjective']
        torch.save({'weights':copy.deepcopy(current.state_dict()),'epoch':epoch,'sourceObjective':best,'config':settings},root/'model.pt')
    print({'epoch':epoch,'seconds':time.perf_counter()-started,**summary},flush=True)

report['trainingLosses']=sequence.fit_params(model,fit,settings,45,observe)
selected_new=min(report['curves'],key=lambda r:r['sourceObjective'])
report['selected']={k:v for k,v in selected_new.items() if k!='familyNLL'}
report['sourceObjectiveDifference']=selected_new['sourceObjective']-control['sourceObjective']
report['proceedToDevStudy']=report['sourceObjectiveDifference']<0
report['seconds']=time.perf_counter()-started
report['peakGpuBytes']=torch.cuda.max_memory_allocated()
report['selectedCheckpointHash']=digest((root/'model.pt').read_bytes())
write(root/'report.json',report)
print({k:report[k] for k in ('selected','controlSelectedBySameSourceObjective','sourceObjectiveDifference','proceedToDevStudy','seconds')},flush=True)
