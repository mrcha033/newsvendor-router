"""Selected GRU on original and newly added Train sources; no Dev/Test diagnosis."""
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch

from newsvendor import demand, sequence
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_tool_eval import weights_hash

torch.set_num_threads(4)
root = Path('results/research-checks/demand-train-audit')
require(not root.exists(), 'Preserve prior audit')
root.mkdir(parents=True)
checkpoint = Path('results/l40s-research-replay-v1/base/42/model.pt')
dataset = Path('data/processed/core-retail-train-v1')
original = [r for r in lines('data/processed/complementary/inputs.jsonl') if r['component'] == 'retail' and r['split'] == 'train']
seen = {r['family'] for r in original}
rows = [r for r in lines(dataset/'inputs.jsonl') if r['component'] == 'retail' and r['split'] == 'train']
ids = {r['id'] for r in rows}
labels = {r['id']: r['target'] for r in lines(dataset/'labels.jsonl') if r['id'] in ids}
samples = sequence.samples(rows, labels)
history = {(r['id'], day['date']): r['input']['observations'][:i+1] for r in rows for i,day in enumerate(r['input']['observations']) if i >= 27}
payload = torch.load(checkpoint, map_location='cpu', weights_only=True, mmap=True)
weights = {k.removeprefix('demand.'): v for k,v in payload['weights'].items() if k.startswith('demand.')}
model = sequence.DemandEncoder().to('cuda').eval()
model.load_state_dict(weights, strict=True)
require(str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == '674d64b8-4bdf-7006-1791-5dc7f7245409', 'Wrong GPU')
report = {
    'scope': 'Train diagnosis only. New Train families were not used to fit the selected small-cohort GRU; they are development evidence, not a fresh Test.',
    'devUsed': False, 'testUsed': False,
    'checkpoint': str(checkpoint), 'checkpointHash': digest(checkpoint.read_bytes()),
    'demandWeightsHash': weights_hash(weights), 'source': provenance(payload['config']),
    'scriptHash': digest(Path(__file__).read_bytes()),
    'dataManifestHash': digest(read(dataset/'manifest.json')),
    'families': {'original': len(seen), 'newTrain': len({r['family'] for r in rows} - seen)},
    'limitations': ['Rolling origins overlap; count source families separately.', 'Complete-period conditional coverage is selection-biased when stockouts depend on demand. It is not latent demand calibration.', 'Censored observations only identify lower bounds. Future stockout status is used for scoring/grouping, not model inputs.'],
}
write(root/'registered.json', report)
started = time.perf_counter()
records = []
with torch.inference_mode():
    for offset in range(0, len(samples), 256):
        batch = samples[offset:offset+256]
        output = model([r['sequence'] for r in batch], [r['horizon'] for r in batch])
        losses = sequence.losses(output, batch).cpu()
        scores = output['scores'].cpu()
        parameters = {f: output['raw'][f].cpu() for f in demand.FAMILIES}
        for i,row in enumerate(batch):
            past = history[row['id'], row['cutoff']]
            observed = row['y'] * row['scale']
            details = {}
            for j,family in enumerate(demand.FAMILIES):
                raw = parameters[family][i]
                first,second = demand.parameters(family, raw)
                distribution = {'family':family, 'normalizationScale':row['scale'], 'parameters':{'zeroProbability':min(max(float(raw[0].sigmoid()),1e-8),1-1e-8), demand.PARAMETERS[family][0]:float(first),demand.PARAMETERS[family][1]:float(second)}}
                F = np.asarray(demand.pmf(distribution)); values,probabilities = F.T
                quantiles = values[np.minimum(np.searchsorted(probabilities.cumsum(),[0.1,0.5,0.9]),len(values)-1)]
                details[family] = {'distribution':distribution,'interval':[float(quantiles[0]),float(quantiles[2])],'median':float(quantiles[1]),'mean':float(values@probabilities),'normalizedNLL':float(losses[i,j]),'score':float(scores[i,j]),'completeDirection':None if row['censored'] else 'below' if observed<quantiles[0] else 'above' if observed>quantiles[2] else 'inside','knownAboveUpper':bool(observed>quantiles[2])}
            record = {k:row[k] for k in ['id','family','split','horizon','cutoff','dates','historyHash','scale','y','censored','dailySales','dailyCensored']}
            mean = row['scale']/row['horizon']
            record.update(cohort='original' if row['family'] in seen else 'newTrain', observed=observed, selected=demand.FAMILIES[int(scores[i].argmin())], families=details, historyStockoutFraction=float(np.mean([r['stockoutHours']>0 for r in past])), recentStockoutFraction=float(np.mean([r['stockoutHours']>0 for r in past[-7:]])), recentSalesRatio=float(np.mean([r['sales'] for r in past[-7:]])/mean), historyZeroFraction=float(np.mean([r['sales']==0 for r in past])))
            records.append(record)
        if (offset//256)%10 == 0:
            state={'processed':min(offset+256,len(samples)),'total':len(samples),'seconds':time.perf_counter()-started}
            write(root/'progress.json',state);print(state,flush=True)
jsonl(root/'raw.jsonl',records)
groups=defaultdict(list)
for r in records:groups[r['cohort'],r['horizon']].append(r)
report['groups']={}
for (cohort,horizon),group in groups.items():
    complete=[r for r in group if not r['censored']]
    by_model={}
    for choice in ['selected',*demand.FAMILIES]:
        def chosen(r):return r['families'][r['selected'] if choice=='selected' else choice]
        by_model[choice]={'completeDirections':dict(Counter(chosen(r)['completeDirection'] for r in complete)),'completeMedianBias':float(np.mean([chosen(r)['median']-r['observed'] for r in complete])),'completeMeanBias':float(np.mean([chosen(r)['mean']-r['observed'] for r in complete])),'knownAboveUpperAll':sum(chosen(r)['knownAboveUpper'] for r in group),'allNormalizedNLL':float(np.mean([chosen(r)['normalizedNLL'] for r in group])),'completeNormalizedNLL':float(np.mean([chosen(r)['normalizedNLL'] for r in complete]))}
    report['groups'][f'{cohort}:{horizon}']={'forecasts':len(group),'families':len({r['family'] for r in group}),'complete':len(complete),'completeFamilies':len({r['family'] for r in complete}),'completeZeros':sum(r['observed']==0 for r in complete),'selectedFamilies':dict(Counter(r['selected'] for r in group)),'models':by_model}
report['seconds']=time.perf_counter()-started;report['rawHash']=digest((root/'raw.jsonl').read_bytes());write(root/'report.json',report)
print(report['groups'],flush=True)
