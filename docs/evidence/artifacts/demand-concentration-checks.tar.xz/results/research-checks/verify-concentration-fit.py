"""Reproduce Train-only allocation estimates from the preserved observation records."""
import math
from collections import defaultdict
from pathlib import Path

import numpy as np

from newsvendor.io import digest, lines, read, require, write
from newsvendor.observations import fit_concentration

root = Path('results/research-checks/demand-train-audit')
raw = root / 'raw.jsonl'
report = read(root / 'report.json')
require(digest(raw.read_bytes()) == report['rawHash'], 'Changed Train observations')
rows = lines(raw)
require(all(r['split'] == 'train' for r in rows), 'Train only')
prior = read(root / 'allocation-fit.json')
families = sorted({r['family'] for r in rows}, key=lambda f: digest([42, f]))
folds = {f: i % 3 for i, f in enumerate(families)}
result = {'testUsed': False, 'devUsed': False, 'rawHash': report['rawHash'], 'scriptHash': digest(Path(__file__).read_bytes()), 'fits': {}}
for fold in (None, 0, 1, 2):
    fit = rows if fold is None else [r for r in rows if folds[r['family']] != fold]
    fitted = fit_concentration(fit)
    previous = prior[str(fold)]
    require(fitted['concentration'] == previous['concentration'], 'Different fitted concentration')
    require(fitted['periods'] == previous['fitPeriods'] and len(fitted['families']) == previous['fitFamilies'], 'Different sources')
    for key, value in fitted['scores'].items():
        require(abs(value - previous['fitScores'][key]) < 1e-12, 'Different allocation score')
    gain = None
    if fold is not None:
        groups = defaultdict(list)
        a = fitted['concentration']
        for row in rows:
            if folds[row['family']] != fold or row['horizon'] == 1 or row['censored']:
                continue
            v = np.asarray(row['dailySales'])
            v = v[v > 0]
            if len(v) > 1:
                k = len(v)
                groups[row['family']].append(math.lgamma(k*a)-k*math.lgamma(a)+(a-1)*np.log(v/v.sum()).sum()-math.lgamma(k))
        require(not set(groups) & set(fitted['families']), 'Source overlap')
        gain = float(np.mean([np.mean(v) for v in groups.values()]))
        require(abs(gain - previous['heldGain']) < 1e-12, 'Different held-source score')
    result['fits'][str(fold)] = {'fit': fitted, 'heldGain': gain}
result['allPriorEstimatesReproduced'] = True
write(root / 'fit-verification.json', result)
print({k: {'concentration': v['fit']['concentration'], 'heldGain': v['heldGain']} for k, v in result['fits'].items()})
