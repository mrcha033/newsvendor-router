"""Publish exact Train diagnosis and numerical checks with verified file hashes."""
import shutil
import tarfile
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import digest, read, require, write

base=Path('results/research-checks')
audit=base/'demand-train-audit'
require(read(audit/'fit-verification.json')['allPriorEstimatesReproduced'], 'Fit estimates not verified')
paths=sorted(audit.glob('*.json'))+[audit/'raw.jsonl']
paths += [base/name for name in ['audit-demand-train.py', 'verify-concentration-fit.py', 'concentration-quadrature.json', 'concentration-sources.json', 'publish-concentration-checks.py']]
paths += [base/'concentration-core-check/manifest.json', Path('results/smoke.json'), Path('scripts/check_observations.py'), Path('tests/test_observations.py')]
manifest={str(p):{'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size} for p in paths}
archive=Path('docs/evidence/artifacts/demand-concentration-checks.tar.xz')
require(not archive.exists(), 'Preserve published checks')
with tarfile.open(archive,'w:xz',preset=3) as tar:
    for path in paths: tar.add(path,arcname=str(path))
with tarfile.open(archive,'r:xz') as tar:
    require(set(tar.getnames())==set(manifest), 'Archive paths differ')
    for name,info in manifest.items(): require(digest(tar.extractfile(name).read())==info['sha256'], 'Archive hash mismatch')
source=Path('docs/evidence/artifacts/demand-concentration-v1-source.tar.gz')
shutil.copyfile('results/l40s-demand-concentration-v1/source.tar.gz',source)
config=read('configs/l40s-demand-concentration-v1.json')
report={
 'scope':'Train diagnosis, numerical likelihood/gradient checks and source isolation; not real organizational effectiveness or forecast improvement evidence',
 'testUsed':False,'devUsedForDiagnosis':False,'source':provenance(config),
 'tests':{'passed':246,'seconds':27.31,'command':'.venv/bin/pytest -q'},
 'ruff':'Source, tests and touched runner scripts: lint and format passed',
 'sourceChecks':read(base/'concentration-sources.json'),
 'numericalSmoke':read('results/smoke.json'),
 'researchInputCheck':read(base/'concentration-core-check/manifest.json'),
 'numerical':read(base/'concentration-quadrature.json'),
 'trainDiagnosis':read(audit/'report.json'),
 'allocationFit':read(audit/'allocation-fit.json'),
 'fitVerified':True,
 'publishedRaw':{'path':str(archive),'sha256':digest(archive.read_bytes()),'bytes':archive.stat().st_size,'files':manifest,'verified':True,'scope':'All 35,772 Train forecast parameters/quantiles and observations, source identities, fitting verification, numerical reports, source checks and audit scripts. Full original model and expanded training capture are not bundled.'},
 'publishedSource':{'path':str(source),'sha256':digest(source.read_bytes()),'bytes':source.stat().st_size},
}
write('docs/evidence/research-concentration-checks.json',report)
print({'files':len(paths),'archiveBytes':archive.stat().st_size,'sourceHash':report['source']['sourceHash']},flush=True)
