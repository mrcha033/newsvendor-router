"""Preserve the public-assets restoration, access guard and actual inference check."""

from pathlib import Path

from publish import publish

from newsvendor.io import read, write

root = Path("results/research-checks/recovery-stability")
names = (
    "restore.py",
    "restoration.json",
    "restoration.log",
    "reproduced.json",
    "guard-check.json",
    "reproduction-guard.py",
    "reproduction.log",
    "publish_reproduction.py",
    "probe_guard.py",
    "guard-preparation.json",
    "final_checks.py",
    "final-checks.json",
    "final-checks.log",
    "generated-all-heads.json",
)
files = {str(root / name): root / name for name in names}
script = Path("docs/evidence/scripts/reproduce-recovery-residual.py")
files[str(script)] = script
artifact = publish(Path("docs/evidence/artifacts/recovery-stability-reproduction-v1.tar.xz"), files)
result = read(root / "reproduced.json")
assert result["verifiedRollouts"] == 720
result.update(
    artifact=artifact,
    networkAndWorkingDataForbidden=True,
    emptyHubCache=True,
    restoredMembers=read(root / "restoration.json")["verifiedMembers"],
    scopeNote="Actual model inference and sequential rollouts from public bundle/head/input assets on a fixed-stride Dev subset; reproduction only, no new selection or effectiveness evaluation.",
)
evidence = read("docs/evidence/research-recovery-stability-results.json")
evidence["publishedReproduction"] = result
evidence["finalChecks"] = read(root / "final-checks.json")
evidence["generatedAllHeads"] = read(root / "generated-all-heads.json")
write("docs/evidence/research-recovery-stability-results.json", evidence)
write(root / "reproduction-publication.json", artifact)
