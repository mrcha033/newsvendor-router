"""Check changed publication sources, document links and archive consistency."""

import json
import re
import subprocess
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import read, write

root = Path("results/research-checks/recovery-stability")
workflow = Path(".github/workflows/ci.yml").read_text()
commands = []
for block in re.findall(r"      - run: >-\n((?:          .+\n)+)", workflow):
    command = block.split()
    assert command[:3] == ["uv", "run", "ruff"]
    commands.append([".venv/bin/ruff", *command[3:]])
checks = {}
for command in commands:
    outcome = subprocess.run(command, text=True, capture_output=True, check=True)
    checks[" ".join(command)] = outcome.stdout.strip()
subprocess.run(["git", "diff", "--check"], check=True)
evidence = read("docs/evidence/research-recovery-stability-results.json")
assert provenance({})["sourceHash"] == evidence["reports"]["residual-dev"]["source"]["sourceHash"]
assert "330 passed" in (root / "tests.log").read_text()
assert not evidence["weightsAdopted"] and not evidence["testUsed"]
assert evidence["trainOutcomeAudit"]["verifiedRollouts"] == 15470
assert evidence["devOutcomeAudit"]["verifiedRollouts"] == 32616
links = []
for name in ("README.md", "docs/research-scope.md", "docs/recovery-stability.md"):
    p = Path(name)
    for target in re.findall(r"\]\(([^)]+)\)", p.read_text()):
        if "://" in target or target.startswith("#"):
            continue
        target = target.split("#")[0]
        assert (p.parent / target).exists(), (name, target)
        links.append([name, target])
result = {
    "lint": checks,
    "sourceHash": provenance({})["sourceHash"],
    "tests": "330 passed in 36.74s",
    "sourceAudits": 5,
    "numericalSmoke": 30,
    "diffCheck": "passed",
    "localDocumentLinks": len(links),
    "testInferencePerformed": False,
}
write(root / "final-checks.json", result)
print(json.dumps(result), flush=True)
