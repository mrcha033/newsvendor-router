"""Restore verified public records into an empty directory for isolated inference."""

import hashlib
import shutil
import tarfile
from pathlib import Path

from newsvendor.io import read, write

root = Path("/dev/shm/newsvendor-recovery-sampling-restored-v1")
assert not root.exists()
root.mkdir()
evidence = read("docs/evidence/research-recovery-sampling-results.json")
prefixes = ("results/l40s-recovery-balanced-refit-v1/", "results/l40s-recovery-balanced-dev-v1/")
restored = []
for artifact in (evidence["artifact"], evidence["rawArtifact"]):
    with Path(artifact["path"]).open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == artifact["sha256"]
    with tarfile.open(artifact["path"], "r:xz") as archive:
        for member in archive:
            if not member.name.startswith(prefixes):
                continue
            assert member.isfile() and ".." not in Path(member.name).parts
            destination = root / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with archive.extractfile(member) as source, destination.open("wb") as output:
                shutil.copyfileobj(source, output)
            with destination.open("rb") as stream:
                assert (
                    hashlib.file_digest(stream, "sha256").hexdigest()
                    == artifact["files"][member.name]["sha256"]
                )
            restored.append(member.name)
(root / "guard").mkdir()
shutil.copy2(
    "/dev/shm/newsvendor-recovery-restored-v1/guard/sitecustomize.py",
    root / "guard/sitecustomize.py",
)
(root / "empty-hub-cache").mkdir()
write(
    "results/research-checks/recovery-balance/restoration.json",
    {
        "source": "Public archives only",
        "root": str(root),
        "verifiedMembers": len(restored),
        "rawJsonByteHashesVerified": True,
        "emptyHubCache": True,
        "guard": str(root / "guard/sitecustomize.py"),
    },
)
print({"restored": len(restored), "root": str(root)}, flush=True)
