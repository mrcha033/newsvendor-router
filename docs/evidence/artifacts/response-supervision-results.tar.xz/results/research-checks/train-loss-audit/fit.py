"""Fixed Train-return fit diagnostic; cached frozen L40S representations, CPU heads."""
from collections import defaultdict
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as fn

from newsvendor.heads import Head
from newsvendor.io import digest, jsonl, lines, require, write
from newsvendor.structured_value import constrain, state_features

torch.set_num_threads(4)
root = Path('results/research-checks/train-loss-audit')
directory = Path('results/l40s-research-responses-v1/sampled/42')
target_path = directory / 'value-targets-0.jsonl'
original_path = Path('results/l40s-research-precision-v1/control/42/value-targets-0.jsonl')
feature_path = Path('results/research-checks/action-precision/train-features.pt')
original = lines(original_path)
cached = torch.load(feature_path, weights_only=True)
gpu = lines('results/research-checks/action-precision/fp32/inherited.jsonl')
by_id = {}
for row, features, prediction in zip(original, cached, gpu, strict=True):
    require(row['split'] == features['split'] == 'train', 'Train only')
    require(row['id'] == features['id'] == prediction['id'], 'Cached row mismatch')
    if not row['input']['history']:
        by_id[row['id']] = (row, features, prediction)
targets = [r for r in lines(target_path) if not r['input']['history']]
require(len(targets) == len(by_id) == 514, 'Initial Train cohort differs')
features = []
for row in targets:
    old, cached, prediction = by_id[row['id']]
    require(digest(row['input']) == digest(old['input']) and digest(row['state']) == digest(old['state']), 'Own input/state changed')
    require(row['actions'] == old['actions'], 'Actions changed')
    x = torch.cat([cached['features'][:, :256].float(), torch.tensor(state_features(row['input'], row['state'], row['actions']))], -1)
    features.append((row, x, cached['costs'], prediction['action']['id']))
initial_path = root / 'initial-value-head.pt'
if not initial_path.exists():
    base_path = directory / 'policy-base.pt'
    weights = torch.load(base_path, map_location='cpu', weights_only=True)['weights']
    weights = {k.removeprefix('heads.value.'): v for k, v in weights.items() if k.startswith('heads.value.')}
    torch.save({'weights': weights, 'baseHash': digest(base_path.read_bytes())}, initial_path)
paths = [initial_path, *sorted(directory.glob('policy-candidate-0-*.pt'))]
report = {'scope': 'Fit to the first iteration mean measured Train returns. Each target continues with the inherited policy, so these are not full rollouts of a newly trained policy and not new effectiveness results. Head calculations use CPU with frozen representations measured on L40S; initial CPU decisions must match recorded GPU decisions.', 'testUsed': False, 'devUsed': False, 'inputHashes': {str(p): digest(p.read_bytes()) for p in [target_path, original_path, feature_path]}, 'heads': {}}
raw = []
for path in paths:
    weights = torch.load(path, map_location='cpu', weights_only=True)['weights']
    head = Head(350, 128, 2).eval()
    head.load_state_dict(weights, strict=True)
    groups = defaultdict(list)
    with torch.inference_mode():
        for row, x, costs, gpu_action in features:
            predicted = constrain(fn.softplus(head(x)), costs).sum(-1)
            chosen = int(predicted.argmin())
            if path == initial_path:
                require(row['actions'][chosen] == gpu_action, 'CPU inherited action differs from recorded GPU action')
            actual = np.array(row['values']).sum(-1)
            group = 'retail' if 'forecast' in row['input']['task'] else 'generated'
            measurement = {'id': row['id'], 'family': row['family'], 'head': path.name, 'benchmark': group, 'action': row['actions'][chosen], 'meanForcedReturn': float(actual[chosen] * row['scale']), 'targetRegret': float((actual[chosen] - actual.min()) * row['scale']), 'absoluteNormalizedError': float(np.abs(predicted.numpy() - actual).mean())}
            raw.append(measurement)
            groups[group].append(measurement)
    report['heads'][path.name] = {'hash': digest(path.read_bytes()), 'benchmarks': {k: {'episodes': len(v), **{metric: float(np.mean([r[metric] for r in v])) for metric in ['meanForcedReturn', 'targetRegret', 'absoluteNormalizedError']}} for k, v in groups.items()}}
jsonl(root / 'train-fit-raw.jsonl', raw)
report['rawHash'] = digest((root / 'train-fit-raw.jsonl').read_bytes())
report['scriptHash'] = digest(Path(__file__).read_bytes())
write(root / 'train-fit.json', report)
print(report['heads'], flush=True)
