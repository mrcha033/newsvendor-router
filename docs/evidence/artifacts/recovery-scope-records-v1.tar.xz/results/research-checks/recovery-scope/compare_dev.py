"""Explain actual paired Dev changes without running inference or selecting a candidate."""

import gzip
import json
import math
import sys
from contextlib import ExitStack
from pathlib import Path

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import conditions

from newsvendor.io import read, require, write
from newsvendor.structured_recovery import failed_fields

root = Path("/dev/shm/newsvendor-recovery-scoped-dev-v1")
report = read(root / "report.json")
names = ["parent", "failure_rule", "scoped-42", "scoped-43", "scoped-44"]
fields = ["q", "result", "terminalLoss", "requestCost", "total", "falseHandoff"]
result = {
    "scope": "Read-only decomposition of already measured original Dev; no inference, model selection, Test or frozen holdout.",
    "testUsed": False,
    "benchmarks": {},
}
for benchmark in ("generated", "retail"):
    counts = {
        name: {
            "parentChangedActions": 0,
            "ruleChangedActions": 0,
            "parentChangedOutcomes": 0,
            "ruleChangedOutcomes": 0,
            "initialActionChanges": 0,
            "divergences": [],
        }
        for name in names[2:]
    }
    totals = {
        name: {str(rate): {"terminal": [], "requests": [], "total": []} for rate in (0, 0.1, 0.2)}
        for name in names
    }
    rows = 0
    with ExitStack() as stack:
        streams = [
            stack.enter_context(gzip.open(root / f"{name}-{benchmark}.jsonl.gz", "rt"))
            for name in names
        ]
        for values in zip(*streams, strict=True):
            records = dict(zip(names, map(json.loads, values), strict=True))
            parent, rule = records["parent"], records["failure_rule"]
            require(
                all(
                    r["id"] == parent["id"]
                    and r.get("missingResponses") == parent.get("missingResponses")
                    for r in records.values()
                ),
                "Paired order changed",
            )
            parent_actions = [e["action"] for e in parent["events"]]
            rule_actions = [e["action"] for e in rule["events"]]
            for name in names[2:]:
                row = records[name]
                actions = [e["action"] for e in row["events"]]
                item = counts[name]
                item["parentChangedActions"] += actions != parent_actions
                item["ruleChangedActions"] += actions != rule_actions
                item["parentChangedOutcomes"] += any(row[k] != parent[k] for k in fields)
                item["ruleChangedOutcomes"] += any(row[k] != rule[k] for k in fields)
                item["initialActionChanges"] += actions[0] != parent_actions[0]
                if actions != parent_actions:
                    index = next(
                        i
                        for i, (a, b) in enumerate(zip(parent_actions, actions, strict=False))
                        if a != b
                    )
                    before, after = parent["events"][index], row["events"][index]
                    require(
                        before["input"] == after["input"],
                        "Input differs before first changed action",
                    )
                    require(before["stateHash"] == after["stateHash"], "Constructed state differs")
                    failed = failed_fields(after["input"], after["state"])
                    require(failed, "Changed policy outside observed recovery")
                    item["divergences"].append(
                        {
                            "id": row["id"],
                            "missingResponses": row.get("missingResponses", []),
                            "step": index,
                            "failedFields": list(failed),
                            "parentAction": before["action"],
                            "candidateAction": after["action"],
                            "requestCostChange": row["requestCost"] - parent["requestCost"],
                            "terminalLossChange": None
                            if row["terminalLoss"] is None
                            else row["terminalLoss"] - parent["terminalLoss"],
                            "totalChange": None
                            if row["total"] is None
                            else row["total"] - parent["total"],
                        }
                    )
            if benchmark == "retail" and parent["outcomeComplete"]:
                for name, row in records.items():
                    for rate in (0, 0.1, 0.2):
                        probability = conditions(rate)[tuple(row["missingResponses"])]
                        for output, key in [
                            ("terminal", "terminalLoss"),
                            ("requests", "requestCost"),
                            ("total", "total"),
                        ]:
                            totals[name][str(rate)][output].append(probability * row[key])
            rows += 1
    summary = {"rawConditions": rows, "comparisons": counts}
    if benchmark == "retail":
        complete_cases = len(totals["parent"]["0"]["total"]) // 16
        require(complete_cases == 35, "Exact loss denominator changed")
        summary["completeCases"] = complete_cases
        summary["completePeriodMeans"] = {
            name: {
                rate: {k: math.fsum(v) / complete_cases for k, v in fields.items()}
                for rate, fields in groups.items()
            }
            for name, groups in totals.items()
        }
        for name in names:
            for rate, metrics in summary["completePeriodMeans"][name].items():
                require(
                    math.isclose(
                        metrics["total"],
                        report["results"][name]["retail"][rate]["totalOnCompletePeriods"]["mean"],
                        abs_tol=1e-9,
                    ),
                    "Mean differs",
                )
    result["benchmarks"][benchmark] = summary
write("results/research-checks/recovery-scope/dev-comparison.json", result)
print(
    {
        benchmark: {
            name: {k: v for k, v in item.items() if k != "divergences"}
            for name, item in data["comparisons"].items()
        }
        for benchmark, data in result["benchmarks"].items()
    },
    flush=True,
)
