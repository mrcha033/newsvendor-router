"""Audit the appended observation flag and normal-state invariance of saved heads."""

import sys
from collections import Counter
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from study_recovery_scope import make_head

from newsvendor.io import lines, read, require, write
from newsvendor.structured_recovery import failed_fields
from newsvendor.structured_value import state_features

torch.set_num_threads(2)
root = Path("/dev/shm/newsvendor-recovery-scoped-v1")
report = read(root / "report.json")
rows = lines(Path(report["plan"]["encoded"]) / "targets.jsonl")
payload = torch.load(
    Path(report["plan"]["numeric"]) / "features.pt", weights_only=True, map_location="cpu"
)
activation = read(root / "activation.json")
counts = Counter()
normal = []
for row, stored, (x, _target, _costs) in zip(rows, activation, payload["features"], strict=True):
    require(stored["inputHash"] == row["inputHash"], "Flag and observation are misaligned")
    require(
        stored["failedFields"] == list(failed_fields(row["input"], row["state"])), "Flag differs"
    )
    actual = torch.tensor(state_features(row["input"], row["state"], row["actions"]))
    require(torch.equal(actual, x[:, 256:]), "Numeric features changed")
    counts[row["benchmark"], bool(stored["failedFields"])] += 1
    if not stored["failedFields"]:
        normal.append(torch.cat([x, x.new_zeros((len(x), 1))], -1))
features = torch.cat(normal)
verified = 0
with torch.inference_mode():
    for seed in (42, 43, 44):
        for stage in ("inner", "refit"):
            saved = torch.load(root / f"{stage}-{seed}.pt", weights_only=True, map_location="cpu")
            head = make_head(payload["initial"], seed).eval()
            for name in ("weights", "finalWeights"):
                head.load_state_dict(saved[name])
                require(
                    torch.equal(head(features), head.base(features[:, :-1])),
                    "Normal scores changed",
                )
                verified += 1
result = {
    "scope": "Train observations only; no new inference over Test or Dev",
    "counts": [{"benchmark": k[0], "recovery": k[1], "states": n} for k, n in counts.items()],
    "allNumericFeaturesMatch": True,
    "allFlagsMatchObservedLatestFailures": True,
    "normalStates": len(normal),
    "normalActionRows": len(features),
    "verifiedSelectedAndFinalHeads": verified,
    "normalScoresBitwisePreserved": True,
    "testUsed": False,
}
write("results/research-checks/recovery-scope/feature-audit.json", result)
print(result, flush=True)
