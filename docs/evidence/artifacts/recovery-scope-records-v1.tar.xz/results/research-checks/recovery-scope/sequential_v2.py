"""Compare recovery-scoped policies and observable failure baselines on Train."""

import copy
import gzip
import importlib.util
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import CachedRouter, file_hash
from study_recovery_scope import make_head

from newsvendor import structured_train
from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_metrics import generated_metrics
from newsvendor.structured_recovery import failed_fields
from newsvendor.structured_rollout import behavior, rollout
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_value import constrain

spec = importlib.util.spec_from_file_location(
    "balanced_sequential", "results/research-checks/recovery-balance/sequential.py"
)
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)


class FailureRouter(CachedRouter):
    def __init__(self, *args, fallback="checklist", **kwargs):
        super().__init__(*args, **kwargs)
        self.fallback = fallback

    def choose(self, value, state):
        allowed = self.allowed(value, state)
        failed = failed_fields(value, state)
        blocked = any(("demand" if slot == "F" else slot) not in allowed for slot in failed)
        if (
            value["task"]["decision"] == "expected_loss"
            and blocked
            and not {"handoff", "retrieve"}.intersection(allowed)
        ):
            action = "hold"
        elif self.fallback == "parent":
            return super().choose(value, state)
        else:
            action = behavior(value, state, self)
        self.last_decision = {
            "action": action,
            "policyMode": "observed-failure-rule",
            "failedFields": list(failed),
            "fallback": self.fallback,
        }
        return action


def retail_metrics(rows):
    require(all(r["outcomeComplete"] for r in rows), "Complete Train periods required")
    return {
        "episodes": len(rows),
        **{
            k: float(np.mean([r[k] for r in rows]))
            for k in (
                "total",
                "terminalLoss",
                "requestCost",
                "interactions",
                "falseHandoff",
                "necessaryRequests",
                "unnecessaryRequests",
                "recoveredAfterRequest",
                "unresolvedAfterRequest",
            )
        },
        "handoffRate": float(np.mean([r["result"] == "handoff" for r in rows])),
        "missingAtStop": float(np.mean([len(r["unresolvedAtStop"]) for r in rows])),
        "parameters": {
            k: float(np.mean([r["parameters"][k] for r in rows]))
            for k in ("parameterAccuracy", "stateAccuracy", "typeAccuracy")
        },
        "evidenceAccuracy": sum(r["parameters"]["evidenceCorrect"] for r in rows)
        / sum(r["parameters"]["evidenceCount"] for r in rows),
    }


def compare(current, reference):
    a, b = current["generated"], reference["generated"]
    result = {
        "generatedTotal": a["meanTotal"] <= b["meanTotal"] + 1e-9,
        "generatedFalseHandoffs": a["falseHandoffs"] <= b["falseHandoffs"],
        "generatedResolvedRequests": a["resolvedFieldRequests"] <= b["resolvedFieldRequests"],
    }
    for rate in ("0", "0.1"):
        a, b = current["retail"][rate], reference["retail"][rate]
        result["retailTotal-" + rate] = a["total"] <= b["total"] + 1e-9
        for k in ("falseHandoff", "unnecessaryRequests"):
            result[k + "-" + rate] = a[k] <= b[k] + 1e-12
    a, b = current["retail"]["0"], reference["retail"]["0"]
    for k in ("necessaryRequests", "recoveredAfterRequest", "handoffRate"):
        result[k + "-no-dropout"] = a[k] >= b[k] - 1e-12
    result["missingAtStop-no-dropout"] = a["missingAtStop"] <= b["missingAtStop"] + 1e-12
    for key in ("parameterAccuracy", "stateAccuracy", "typeAccuracy"):
        result["generated-" + key] = (
            current["generated"]["finalParameters"][key]
            >= reference["generated"]["finalParameters"][key] - 1e-12
        )
        for rate in ("0", "0.1"):
            result["retail-" + rate + "-" + key] = (
                current["retail"][rate]["parameters"][key]
                >= reference["retail"][rate]["parameters"][key] - 1e-12
            )
    result["generated-evidence"] = (
        current["generated"]["finalEvidenceAccuracy"]
        >= reference["generated"]["finalEvidenceAccuracy"] - 1e-12
    )
    for rate in ("0", "0.1"):
        result["retail-" + rate + "-evidence"] = (
            current["retail"][rate]["evidenceAccuracy"]
            >= reference["retail"][rate]["evidenceAccuracy"] - 1e-12
        )
    return result


def main():
    plan = read("configs/research-recovery-scoped-sequential-v2.json")
    require(file_hash(__file__) == plan["scriptHash"], "Registered execution source differs")
    require(provenance({})["sourceHash"] == plan["sourceHash"], "Package source differs")
    for path, expected in plan["files"].items():
        require(file_hash(path) == expected, "Registered asset changed: " + path)
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    fitted = read(Path(plan["candidate"]) / "report.json")
    require(fitted["eligibleForSequentialTrainCheck"], "Scoped inner learning gates failed")
    root = Path(plan["output"])
    require(not root.exists(), "Preserve prior evaluations")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    started = time.perf_counter()
    original = Path(fitted["plan"]["encoded"])
    inputs = {r["id"]: r for r in lines(original / "initial-inputs.jsonl")}
    environment = lines(original / "environment.jsonl")
    episodes = [inputs[r["id"]] | r for r in environment]
    require(
        len(episodes) == 514 and all(e["split"] == "train" for e in episodes),
        "Train cohort differs",
    )
    jsonl(root / "inputs.jsonl", [inputs[r["id"]] for r in environment])
    jsonl(root / "environment.jsonl", environment)
    model, tokenizer, config, _ = structured_train.load(fitted["plan"]["retainedModel"], "cuda")
    require(
        weights_hash(model.state_dict()) == fitted["plan"]["parentWeightsHash"], "Parent differs"
    )
    model.requires_grad_(False).eval()
    frozen_hash = weights_hash(
        {
            k: v
            for k, v in model.state_dict().items()
            if not k.startswith(("heads.value.", "heads.recovery."))
        }
    )
    original_forward, outputs, fresh_checks = model.forward, {}, []
    active_name = "parent"

    @torch.inference_mode()
    def cached_forward(view):
        key = digest(
            [active_name in ("parent", "checklist", "failure_rule"), previous.observed_key(view)]
        )
        if key not in outputs:
            outputs[key] = original_forward(view)
        result = dict(outputs[key])
        if active_name.startswith("scoped-"):
            with torch.autocast("cuda", enabled=False):
                result["value"] = constrain(
                    torch.nn.functional.softplus(
                        model.heads["value"](result["valueState"]).float()
                    ),
                    view.get("valueCosts"),
                )
        if active_name.startswith("scoped-") and not view.get("recoveryActive", False):
            prior_scores = constrain(
                torch.nn.functional.softplus(
                    model.heads["value"].base(result["valueState"][:, :-1]).float()
                ),
                view.get("valueCosts"),
            )
            require(torch.equal(result["value"], prior_scores), "Normal policy scores changed")
        if len(fresh_checks) < 12:
            direct = original_forward(view)
            require(
                all(torch.equal(v, direct[k]) for k, v in result.items()), "Cached values differ"
            )
            fresh_checks.append(key)
        return result

    model.forward = cached_forward
    report = {
        "scope": "Actual Train validation of frozen recovery-scoped refits, parent, failure-aware checklist and the same parent with an observable failure stopping rule. All response draws and cohorts are paired; no new training or epoch selection. Cached refit scores are diagnostics under the registered protocol.",
        "source": provenance({}),
        "registration": plan,
        "devUsed": False,
        "testUsed": False,
        "episodes": len(episodes),
        "families": len({e["family"] for e in episodes}),
        "results": {},
        "gates": {},
    }
    write(root / "registered.json", report)
    state_cache, responses = {}, {}
    order = ["parent", "checklist", "failure_rule"] + [f"scoped-{seed}" for seed in (42, 43, 44)]
    initial = None
    for active_name in order:
        if active_name == "scoped-42":
            for name in ("value", "recovery"):
                old = model.heads[name]
                weights = copy.deepcopy(old.state_dict())
                weights["layers.0.weight"] = torch.cat(
                    [weights["layers.0.weight"], weights["layers.0.weight"].new_zeros((128, 94))], 1
                )
                replacement = Head(350, 128, old.layers[-1].out_features).cuda().eval()
                replacement.load_state_dict(weights)
                model.heads[name] = replacement
            initial = copy.deepcopy(model.heads["value"].state_dict())
            require(weights_hash(initial) == fitted["baseHeadHash"], "Padded parent differs")
            config["encoder"].update(
                numericState=True, actionPrecision="float32", recoveryResidual=True
            )
            model.config.update(numericState=True, actionPrecision="float32", recoveryResidual=True)
            recovery_hash = weights_hash(model.heads["recovery"].state_dict())
        if active_name.startswith("scoped-"):
            kind, random_seed = active_name.split("-")
            path = Path(plan["candidate"]) / f"refit-{random_seed}.pt"
            payload = torch.load(path, map_location="cpu", weights_only=True)
            require(
                payload["parentWeightsHash"] == fitted["plan"]["parentWeightsHash"],
                "Wrong parent checkpoint",
            )
            head = make_head(initial, int(random_seed))
            head.load_state_dict(payload["weights"])
            model.heads["value"] = head.cuda().requires_grad_(False).eval()
            require(
                weights_hash(head.base.state_dict()) == fitted["baseHeadHash"],
                "Frozen prior changed",
            )
        model.requires_grad_(False).eval()
        router = (
            FailureRouter(
                model,
                tokenizer,
                config["encoder"],
                fallback="parent" if active_name == "failure_rule" else "checklist",
            )
            if active_name in ("checklist", "failure_rule")
            else CachedRouter(model, tokenizer, config["encoder"])
        )
        router.reset()
        router.cache = state_cache
        fresh_checks.clear()
        generated, retail = [], {"0": [], "0.1": []}
        measurements = []
        with gzip.open(root / f"{active_name}-rollouts.jsonl.gz", "wt", compresslevel=3) as stream:
            for sample in range(plan["samples"] + 1):
                draw = digest([plan["responseSeed"], "sequential", sample])
                for episode in episodes:
                    benchmark = "retail" if "forecast" in episode["input"]["task"] else "generated"
                    if sample == plan["samples"] and benchmark != "retail":
                        continue
                    noise = 0.1 if benchmark == "retail" and sample < plan["samples"] else 0
                    actual = rollout(episode, router, noise=noise, response_seed=draw)
                    raw = {
                        "benchmark": benchmark,
                        "noise": noise,
                        "sample": sample,
                        "responseSeed": draw,
                        **actual,
                    }
                    stream.write(json.dumps(raw, allow_nan=False) + "\n")
                    for event in actual["events"]:
                        if event["action"] not in ("hold", "handoff", "retrieve"):
                            key = (episode["id"], draw, noise, event["action"])
                            answer = event["observedResponse"]
                            require(
                                key not in responses or responses[key] == answer,
                                "Response pairing differs",
                            )
                            responses[key] = answer
                    if benchmark == "generated":
                        generated.append(raw)
                    else:
                        retail[str(noise)].append(raw)
                    measurements.append(
                        {
                            "id": episode["id"],
                            "family": episode["family"],
                            "benchmark": benchmark,
                            "noise": noise,
                            "responseSeed": draw,
                            "actions": [v["action"] for v in actual["events"]],
                            **{
                                k: actual[k]
                                for k in (
                                    "q",
                                    "result",
                                    "total",
                                    "terminalLoss",
                                    "requestCost",
                                    "falseHandoff",
                                )
                            },
                        }
                    )
                write(
                    root / "progress.json",
                    {
                        "condition": active_name,
                        "sample": sample,
                        "seconds": time.perf_counter() - started,
                    },
                )
        metrics = {
            "generated": generated_metrics(generated),
            "retail": {k: retail_metrics(v) for k, v in retail.items()},
        }
        metrics["generated"]["meanTerminalLoss"] = float(
            np.mean([r["terminalLoss"] for r in generated])
        )
        jsonl(root / f"{active_name}-measurements.jsonl", measurements)
        report["results"][active_name] = {
            "metrics": metrics,
            "rollouts": len(measurements),
            "cachedForwardChecks": len(fresh_checks),
            "headTensorHash": weights_hash(model.heads["value"].state_dict()),
        }
        write(root / "partial.json", report)
        print(
            {
                "condition": active_name,
                "generated": metrics["generated"]["meanTotal"],
                "retail": {k: v["total"] for k, v in metrics["retail"].items()},
                "seconds": time.perf_counter() - started,
            },
            flush=True,
        )
    for seed in (42, 43, 44):
        current = report["results"][f"scoped-{seed}"]["metrics"]
        parent = report["results"]["parent"]["metrics"]
        criteria = {"parent-" + k: v for k, v in compare(current, parent).items()}
        criteria["improvesActualTotalOverParent"] = current["generated"]["meanTotal"] < parent[
            "generated"
        ]["meanTotal"] - 1e-9 or any(
            current["retail"][k]["total"] < parent["retail"][k]["total"] - 1e-9
            for k in ("0", "0.1")
        )
        report["gates"][str(seed)] = criteria
    require(
        weights_hash(
            {
                k: v
                for k, v in model.state_dict().items()
                if not k.startswith(("heads.value.", "heads.recovery."))
            }
        )
        == frozen_hash,
        "Frozen constructor or demand weights changed",
    )
    require(
        weights_hash(model.heads["recovery"].state_dict()) == recovery_hash,
        "Padded recovery head changed",
    )
    report.update(
        eligibleForDev=all(all(g.values()) for g in report["gates"].values()),
        seconds=time.perf_counter() - started,
        rawRollouts=sum(r["rollouts"] for r in report["results"].values()),
        pairedObservedChannels=len(responses),
        cachedViews=len(outputs),
        constructedStates=len(state_cache),
        frozenWeightsPreserved=True,
        frozenScope="Constructor and demand tensors unchanged; original value prior unchanged in every correction; recovery only padded with zero input columns and then preserved.",
        peakGpuBytes=torch.cuda.max_memory_allocated(),
    )
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print(
        {
            "completed": True,
            "seconds": report["seconds"],
            "eligibleForDev": report["eligibleForDev"],
            "failures": {s: [k for k, v in g.items() if not v] for s, g in report["gates"].items()},
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
