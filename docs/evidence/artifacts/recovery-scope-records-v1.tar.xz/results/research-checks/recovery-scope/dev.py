"""Validate fixed recovery-scoped refits and simple failure baselines on original Dev."""

import copy
import gzip
import json
import os
import sys
import time
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from evaluate_responses import CachedRouter, conditions, expectations, file_hash, measurement
from sequential import FailureRouter, previous
from study_recovery_scope import make_head

from newsvendor import structured_compare, structured_retail, structured_train
from newsvendor.cli import provenance
from newsvendor.heads import Head
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_metrics import generated_metrics
from newsvendor.structured_policy import public_validation, retained
from newsvendor.structured_rollout import rollout
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_value import constrain


def gates(reference, current):
    a, b = reference["generated"], current["generated"]
    result = {
        "generatedTotal": b["meanTotal"] <= a["meanTotal"] + 1e-9,
        "generatedFalseHandoffs": b["falseHandoffs"] <= a["falseHandoffs"],
        "generatedResolvedRequests": b["resolvedFieldRequests"] <= a["resolvedFieldRequests"],
        "generatedParameters": all(
            b["finalParameters"][k] >= a["finalParameters"][k] - 1e-12
            for k in ("parameterAccuracy", "stateAccuracy", "typeAccuracy")
        ),
        "generatedEvidence": b["finalEvidenceAccuracy"] >= a["finalEvidenceAccuracy"] - 1e-12,
    }
    for rate in ("0", "0.1", "0.2"):
        a, b = reference["retail"][rate], current["retail"][rate]
        result["retailTotal-" + rate] = (
            b["totalOnCompletePeriods"]["mean"] <= a["totalOnCompletePeriods"]["mean"] + 1e-9
        )
        for metric in ("falseHandoff", "unnecessaryRequests"):
            result[metric + "-" + rate] = b[metric]["mean"] <= a[metric]["mean"] + 1e-12
        for metric in ("parameterAccuracy", "stateAccuracy", "typeAccuracy"):
            result[metric + "-" + rate] = b[metric]["mean"] >= a[metric]["mean"] - 1e-12
        result["evidence-" + rate] = (
            b["evidenceCorrect"]["mean"] / b["evidenceCount"]["mean"]
            >= a["evidenceCorrect"]["mean"] / a["evidenceCount"]["mean"] - 1e-12
        )
    for metric in ("necessaryRequests", "recoveredAfterRequest", "handoffRate"):
        result[metric + "-no-dropout"] = (
            current["retail"]["0"][metric]["mean"]
            >= reference["retail"]["0"][metric]["mean"] - 1e-12
        )
    result["missingAtStop-no-dropout"] = (
        current["retail"]["0"]["missingAtStop"]["mean"]
        <= reference["retail"]["0"]["missingAtStop"]["mean"] + 1e-12
    )
    return result


def main():
    plan = read("configs/research-recovery-scoped-dev-v1.json")
    require(file_hash(__file__) == plan["scriptHash"], "Registered Dev source differs")
    require(provenance({})["sourceHash"] == plan["sourceHash"], "Package source differs")
    require(os.environ.get("CUDA_VISIBLE_DEVICES") == plan["gpu"], "Assigned L40S only")
    require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(0), "L40S only")
    for path, checksum in plan["files"].items():
        require(file_hash(path) == checksum, "Registered asset changed: " + path)
    require(read(plan["trainReport"])["eligibleForDev"], "Actual sequential Train gate failed")
    fitted = read(Path(plan["candidate"]) / "report.json")
    root = Path(plan["output"])
    require(not root.exists(), "Preserve earlier runs")
    root.mkdir()
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    started = time.perf_counter()
    episodes = {}
    for name, directory in plan["cohorts"].items():
        observed = lines(Path(directory) / "inputs.jsonl")
        environment = {r["id"]: r for r in lines(Path(directory) / "environment.jsonl")}
        require(all(r["split"] == "dev" for r in observed), "Dev only")
        episodes[name] = [r | environment[r["id"]] for r in observed]
        if name == "retail":
            for episode in episodes[name]:
                episode.update(
                    benchmark=structured_retail.VERSION,
                    cutoffIndex=len(episode["input"]["observations"]),
                )
        jsonl(root / f"{name}-inputs.jsonl", observed)
        jsonl(root / f"{name}-environment.jsonl", list(environment.values()))
    require(
        len(episodes["generated"]) == 60 and len(episodes["retail"]) == 336, "Dev cohort changed"
    )
    model, tokenizer, config, _ = structured_train.load(plan["checkpoint"], "cuda")
    require(weights_hash(model.state_dict()) == fitted["plan"]["parentWeightsHash"], "Wrong parent")
    model.requires_grad_(False).eval()
    public_dir = Path(plan["publicDataset"])
    public_rows = [
        r
        for r in lines(public_dir / "inputs.jsonl")
        if r["split"] == "dev" and r["component"] in ("contractnli", "cuad", "orsharc", "tatqa")
    ]
    require(len(public_rows) == 258, "Public Dev changed")
    cases = [("public", r) for r in public_rows]
    labels = {
        r["id"]: r["target"]
        for r in lines(public_dir / "labels.jsonl")
        if r["id"] in {e["id"] for e in public_rows}
    }
    collection = lines(public_dir / "collection.jsonl")
    frozen_hash = weights_hash(
        {
            k: v
            for k, v in model.state_dict().items()
            if not k.startswith(("heads.value.", "heads.recovery."))
        }
    )
    original_forward, outputs, direct_checks = model.forward, {}, []
    active_name = "parent"

    @torch.inference_mode()
    def cached_forward(view):
        scoped = active_name.startswith("scoped-")
        key = digest([scoped, previous.observed_key(view)])
        if key not in outputs:
            outputs[key] = original_forward(view)
        result = dict(outputs[key])
        if scoped:
            with torch.autocast("cuda", enabled=False):
                result["value"] = constrain(
                    torch.nn.functional.softplus(
                        model.heads["value"](result["valueState"]).float()
                    ),
                    view.get("valueCosts"),
                )
            if not view.get("recoveryActive", False):
                before = constrain(
                    torch.nn.functional.softplus(
                        model.heads["value"].base(result["valueState"][:, :-1]).float()
                    ),
                    view.get("valueCosts"),
                )
                require(torch.equal(result["value"], before), "Normal scores changed")
        if len(direct_checks) < 12:
            direct = original_forward(view)
            require(
                all(torch.equal(v, direct[k]) for k, v in result.items()),
                "Cached inference differs",
            )
            direct_checks.append(key)
        return result

    model.forward = cached_forward
    state_cache = {}
    report = {
        "scope": "Fixed three-seed recovery-scoped refits after registered Train gates; parent and two observable stopping baselines on original Dev. Controlled data only.",
        "source": provenance({}),
        "registration": plan,
        "testUsed": False,
        "newSourceHoldoutUsed": False,
        "devUsed": True,
        "trainingPerformed": False,
        "primary": "scoped-42",
        "results": {},
        "gates": {},
    }
    write(root / "registered.json", report)
    for active_name in [
        "parent",
        "checklist",
        "failure_rule",
        "scoped-42",
        "scoped-43",
        "scoped-44",
    ]:
        head_path, selected_epoch = Path(plan["checkpoint"]), 0
        if active_name == "scoped-42":
            for name in ("value", "recovery"):
                old = model.heads[name]
                weights = copy.deepcopy(old.state_dict())
                weights["layers.0.weight"] = torch.cat(
                    [weights["layers.0.weight"], weights["layers.0.weight"].new_zeros((128, 94))], 1
                )
                model.heads[name] = Head(350, 128, old.layers[-1].out_features).cuda().eval()
                model.heads[name].load_state_dict(weights)
            initial = copy.deepcopy(model.heads["value"].state_dict())
            require(weights_hash(initial) == fitted["baseHeadHash"], "Padded prior differs")
            config["encoder"].update(
                numericState=True, actionPrecision="float32", recoveryResidual=True
            )
            model.config.update(numericState=True, actionPrecision="float32", recoveryResidual=True)
            recovery_hash = weights_hash(model.heads["recovery"].state_dict())
        if active_name.startswith("scoped-"):
            seed = active_name.split("-")[1]
            head_path = Path(plan["candidate"]) / f"refit-{seed}.pt"
            payload = torch.load(head_path, map_location="cpu", weights_only=True)
            selected_epoch = payload["selectedEpoch"]
            require(selected_epoch == fitted["refit"][seed]["selectedEpoch"], "Fixed epoch differs")
            model.heads["value"] = make_head(initial, int(seed)).cuda().requires_grad_(False).eval()
            model.heads["value"].load_state_dict(payload["weights"])
            require(
                weights_hash(model.heads["value"].state_dict())
                == fitted["refit"][seed]["weightsHash"],
                "Candidate tensor hash differs",
            )
            require(
                weights_hash(model.heads["value"].base.state_dict()) == fitted["baseHeadHash"],
                "Prior changed",
            )
        router = (
            FailureRouter(
                model,
                tokenizer,
                config["encoder"],
                fallback="parent" if active_name == "failure_rule" else "checklist",
            )
            if active_name in ("checklist", "failure_rule")
            else CachedRouter(model, tokenizer, config["encoder"])
        )
        router.reset()
        router.cache = state_cache
        direct_checks.clear()
        generated = []
        with gzip.open(root / f"{active_name}-generated.jsonl.gz", "wt", compresslevel=3) as stream:
            for episode in episodes["generated"]:
                record = rollout(episode, router)
                stream.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
                generated.append(record)
        measured = []
        with gzip.open(root / f"{active_name}-retail.jsonl.gz", "wt", compresslevel=3) as stream:
            for index, episode in enumerate(episodes["retail"]):
                for missing in conditions(0):
                    record = rollout(episode, router, missing_responses=frozenset(missing))
                    record["missingResponses"] = list(missing)
                    stream.write(json.dumps(record, allow_nan=False, separators=(",", ":")) + "\n")
                    measured.append(measurement(record) | {"missingResponses": list(missing)})
                if (index + 1) % 32 == 0:
                    write(
                        root / "progress.json",
                        {
                            "condition": active_name,
                            "retailCases": index + 1,
                            "seconds": time.perf_counter() - started,
                        },
                    )
        jsonl(root / f"{active_name}-retail-measurements.jsonl", measured)
        expected = {str(rate): expectations(measured, rate) for rate in (0, 0.1, 0.2)}
        write(root / f"{active_name}-retail-expectations.json", expected)
        public = public_validation(
            model,
            tokenizer,
            config,
            cases,
            labels,
            collection,
            root / f"{active_name}-public.jsonl",
        )
        if active_name == "parent":
            report["publicParent"] = public
        report["results"][active_name] = {
            "selectedEpoch": selected_epoch,
            "headHash": file_hash(head_path),
            "generated": generated_metrics(generated),
            "retail": {k: structured_compare.means(v) for k, v in expected.items()},
            "public": public,
            "publicRetentionFailures": retained(report["publicParent"], public),
            "cachedForwardChecks": len(direct_checks),
            "generatedTerminalLoss": sum(r["terminalLoss"] for r in generated) / len(generated),
        }
        if active_name == "parent":
            report["parent"] = {k: report["results"]["parent"][k] for k in ("generated", "retail")}
            historical = read(plan["reference"])
            require(
                report["parent"]["generated"]
                == historical["generatedComparison"]["results"]["after-value"]["metrics"],
                "Native parent generated metrics changed",
            )
            require(
                report["parent"]["retail"] == historical["results"]["value"]["metrics"],
                "Native parent retail metrics changed",
            )
        write(root / "partial.json", report)
        print(
            {
                "condition": active_name,
                "generatedTotal": report["results"][active_name]["generated"]["meanTotal"],
                "retailTotals": {
                    k: v["totalOnCompletePeriods"]["mean"]
                    for k, v in report["results"][active_name]["retail"].items()
                },
                "seconds": time.perf_counter() - started,
            },
            flush=True,
        )
    for seed in (42, 43, 44):
        candidate, parent = report["results"][f"scoped-{seed}"], report["parent"]
        result = {"parent-" + k: v for k, v in gates(parent, candidate).items()}
        result["publicRetention"] = not candidate["publicRetentionFailures"]
        result["actualImprovementOverParent"] = candidate["generated"]["meanTotal"] < parent[
            "generated"
        ]["meanTotal"] - 1e-9 or any(
            candidate["retail"][k]["totalOnCompletePeriods"]["mean"]
            < parent["retail"][k]["totalOnCompletePeriods"]["mean"] - 1e-9
            for k in parent["retail"]
        )
        report["gates"][str(seed)] = result
    require(
        weights_hash(
            {
                k: v
                for k, v in model.state_dict().items()
                if not k.startswith(("heads.value.", "heads.recovery."))
            }
        )
        == frozen_hash,
        "Constructor or GRU changed",
    )
    require(
        weights_hash(model.heads["recovery"].state_dict()) == recovery_hash,
        "Recovery classifier changed",
    )
    report.update(
        eligibleForAdoption=all(all(g.values()) for g in report["gates"].values()),
        seconds=time.perf_counter() - started,
        peakGpuBytes=torch.cuda.max_memory_allocated(),
        frozenWeightsPreserved=True,
        rawRollouts=6 * (60 + 16 * 336),
    )
    report["rawHashes"] = {p.name: file_hash(p) for p in root.iterdir() if p.is_file()}
    write(root / "report.json", report)
    print(
        {
            "completed": True,
            "seconds": report["seconds"],
            "eligibleForAdoption": report["eligibleForAdoption"],
            "failedGates": {
                s: [k for k, v in g.items() if not v] for s, g in report["gates"].items()
            },
        },
        flush=True,
    )


if __name__ == "__main__":
    main()
