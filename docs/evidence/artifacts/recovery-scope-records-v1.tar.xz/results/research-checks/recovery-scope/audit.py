"""Audit source isolation, matched updates, fixed epochs and preserved base estimates."""

import sys
from pathlib import Path

import torch

sys.path.insert(0, str(Path("scripts").resolve()))
from evaluate_responses import file_hash

from newsvendor.io import lines, read, require, write
from newsvendor.structured_tool_eval import weights_hash

root = Path("/dev/shm/newsvendor-recovery-scoped-v1")
report = read(root / "report.json")
control = Path(report["plan"]["control"])
full = Path(report["plan"]["fullControl"])
original = read(control / "report.json")
rows = lines(Path(report["plan"]["encoded"]) / "targets.jsonl")
fit_families = set(report["partitions"]["fit"]["families"])
held_families = set(report["partitions"]["held"]["families"])
require(not fit_families & held_families, "Inner source overlap")
require(all(r["split"] == "train" for r in rows), "Non-Train data used")
for key in ("epochs", "batchSize", "lr", "rankWeight", "seeds"):
    require(report["plan"][key] == original["plan"][key], "Control budget differs: " + key)
audit = {"devUsed": False, "testUsed": False, "sourceOverlap": 0, "runs": {}}
for random_seed in (42, 43, 44):
    inner = report["inner"][str(random_seed)]
    best, chosen = original["initial"]["meanTargetLoss"], 0
    for epoch in inner["epochs"]:
        if epoch["meanTargetLoss"] < best - 1e-10:
            best, chosen = epoch["meanTargetLoss"], epoch["epoch"]
    require(chosen == inner["selectedEpoch"], "Inner selected epoch differs")
    for stage in ("inner", "refit"):
        name = f"{stage}-{random_seed}"
        old = (
            control / f"batches-{random_seed}.json"
            if stage == "inner"
            else full / f"balanced-{random_seed}-batches.json"
        )
        batches = read(root / f"{name}-batches.json")
        require(batches == read(old), "Recorded batch sequence differs")
        fitting = fit_families if stage == "inner" else fit_families | held_families
        require(
            all(rows[i]["family"] in fitting for batch in batches for i in batch),
            "Held source entered fitting",
        )
        checkpoint = torch.load(root / f"{name}.pt", map_location="cpu", weights_only=True)
        require(checkpoint["selectedEpoch"] == chosen, "Refit epoch was reselected")
        for key in ("weights", "finalWeights"):
            base = {
                k.removeprefix("base."): v
                for k, v in checkpoint[key].items()
                if k.startswith("base.")
            }
            require(weights_hash(base) == report["baseHeadHash"], "Frozen prior was trained")
        result = report[stage][str(random_seed)]
        require(
            weights_hash(checkpoint["weights"]) == result["weightsHash"],
            "Reported tensor hash differs",
        )
        selected = result["epochs"][chosen - 1]
        require(
            all(result["selected"][k] == selected[k] for k in result["selected"]),
            "Selected measurements differ",
        )
        require(
            file_hash(root / f"{name}.pt") == report["rawHashes"][name + ".pt"],
            "Checkpoint bytes differ",
        )
        audit["runs"][name] = {
            "updates": len(batches),
            "draws": sum(map(len, batches)),
            "selectedEpoch": chosen,
            "batchesExactlyMatchControl": True,
            "baseUnchangedInSelectedAndFinal": True,
            "selectedTargetLoss": result["selected"]["meanTargetLoss"],
        }
write("results/research-checks/recovery-scope/audit.json", audit)
print(
    {
        "verifiedRuns": len(audit["runs"]),
        "sourceOverlap": 0,
        "allBatchesAndBaseWeightsVerified": True,
    }
)
