"""Publish scoped recovery learning, the failed first selection and all paired outcomes."""

import importlib.util
from pathlib import Path

from newsvendor.io import read, write

spec = importlib.util.spec_from_file_location(
    "prior_publication", "results/research-checks/recovery-balance/publish.py"
)
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
publish, raw_entries = prior.publish, prior.raw_entries


def compact(report):
    result = {k: v for k, v in report.items() if k != "rawHashes"}
    for stage in ("inner", "refit"):
        if stage not in result:
            continue
        result[stage] = {
            seed: {
                k: {a: b for a, b in value.items() if a != "selectedActions"}
                if k in ("selected", "fit")
                else value
                for k, value in run.items()
                if k != "epochs"
            }
            for seed, run in result[stage].items()
        }
    return result


def main():
    checks = Path("results/research-checks/recovery-scope")
    names = (
        "scoped-v1",
        "scoped-sequential-v1",
        "scoped-v2",
        "scoped-sequential-v2",
        "scoped-dev-v1",
    )
    roots = {name: Path(f"/dev/shm/newsvendor-recovery-{name}") for name in names}
    destinations = {name: f"results/l40s-recovery-{name}" for name in names}
    reports = {name: read(root / "report.json") for name, root in roots.items()}
    assert reports["scoped-v1"]["eligibleForSequentialTrainCheck"]
    assert not reports["scoped-sequential-v1"]["eligibleForDev"]
    assert reports["scoped-v2"]["eligibleForSequentialTrainCheck"]
    assert reports["scoped-sequential-v2"]["eligibleForDev"]
    raw = []
    for name in ("scoped-sequential-v1", "scoped-sequential-v2", "scoped-dev-v1"):
        raw += raw_entries(roots[name], destinations[name])
    raw_archive = publish(
        Path("docs/evidence/artifacts/recovery-scope-rollouts-v1.tar.xz"), {}, raw
    )
    files = {}
    for name, root in roots.items():
        for p in root.iterdir():
            if not p.is_file() or p.name.endswith(".jsonl.gz"):
                continue
            if p.name in reports[name]["rawHashes"]:
                assert prior.sha(p) == reports[name]["rawHashes"][p.name], p
            files[str(Path(destinations[name]) / p.name)] = p
    files.update(
        {str(p): p for p in checks.iterdir() if p.is_file() and "publication" not in p.name}
    )
    for p in [
        *Path("src/newsvendor").glob("*.py"),
        *Path("configs").glob("research-recovery-scoped*.json"),
        Path("scripts/study_recovery_scope.py"),
        Path("scripts/study_recovery_selection.py"),
        Path("scripts/study_recovery_residual.py"),
        Path("scripts/study_recovery_replay.py"),
        Path("scripts/study_recovery_sampling.py"),
        Path("scripts/evaluate_responses.py"),
        Path("tests/test_recovery_scope.py"),
        Path("tests/test_structured.py"),
        Path("docs/evidence/scripts/reproduce-recovery-scope.py"),
        Path("results/research-checks/recovery-balance/sequential.py"),
        Path("results/research-checks/recovery-balance/publish.py"),
        Path(".github/workflows/ci.yml"),
    ]:
        files[str(p)] = p
    if Path("scripts/compose_recovery.py").exists():
        files["scripts/compose_recovery.py"] = Path("scripts/compose_recovery.py")
    records = publish(Path("docs/evidence/artifacts/recovery-scope-records-v1.tar.xz"), files)
    eligible = reports["scoped-dev-v1"]["eligibleForAdoption"]
    result = {
        "scope": "Observed-failure-scoped value correction with frozen encoder, constructor and demand model; selection-only replay and paired original Train/Dev evaluation. Controlled documents and responses only.",
        "testUsed": False,
        "newSourceHoldoutUsed": False,
        "eligibleForAdoption": eligible,
        "weightsAdopted": False,
        "deploymentStatus": "Awaiting public-assets reproduction and composition verification",
        "retainedModel": "forecast-v1",
        "priorProtocolFailuresPreserved": True,
        "reports": {name: compact(report) for name, report in reports.items()},
        "selectionDiagnostic": read(checks / "selection-diagnostic.json"),
        "actualTrainCoverage": read(checks / "actual-coverage.json"),
        "learningAudits": {
            k: read(checks / v) for k, v in [("v1", "audit.json"), ("v2", "audit-v2.json")]
        },
        "featureAudits": {
            k: read(checks / v)
            for k, v in [("v1", "feature-audit.json"), ("v2", "feature-audit-v2.json")]
        },
        "trainOutcomeAudits": {
            k: read(checks / v)
            for k, v in [("v1", "outcome-audit.json"), ("v2", "outcome-audit-v2.json")]
        },
        "devOutcomeAudit": read(checks / "dev-audit.json"),
        "devComparison": read(checks / "dev-comparison.json"),
        "checks": read(checks / "checks.json"),
        "artifact": records,
        "rawArtifact": raw_archive,
        "rawFormat": "Decompressed JSONL bytes and order are unchanged. raw-format.json preserves original gzip hashes and exact raw-byte hashes; tar.xz avoids recompressing gzip streams.",
        "limitations": [
            "V1 actual Train gate failed; v2 checkpoint selection was separately registered before its learning replay and subsequent Train outcomes. V1 is not retrospectively passed.",
            "Each Train comparison uses fresh paired response draws; compare candidates with their own parent, not totals between response seeds.",
            "V2 final weights match v1 exactly for all six training runs; only held continuous-loss tie breaking and resulting selected epochs changed.",
            "Parent encoder had seen the Train families; source-held action-head selection is not independent generalization.",
            "Original Dev was repeatedly used for development; this is not a new blind evaluation.",
            "Exact retail losses use only five complete periods from four sources, giving 35 conditions; censored periods remain separate.",
            "Compare the same-parent observed-failure rule as well as a failure-aware checklist before crediting learning.",
            "Generated Dev is 60 cases from 12 families. Public extraction, demand calibration and the historical frozen Test threshold remain unresolved.",
        ],
    }
    write("docs/evidence/research-recovery-scope-results.json", result)
    write(checks / "publication.json", {"artifact": records, "rawArtifact": raw_archive})


if __name__ == "__main__":
    main()
