"""Check that the isolation guard is active before accepting loading results."""
import json
import socket
import sys
from pathlib import Path

assert 'sitecustomize' in sys.modules
root = Path('/dev/shm/newsvendor-response-state-restored-v1')
target = Path('/home/yunmin/newsvendor-router/data/processed/complementary/manifest.json')
link = root / 'blocked-data-link'
assert not link.exists() and not link.is_symlink()
link.symlink_to(target)
checks = {}
for name, action in (
    ('directDataAccessBlocked', lambda: target.open()),
    ('symlinkDataAccessBlocked', lambda: link.open()),
    ('checkpointAccessBlocked', lambda: Path('/home/yunmin/newsvendor-router/results/l40s-research-forecast-v1/base/42/model.pt').open('rb')),
    ('networkBlocked', lambda: socket.create_connection(('127.0.0.1', 9))),
):
    try:
        action()
    except RuntimeError as error:
        checks[name] = 'forbidden' in str(error)
    else:
        checks[name] = False
assert all(checks.values())
checks['guardLoaded'] = True
checks['emptyHubCache'] = not list((root / 'empty-hub-cache').rglob('*'))
assert checks['emptyHubCache']
(root / 'access-proof.json').write_text(json.dumps(checks, indent=2) + '\n')
print(checks, flush=True)
