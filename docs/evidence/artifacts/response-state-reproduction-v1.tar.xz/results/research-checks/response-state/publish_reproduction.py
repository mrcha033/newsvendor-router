"""Preserve the public-assets loading check separately from the full Dev study."""
from pathlib import Path
from publish import publish
from newsvendor.io import read, write

root = Path('/dev/shm/newsvendor-response-state-reproduction-v1')
restored = Path('/dev/shm/newsvendor-response-state-restored-v1')
checks = Path('results/research-checks/response-state')
report = read(root / 'report.json')
assert report['smokeOnly'] and len(report['episodes']) == 7
assert all(r['allExactlyEqual'] and r['measurements'] == 112 for r in report['results'].values())
assert all(read(restored / 'access-proof.json').values())
files = {str(Path('results/response-state-public-reproduction-v1') / p.name): p
         for p in root.iterdir() if p.is_file()}
files[str(checks / 'reproduction-guard.py')] = restored / 'guard/sitecustomize.py'
for name in ('restoration.json', 'access-proof.json'):
    files[str(checks / name)] = restored / name
for name in ('reproduction.log', 'guard-probe.log', 'guard-probe-blocked-script.log', 'guard_probe.py', 'restore.py', 'publish_reproduction.py'):
    files[str(checks / name)] = checks / name
files['scripts/reproduce_responses.py'] = Path('scripts/reproduce_responses.py')
artifact = publish(Path('docs/evidence/artifacts/response-state-reproduction-v1.tar.xz'), files)
path = 'docs/evidence/research-response-state-results.json'
evidence = read(path)
evidence['publishedReproduction'] = {
    **report, 'artifact': artifact, 'accessRestrictions': read(restored / 'access-proof.json'),
    'verifiedMeasurements': 336,
    'scopeNote': 'Seven fixed cases, one per scenario, 16 response conditions, three policies. Remaining 329 cases were not rerun in this loading check.',
}
write(path, evidence)
write(checks / 'reproduction-publication.json', artifact)
