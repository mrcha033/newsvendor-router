"""Restore only public assets into a fresh directory for an isolated loading check."""
import hashlib
import tarfile
from pathlib import Path
from newsvendor.io import read, write

evidence = read('docs/evidence/research-response-state-results.json')
root = Path('/dev/shm/newsvendor-response-state-restored-v1')
assert not root.exists()
root.mkdir()
artifact = evidence['artifact']
with Path(artifact['path']).open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == artifact['sha256']
with tarfile.open(artifact['path'], 'r:xz') as archive:
    selected = [m for m in archive.getmembers() if m.name.startswith(evidence['dataPrefix'] + '/')]
    archive.extractall(root, members=selected, filter='data')
for member in selected:
    with (root / member.name).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == artifact['files'][member.name]['sha256']
guard = root / 'guard'
guard.mkdir()
(guard / 'sitecustomize.py').write_text('''import os, sys
from pathlib import Path
blocked = [Path('/home/yunmin/newsvendor-router/data'), Path('/home/yunmin/newsvendor-router/results')]
def audit(event, args):
    if event in ('socket.connect', 'socket.getaddrinfo'):
        raise RuntimeError('Network forbidden during published-assets reproduction')
    if event == 'open' and isinstance(args[0], (str, bytes, os.PathLike)):
        path = Path(os.path.abspath(os.fsdecode(args[0])))
        if any(path.is_relative_to(r) or path.resolve().is_relative_to(r) for r in blocked):
            raise RuntimeError('Working data/checkpoint forbidden: ' + str(path))
sys.addaudithook(audit)
''')
(root / 'empty-hub-cache').mkdir()
write(root / 'restoration.json', {'artifact': artifact['path'], 'sha256': artifact['sha256'],
                                'verifiedMembers': len(selected), 'source': evidence['source']['sourceHash']})
print({'restored': str(root), 'verifiedMembers': len(selected)}, flush=True)
