import os
import runpy
import sys
import time
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write
from newsvendor.structured_progress import Progress
from newsvendor.structured_train import save

root = Path("results/l40s-research-coverage-v1")
root.mkdir(parents=True, exist_ok=True)
output = Path("/dev/shm/newsvendor-replay-coverage-v1/42")
config_path = "configs/l40s-research-coverage-v1.json"
config = read(config_path)
checks = Path("results/research-checks/replay-coverage")
require(not output.exists() and not (root/"queue.json").exists(), "Preserve the existing run")
probe = read(checks/"probe.json")
require(not probe["testUsed"] and not probe["devUsed"] and probe["source"]["sourceHash"] == provenance(config)["sourceHash"], "Missing current-source Train diagnostic")
require("286 passed" in (checks/"tests.log").read_text(), "Tests incomplete")
require("All checks passed!" in (checks/"ruff.log").read_text(), "Lint incomplete")
require(all(v["check"]["sourceOverlaps"] == v["check"]["inputOverlaps"] == 0 for v in read(checks/"source-checks.json").values()), "Source leakage")
require(read("results/smoke.json")["smokeEpisodes"] == 30 and read("results/smoke.json")["falseHandoffs"] == 0, "Numerical smoke incomplete")
registration = {"config":config,"configHash":file_hash(config_path),"source":provenance(config),"parentHash":file_hash(config["warmStart"]),"runtimeOutput":str(output),"testUsed":False,"scriptHash":file_hash(__file__),"comparison":"Historical retention-v1: same parent, research cases, model, learning rates, epochs and teacher weight. All public Train examples replace repeated subset; more updates, not equal compute.","pid":os.getpid()}
write(root/"registered.json", registration)
checkpoint = Progress.checkpoint

def preserve(self, name, model, state, optimizer=None):
    checkpoint(self, name, model, state, optimizer)
    if name == "language-progress" and state.get("epoch",0)>0 and state.get("offset")==0:
        path = self.directory/f"language-epoch-{state['epoch']}.pt"
        require(not path.exists(), "Candidate already captured")
        save(path, model, self.config, {"epoch":state["epoch"],"selectedEpoch":state["selected"],"epochs":state["report"]})
        print({"preservedLanguageCandidate":str(path)},flush=True)

Progress.checkpoint = preserve
write(root/"queue.json", {"status":"running","pid":os.getpid(),"output":str(output),"started":time.time(),"sourceHash":registration["source"]["sourceHash"]})
sys.argv = ["scripts/run_research.py","--config",config_path,"--stage","train","--output",str(output)]
start = time.perf_counter()
try:
    runpy.run_path("scripts/run_research.py",run_name="__main__")
except BaseException as error:
    write(root/"queue.json", {"status":"failed","pid":os.getpid(),"output":str(output),"error":repr(error),"seconds":time.perf_counter()-start})
    raise
write(root/"queue.json", {"status":"complete","pid":os.getpid(),"output":str(output),"seconds":time.perf_counter()-start})
