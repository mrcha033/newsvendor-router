"""Remove only byte-identical, durable archive duplicates from completed runs."""
import hashlib
import subprocess
import tarfile
from pathlib import Path

from newsvendor.bundle import file_hash
from newsvendor.io import read, require, write

root = Path("results/research-checks/replay-coverage")
runs = [
    Path("results/l40s-research-parameter-contrasts-v1"),
]
records = read(root / "duplicate-storage.json")["records"]
for run in runs:
    metadata = read(run / "storage.json")
    archive = Path(metadata["archive"])
    filename = "common.pt"
    direct = run / "42" / filename if "scope-v1" in str(run) else run / "base/42" / filename
    require(direct.is_file(), "No duplicate to verify")
    expected = metadata["files"][filename]
    require(file_hash(archive) == metadata["archiveHash"], "Durable archive changed")
    require(file_hash(direct) == expected["sha256"] and direct.stat().st_size == expected["bytes"], "Direct checkpoint changed")
    process = subprocess.Popen(["zstd", "--long=31", "-dc", str(archive)], stdout=subprocess.PIPE)
    found = False
    with tarfile.open(fileobj=process.stdout, mode="r|") as tar:
        for member in tar:
            if member.name in (filename, "./" + filename):
                require(not found and member.isfile(), "Duplicate or invalid member")
                require(member.size == expected["bytes"], "Archived size differs")
                require(hashlib.file_digest(tar.extractfile(member), "sha256").hexdigest() == expected["sha256"], "Archived bytes differ")
                found = True
    require(process.wait() == 0 and found, "Archive verification failed")
    direct.unlink()
    metadata.setdefault("archiveOnly", []).append(filename)
    metadata["note"] = "Only byte-identical duplicates removed after rehashing the durable archive, member and local file. All model and optimizer versions remain restorable from the archive."
    write(run / "storage.json", metadata)
    records.append({"removedDuplicate":str(direct),"archive":str(archive),"archiveHash":metadata["archiveHash"],"member":filename,**expected,"verifiedBeforeRemoval":True})
    write(root / "duplicate-storage.json", {"records":records,"freedBytes":sum(r["bytes"] for r in records)})
    print(records[-1],flush=True)
