"""Summarize the completed registered run without selecting new candidates."""
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

from newsvendor.cli import provenance
from newsvendor.io import digest, lines, read, require, write

root = Path("results/l40s-research-coverage-v1")
checks = Path("results/research-checks/replay-coverage")
run = Path(read(root / "registered.json")["runtimeOutput"])
require(read(root / "queue.json")["status"] == "complete", "Run is active")
diagnostics = read(root / "diagnostics/report.json")
require(diagnostics["source"]["sourceHash"] == provenance({})["sourceHash"], "Source changed")
report = read(run / "report.json")
groups = {}
for cohort, prefix in (("generated", "generated-"), ("retail", "")):
    before = lines(run / f"initial-{prefix}dev-learned.jsonl")
    after = lines(run / f"final-{prefix}dev-learned.jsonl")
    require([r["id"] for r in before] == [r["id"] for r in after], "Case order differs")
    changed, deltas, by_family = [], [], defaultdict(list)
    for a, b in zip(before, after, strict=True):
        if cohort == "retail" and not a["outcomeComplete"]:
            continue
        keys = ("terminalLoss", "requestCost", "total")
        delta = {k:b[k] - a[k] for k in keys}
        require(abs(delta["total"] - delta["terminalLoss"] - delta["requestCost"]) < 1e-7, "Loss decomposition differs")
        deltas.append(delta)
        by_family[a["family"]].append(delta["total"])
        before_actions = [r["action"] for r in a["events"]]
        after_actions = [r["action"] for r in b["events"]]
        if any(abs(v) > 1e-9 for v in delta.values()) or before_actions != after_actions:
            fields = ("result", "q", "terminalLoss", "requestCost", "total", "interactions")
            changed.append({"id":a["id"],"family":a["family"],"before":{k:a[k] for k in fields},"after":{k:b[k] for k in fields},"beforeActions":before_actions,"afterActions":after_actions})
    groups[cohort] = {"cases":len(before),"exactLossCases":len(deltas),"exactLossFamilies":len(by_family),"meanDelta":{k:float(np.mean([r[k] for r in deltas])) for k in ("terminalLoss","requestCost","total")},"changed":changed,"familyMeanTotalDelta":{k:float(np.mean(v)) for k,v in by_family.items()},"beforeHash":digest(before),"afterHash":digest(after)}
write(checks / "loss-decomposition.json", groups)
decision = {"adopted":False,"candidatePassedRegisteredGates":diagnostics["allGatesPassed"],"gates":diagnostics["adoptionGates"],"publicRetentionFailures":diagnostics["publicRetentionFailures"],"selectionUnchanged":True,"selectedModel":"results/l40s-research-forecast-v1/base/42/model.pt","testUsed":False,"reason":"Assess the preregistered full-model gates and paired actual losses; never adopt on construction accuracy alone."}
write(root / "decision.json", decision)
print({"gates":decision["gates"],"decomposition":{k:v["meanDelta"] for k,v in groups.items()},"languageSelectedEpoch":report["language"]["selectedEpoch"]},flush=True)
