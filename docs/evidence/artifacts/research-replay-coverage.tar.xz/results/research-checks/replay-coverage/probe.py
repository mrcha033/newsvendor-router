"""Train-only coverage and local gradient diagnostics; no model selection."""

import os
import time
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import torch

from newsvendor import corpus, structured_train as training
from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import digest, jsonl, lines, read, require, write
from newsvendor.structured_inputs import research_input
from newsvendor.structured_labels import objective
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.suite import public_input
from newsvendor.suite_score import metrics
from newsvendor.train import seed

root = Path(__file__).resolve().parent
require(not (root / "probe.json").exists(), "Preserve previous measurements")
require(os.environ.get("CUDA_VISIBLE_DEVICES") == "GPU-674d64b8-4bdf-7006-1791-5dc7f7245409", "Assigned L40S only")
require(torch.cuda.device_count() == 1 and "L40S" in torch.cuda.get_device_name(), "Wrong GPU")
config = read("configs/l40s-research-retention-v1.json")
original = [r for r in lines("data/processed/complementary/inputs.jsonl") if r["split"] == "train" and r["component"] == "tatqa"]
old_hashes = {digest(r["input"]) for r in original}
expanded = [r for r in lines("data/processed/core-tatqa-train-v1/inputs.jsonl") if r["split"] == "train" and r["component"] == "tatqa" and digest(r["input"]) not in old_hashes]
random = np.random.default_rng(7301)
sample = [expanded[int(i)] for i in random.permutation(len(expanded))[:512]]
pools = {"original": original, "expanded": sample}
ids = {r["id"] for rows in pools.values() for r in rows}
labels = {r["id"]:r["target"] for r in lines("data/processed/core-tatqa-train-v1/labels.jsonl") if r["id"] in ids}
collection = lines("data/processed/core-tatqa-train-v1/collection.jsonl")
fit = lines("results/parameter-contrasts-v2/fit.jsonl")
require(all(r["split"] == "train" and digest(research_input(r["input"])) == r["inputHash"] for r in fit), "Invalid contrast inputs")
research = [fit[int(i)] for i in random.permutation(len(fit))[:64]]
models = {"parent":config["warmStart"], "retention":"/dev/shm/newsvendor-language-retention-v1/42/language-epoch-2.pt"}
registration = {"source":provenance(config), "scriptHash":file_hash(__file__), "testUsed":False, "devUsed":False, "samplingSeed":7301, "models":{k:{"path":v,"sha256":file_hash(v)} for k,v in models.items()}, "pools":{k:[{"id":r["id"],"family":r["family"],"inputHash":digest(r["input"])} for r in rows] for k,rows in pools.items()}, "gradientResearch":[{k:r[k] for k in ("id","family","inputHash")} for r in research]}
write(root / "registered.json", registration)
seed(42)
torch.set_num_threads(8)
start = time.perf_counter()
results = {}
for name, path in models.items():
    model, tokenizer, actual_config, _ = training.load(path, "cuda")
    before = weights_hash(model.state_dict())
    results[name] = {"weightsHash":before, "pools":{}}
    for pool_name, rows in pools.items():
        records, group = [], defaultdict(list)
        with torch.inference_mode():
            for row in rows:
                prediction, _ = training.infer(model, tokenizer, public_input(row), actual_config, collection)
                values = metrics(row, labels[row["id"]], prediction)
                records.append({"id":row["id"],"family":row["family"],"prediction":prediction,"metrics":values})
                for key,value in values.items():
                    if value is not None:group[key].append(float(value))
        jsonl(root / f"{name}-{pool_name}.jsonl", records)
        results[name]["pools"][pool_name] = {"cases":len(rows),"families":len({r["family"] for r in rows}),"metrics":{k:float(np.mean(v)) for k,v in group.items()}}
        write(root / "partial.json", results)
        print({"model":name,"pool":pool_name,**results[name]["pools"][pool_name]}, flush=True)
    if name == "parent":
        vectors, measured = {}, {}
        gradient_cases = {"research":[("research",r) for r in research]}
        gradient_cases.update({k:[("public",r) for r in rows[:64]] for k,rows in pools.items()})
        for group_name, cases in gradient_cases.items():
            model.eval()
            model.zero_grad(set_to_none=True)
            values = []
            for index in range(0,len(cases),16):
                group = cases[index:index+16]
                prepared = [training.language_view(c,tokenizer,config,labels,collection) for c in group]
                for lo,hi in model.training_batches([v for v,_ in prepared]):
                    outputs = model([v for v,_ in prepared[lo:hi]])
                    losses = [objective(o,t)[0] for o,(_,t) in zip(outputs,prepared[lo:hi],strict=True)]
                    (sum(losses)/len(cases)).backward()
                    values.extend(float(v.detach()) for v in losses)
            vectors[group_name] = torch.cat([(p.grad if p.grad is not None else torch.zeros_like(p)).detach().flatten().float() for p in model.encoder.parameters()])
            measured[group_name] = {"cases":len(cases),"meanAnnotatedLoss":float(np.mean(values)),"encoderGradientNorm":float(vectors[group_name].norm())}
        pairs = {}
        for group_name in ("original","expanded"):
            a,b = vectors["research"],vectors[group_name]
            pairs[group_name] = {"dot":float(torch.dot(a,b)),"cosine":float(torch.dot(a,b)/(a.norm()*b.norm()))}
        results[name]["gradient"] = {"groups":measured,"researchVsPublic":pairs,"scope":"Eval-mode mean supervised gradient on fixed 64-case Train samples, first view only; no optimizer update or global causal claim."}
        print({"gradient":results[name]["gradient"]},flush=True)
        del vectors, a,b
    require(weights_hash(model.state_dict()) == before,"Diagnostic changed weights")
    del model,tokenizer
    torch.cuda.empty_cache()
write(root / "probe.json", {"source":provenance(config),"testUsed":False,"devUsed":False,"seconds":time.perf_counter()-start,"models":results,"limitations":["Observed Train samples, not held-out effectiveness evidence.","One deterministic local gradient sample cannot establish the cause of forgetting.","Expanded rows are selected by input and seed before opening their labels."]})
print({"complete":True,"seconds":time.perf_counter()-start},flush=True)
