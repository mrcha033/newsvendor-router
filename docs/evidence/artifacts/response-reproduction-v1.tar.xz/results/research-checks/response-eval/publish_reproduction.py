"""Preserve the isolated published-assets smoke reproduction and its access guard."""
import hashlib
import tarfile
from pathlib import Path
from newsvendor.io import read,write

root=Path('/dev/shm/newsvendor-response-reproduction-v1')
checks=Path('results/research-checks/response-eval')
report=read(root/'report.json')
assert report['smokeOnly'] and len(report['episodes'])==7
assert all(r['allExactlyEqual'] and r['measurements']==112 for r in report['results'].values())
files={str(Path('results/response-public-reproduction-v1')/p.name):p for p in root.iterdir() if p.is_file()}
files[str(checks/'reproduction-guard.py')]=Path('/dev/shm/newsvendor-response-restored-v1/guard/sitecustomize.py')
for name in ('reproduction.log','publish_reproduction.py'):
 files[str(checks/name)]=checks/name
files['scripts/reproduce_responses.py']=Path('scripts/reproduce_responses.py')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
manifest={n:{'bytes':p.stat().st_size,'sha256':sha(p)} for n,p in files.items()}
out=Path('docs/evidence/artifacts/response-reproduction-v1.tar.xz');assert not out.exists()
with tarfile.open(out,'w:xz',preset=3) as archive:
 for n,p in files.items():archive.add(p,arcname=n)
seen=set()
with tarfile.open(out,'r:xz') as archive:
 for m in archive:
  if not m.isfile():continue
  assert m.size==manifest[m.name]['bytes']
  assert hashlib.file_digest(archive.extractfile(m),'sha256').hexdigest()==manifest[m.name]['sha256']
  seen.add(m.name)
assert seen==set(manifest)
artifact={'path':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'verifiedEveryMember':True,'files':manifest}
p='docs/evidence/research-paired-response-results.json';e=read(p)
e['publishedReproduction']={**report,'artifact':artifact,'accessRestrictions':{'networkForbidden':True,'workingDataAndCheckpointRootsForbidden':True,'emptyHubCache':True},'verifiedMeasurements':336,'scopeNote':'Seven fixed cases, one per scenario, all 16 response conditions and all three policies. The remaining 329 cases were not rerun in this loader check.'}
write(p,e)
write(checks/'reproduction-publication.json',artifact)
print({k:v for k,v in artifact.items() if k!='files'},flush=True)
