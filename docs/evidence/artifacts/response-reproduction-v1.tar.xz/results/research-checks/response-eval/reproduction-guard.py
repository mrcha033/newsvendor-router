import os,sys
from pathlib import Path
blocked=[Path('/home/yunmin/newsvendor-router/data'),Path('/home/yunmin/newsvendor-router/results')]
def audit(event,args):
 if event in ('socket.connect','socket.getaddrinfo'):raise RuntimeError('Network access forbidden in publication reproduction')
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  p=Path(os.fsdecode(args[0])).resolve()
  if any(p.is_relative_to(r) for r in blocked):raise RuntimeError('Working data/checkpoint access forbidden: '+str(p))
sys.addaudithook(audit)
