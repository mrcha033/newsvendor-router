"""Preserve public composition, isolated inference, CPU smoke and retained checkpoint identity."""

from pathlib import Path

from publish import publish

from newsvendor.bundle import file_hash
from newsvendor.io import lines, read, require, write

root = Path("results/research-checks/recovery-scope")
checks = read(root / "reproduced.json")
retained = read(root / "retained.json")
require(checks["verifiedRollouts"] == 720, "Incomplete reproduction")
require(checks["composedBundleWeightsHash"] == retained["weightsHash"], "Wrong adopted weights")
inputs = Path("/dev/shm/newsvendor-public-download-1654e77/example-inputs.jsonl")
(root / "cpu-inputs.jsonl").write_bytes(inputs.read_bytes())
require(
    len(lines(root / "cpu-predictions.jsonl")) == len(lines(inputs)) == 8, "Incomplete CPU smoke"
)
names = [
    "restore.py",
    "restoration.json",
    "restoration.log",
    "reproduction-guard.py",
    "probe_guard.py",
    "guard-check.json",
    "composition.json",
    "composition.log",
    "reproduced.json",
    "reproduction.log",
    "cpu-inputs.jsonl",
    "cpu-predictions.jsonl",
    "cpu-prediction.log",
    "retain.py",
    "retained.json",
    "retained.log",
    "publish_reproduction.py",
    "final_checks.py",
]
files = {str(root / name): root / name for name in names}
for name in [
    "scripts/compose_recovery.py",
    "scripts/predict_research.py",
    "docs/evidence/scripts/reproduce-recovery-scope.py",
]:
    files[name] = Path(name)
artifact = publish(Path("docs/evidence/artifacts/recovery-scope-reproduction-v1.tar.xz"), files)
r = read("docs/evidence/research-recovery-scope-results.json")
r.update(
    weightsAdopted=True,
    deploymentStatus="Publicly composable accepted v2/42; offline GPU reproduction and CPU CLI passed",
    retainedModel="recovery-v1 (forecast-v1 + scoped-v2/42)",
    retainedCheckpoint=retained,
    learnedValueAddedBenefitEstablished=False,
    reproductionArtifact=artifact,
    cpuSmoke={
        "cases": 8,
        "scope": "Public Train observations; CLI/serialization validation, not a new performance evaluation",
        "inputHash": file_hash(inputs),
        "outputHash": file_hash(root / "cpu-predictions.jsonl"),
        "networkAndWorkingAssetsForbidden": True,
    },
)
write("docs/evidence/research-recovery-scope-results.json", r)
write(root / "reproduction-publication.json", artifact)
