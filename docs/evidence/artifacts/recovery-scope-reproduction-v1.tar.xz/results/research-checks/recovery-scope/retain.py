"""Retain the fixed accepted head after public composition and trajectory reproduction."""

import copy
from pathlib import Path

import torch

from newsvendor.bundle import file_hash
from newsvendor.cli import provenance
from newsvendor.io import read, require, write
from newsvendor.structured_tool_eval import weights_hash
from newsvendor.structured_train import dataset_hashes, load

checks = Path("results/research-checks/recovery-scope")
root = Path("/dev/shm/newsvendor-recovery-scope-restored-v1")
manifest = read(root / "composed-model/manifest.json")
reproduced = read(checks / "reproduced.json")
require(reproduced["verifiedRollouts"] == 720, "Incomplete public reproduction")
require(reproduced["composedBundleWeightsHash"] == manifest["weightsHash"], "Unverified bundle")
report = read("/dev/shm/newsvendor-recovery-scoped-dev-v1/report.json")
require(
    report["eligibleForAdoption"] and all(all(g.values()) for g in report["gates"].values()),
    "Gate failed",
)
parent_path = Path("results/l40s-research-forecast-v1/base/42/model.pt")
require(
    file_hash(parent_path) == report["registration"]["files"][str(parent_path)],
    "Original training metadata changed",
)
parent = torch.load(parent_path, map_location="cpu", weights_only=True, mmap=True)
payload = torch.load(
    root / "composed-model/model.pt", map_location="cpu", weights_only=True, mmap=True
)
config = copy.deepcopy(parent["config"])
out = Path("results/l40s-research-recovery-v1/base/42/model.pt")
require(not out.exists(), "Preserve previous checkpoint")
config.update(output=str(out.parent), warmStart=str(parent_path))
config["encoder"] = payload["config"]["encoder"]
config["recoveryStudy"] = {
    "registration": "configs/research-recovery-scoped-v2.json",
    "headHash": manifest["source"]["checkpointHash"],
    "selectedSeed": 42,
    "selectedEpoch": 40,
}
selection = {
    "scope": "Fixed scoped-v2/42 after all three registered Train/Dev gates and isolated public-assets reproduction. No Test evaluation.",
    "source": provenance(config),
    "weightsHash": manifest["weightsHash"],
    "parentCheckpointHash": file_hash(parent_path),
    "parentWeightsHash": manifest["source"]["parentWeightsHash"],
    "studyReportHash": manifest["source"]["studyReportHash"],
    "devReportHash": manifest["source"]["devReportHash"],
    "testUsed": False,
    "newSourceHoldoutUsed": False,
    "simpleFailureRuleMatchesActionsAndOutcomes": True,
    "learnedValueAddedBenefitEstablished": False,
    "dev": {k: report["results"]["scoped-42"][k] for k in ("generated", "retail", "public")},
    "datasetHashes": dataset_hashes(config),
}
out.parent.mkdir(parents=True)
torch.save(
    {
        "schema": parent["schema"],
        "config": config,
        "report": selection,
        "datasetHashes": selection["datasetHashes"],
        "weights": payload["weights"],
    },
    out,
)
torch.set_num_threads(4)
model, tokenizer, restored_config, restored_report = load(out, "cpu")
require(restored_config == config and restored_report == selection, "Checkpoint metadata changed")
require(
    weights_hash(model.state_dict()) == manifest["weightsHash"], "Loaded checkpoint tensors differ"
)
result = {
    "checkpoint": str(out),
    "checkpointHash": file_hash(out),
    "weightsHash": manifest["weightsHash"],
    "sourceHash": provenance({})["sourceHash"],
    "parentCheckpoint": str(parent_path),
    "parentCheckpointHash": file_hash(parent_path),
    "publicCompositionEquivalent": True,
    "structuredLoaderVerified": True,
    "testUsed": False,
    "allRequiredGatesPassed": True,
    "primarySeed": 42,
    "selectedEpoch": 40,
}
write(checks / "retained.json", result)
print(result, flush=True)
