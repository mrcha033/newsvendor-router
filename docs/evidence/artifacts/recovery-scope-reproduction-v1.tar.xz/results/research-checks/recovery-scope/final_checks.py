"""Verify publication links, executed package identity, checks and raw denominators."""

import json
import re
import subprocess
from pathlib import Path

from newsvendor.cli import provenance
from newsvendor.io import read, write

root = Path("results/research-checks/recovery-scope")
checks = {}
for block in re.findall(
    r"      - run: >-\n((?:          .+\n)+)", Path(".github/workflows/ci.yml").read_text()
):
    command = block.split()
    assert command[:3] == ["uv", "run", "ruff"]
    command = [".venv/bin/ruff", *command[3:]]
    outcome = subprocess.run(command, text=True, capture_output=True, check=True)
    checks[" ".join(command)] = outcome.stdout.strip()
subprocess.run(["git", "diff", "--check"], check=True)
evidence = read("docs/evidence/research-recovery-scope-results.json")
assert provenance({})["sourceHash"] == evidence["reports"]["scoped-dev-v1"]["source"]["sourceHash"]
assert "334 passed" in (root / "tests.log").read_text()
assert not evidence["testUsed"] and not evidence["newSourceHoldoutUsed"]
assert evidence["trainOutcomeAudits"]["v1"]["verifiedRollouts"] == 13260
assert evidence["trainOutcomeAudits"]["v2"]["verifiedRollouts"] == 13260
assert evidence["devOutcomeAudit"]["verifiedRollouts"] == 32616
assert not evidence["reports"]["scoped-sequential-v1"]["eligibleForDev"]
assert evidence["reports"]["scoped-sequential-v2"]["eligibleForDev"]
links = []
for name in [
    "README.md",
    "docs/research-scope.md",
    "docs/recovery-scope.md",
    "docs/model-bundle.md",
]:
    p = Path(name)
    for target in re.findall(r"\]\(([^)]+)\)", p.read_text()):
        if "://" in target or target.startswith("#"):
            continue
        target = target.split("#")[0]
        assert (p.parent / target).exists(), (name, target)
        links.append([name, target])
result = {
    "lint": checks,
    "sourceHash": provenance({})["sourceHash"],
    "tests": "334 passed in 37.66s",
    "sourceAudits": 5,
    "numericalSmoke": 30,
    "diffCheck": "passed",
    "localDocumentLinks": len(links),
    "testInferencePerformed": False,
    "trainDevRawPathsAudited": 59136,
}
write(root / "final-checks.json", result)
print(json.dumps(result), flush=True)
