"""Assert that public-assets inference cannot use working data or network access."""

import json
import os
import socket
from pathlib import Path

root = Path("/dev/shm/newsvendor-recovery-scope-restored-v1")
result = {"guard": str(root / "guard/sitecustomize.py")}
for key, path in {
    "working_data": "data/processed/complementary/inputs.jsonl",
    "working_checkpoint": "results/l40s-research-forecast-v1/base/42/model.pt",
}.items():
    try:
        with open(path, "rb") as stream:
            stream.read(1)
    except RuntimeError as error:
        assert "Working data/checkpoint forbidden" in str(error)
        result[key] = "blocked"
    else:
        raise AssertionError("Working asset remained readable")
try:
    socket.getaddrinfo("localhost", 80)
except RuntimeError as error:
    assert "Network forbidden" in str(error)
    result["network"] = "blocked"
else:
    raise AssertionError("Network remained available")
result["emptyHubCache"] = not any(Path(os.environ["HF_HOME"]).iterdir())
assert result["emptyHubCache"]
(root / "guard-check.json").write_text(json.dumps(result, indent=2) + "\n")
print(result, flush=True)
